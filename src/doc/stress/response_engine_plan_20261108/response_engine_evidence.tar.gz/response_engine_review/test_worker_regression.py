from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path(__file__).resolve().parent
env=os.environ.copy()
for k in list(env):
 if k.startswith(('DFTKS_','EDMFT_','WIEN_LAPW1_','WIEN_STRESS_')):del env[k]
env.update(OMP_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
results={}
for case,exe in [('SrVO3','lapw1c'),('FeSe','lapw1')]:
 d=root/'tests'/(case+'_baseline_regression');d.mkdir(exist_ok=True)
 for p in (root/'tests'/case).iterdir():
  if p.is_file() and (p.suffix in {'.struct','.vsp','.vns','.klist','.in1','.in1c'} or p.name=='lapw1.def'):shutil.copy2(p,d/p.name)
 expected={}
 for label,base in [('before',root/'baseline_build/dftKS'),('after',root/'src/dftKS')]:
  with (d/(label+'.log')).open('w') as f:r=subprocess.run(['/opt/homebrew/bin/mpirun','-n','1',str(base/exe),'lapw1.def'],cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode:raise RuntimeError((d/(label+'.log')).read_text())
  got={suffix:hashlib.sha256((d/(case+'.'+suffix)).read_bytes()).hexdigest() for suffix in ['vector','energy','nsh','vec'] if (d/(case+'.'+suffix)).exists()}
  if label=='before':expected=got
  else:assert got==expected,(case,got,expected)
 results[case]={'protected_outputs_bitwise_identical':True,'sha256':got}
(root/'matrix_worker_regression.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
