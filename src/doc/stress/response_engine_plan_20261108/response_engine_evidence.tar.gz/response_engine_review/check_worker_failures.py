from pathlib import Path
import hashlib,json,os,subprocess
root=Path(__file__).resolve().parent
d=root/'tests/SrVO3';exe=root/'src/dftKS/lapw1c'
env=os.environ.copy()
for k in list(env):
 if k.startswith('DFTKS_'):del env[k]
env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
def snapshot():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file() and p.suffix not in {'.log'}}
result={}
for mode,extra in [('invalid_flag',{'DFTKS_MATRICES_ONLY':'maybe'}),('missing_prefix',{'DFTKS_MATRICES_ONLY':'1'}),('disabled_prefix',{'DFTKS_MATRICES_ONLY':'1','DFTKS_OVERLAP_DUMP':'off'})]:
 before=snapshot()
 r=subprocess.run(['/opt/homebrew/bin/mpirun','-n','4',str(exe),'lapw1.def'],cwd=d,env=env|extra,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=15)
 assert r.returncode!=0,(mode,r.stdout)
 assert snapshot()==before,mode
 result[mode]={'exit_code':r.returncode,'non_log_files_unchanged':True}
 (d/(mode+'.log')).write_text(r.stdout)
(root/'matrix_worker_failures.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
