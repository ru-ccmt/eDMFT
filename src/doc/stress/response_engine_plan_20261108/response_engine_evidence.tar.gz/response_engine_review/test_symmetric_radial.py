"""Differentiate assembled matrices with the physical KS operator fixed.

Uses current central KS vectors, not complete-eigenvector inversion.  All
outputs are in this test tree.  Production sources and material inputs are read only.
"""
from test_wien_matrices import vectors
from pathlib import Path
import json,os,re,shutil,subprocess,sys,time
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src/python'))
sys.path.insert(0,'/private/tmp/radial_stress_response_20261108')
from check_oneparticle_stress_fd import read_basis_matrix
from step_check import interpolate
ENV=os.environ.copy()
for k in list(ENV):
 if k.startswith(('DFTKS_','EDMFT_','WIEN_LAPW1_','WIEN_STRESS_')):del ENV[k]
ENV.update(OMP_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',OPENBLAS_NUM_THREADS='1')

def symmetric_vsp(base,minus,plus,out,scale):
    lines=[p.read_text().splitlines() for p in (base,minus,plus)]
    assert len(set(map(len,lines)))==1
    pattern=re.compile(r"[-+]?\d+\.\d+[EeDd][-+]\d+")
    result=[]
    for a,m,p in zip(*lines):
        fields=[list(pattern.finditer(x)) for x in (a,m,p)]
        assert len(set(map(len,fields)))==1
        line=a
        for x,y,z in reversed(list(zip(*fields))):
            value=float(x.group())+scale*(float(z.group())-float(y.group()))
            field=f"{value:{x.end()-x.start()}.12E}"
            assert len(field)==x.end()-x.start()
            line=line[:x.start()]+field+line[x.end():]
        result.append(line)
    out.write_text('\n'.join(result)+'\n')

def clone(src,d,case):
 d.mkdir(parents=True)
 for p in src.iterdir():
  if p.is_file() and (p.suffix in {'.struct','.vsp','.vns','.klist','.in1','.in1c'} or p.name=='lapw1.def'):shutil.copy2(p,d/p.name)
def execute(d,case,cplx,extra):
 t=time.monotonic()
 with (d/'run.log').open('w') as log:
  r=subprocess.run([str(ROOT/'wien/SRC_lapw1'/('lapw1c' if cplx else 'lapw1')),'lapw1.def'],cwd=d,env=ENV|extra|{'WIEN_LAPW1_MATRIX_DUMP':str(d/'native')},stdout=log,stderr=subprocess.STDOUT)
 if r.returncode or any(p.read_text().strip() for p in d.glob('lapw1.error*')):raise RuntimeError((d/'run.log').read_text())
 print(d,round(time.monotonic()-t,2),flush=True)

def run(case):
 nat,cplx=(4,True) if case=='SrVO3' else (2,False)
 old=Path('/private/tmp/radial_stress_response_20261108')/(case+'_DFT'); src=old/'center'
 root=ROOT/'tests'/(case+'_native_symmetric');center=root/'center'
 if not center.exists():
  clone(src,center,case);(center/'lapw1.fixgvec.write').touch();execute(center,case,cplx,{})
 cv=list(vectors(center/(case+'.vector'),nat,cplx))
 weights=[]
 for line in (src/(case+'.weight')).read_text().splitlines():
  a=line.split()
  if len(a)==4 and a[0].isdigit() and a[1].isdigit():weights.append(float(a[3]))
 weights=np.array(weights).reshape(len(cv),-1)
 info=json.loads((old/'summary.json').read_text());factor=14710.507641078/(3*info['volume']);results=[]
 for step in [1e-5,5e-6]:
  ends=[]
  for sign in ['minus','plus']:
   d=root/(sign+f'_{step:.0e}');ends.append(d)
   if d.exists():continue
   clone(center,d,case);shutil.copy2(center/'lapw1.fixgvec',d/'lapw1.fixgvec');(d/'lapw1.fixgvec.read').touch()
   symmetric_vsp(center/(case+'.vsp'),old/'minus/basis.vsp',old/'plus/basis.vsp',d/'basis.vsp',(1 if sign=='plus' else -1)*step/(2*info['step']))
   execute(d,case,cplx,{'WIEN_LAPW1_BASIS_VSP':str(d/'basis.vsp')})
  ev=[list(vectors(d/(case+'.vector'),nat,cplx)) for d in ends]
  dh=[];do=[];de=[];de_matrix=[];normalization=[]
  for k,(e,c,labels) in enumerate(cv,1):
   mats=[]
   for d in ends:
    h=read_basis_matrix(d/f'native.ham.k{k:08d}.bin',b'EDMFTHV1');o=read_basis_matrix(d/f'native.k{k:08d}.bin',b'EDMFTOV1')
    assert np.array_equal(labels,h.labels) and np.array_equal(labels,o.labels)
    mats.append((h.matrix,o.matrix))
   hp=(mats[1][0]-mats[0][0])/(2*step);op=(mats[1][1]-mats[0][1])/(2*step)
   hb=c.conj().T@hp@c;ob=c.conj().T@op@c
   dh.append(hb);do.append(ob);de_matrix.append((hb.diagonal()-e*ob.diagonal()).real)
   de.append((ev[1][k-1][0]-ev[0][k-1][0])/(2*step))
  dh=np.array(dh);do=np.array(do);de=np.array(de);de_matrix=np.array(de_matrix)
  result={'step':step,'direct_matrix_GPa':float(np.sum(weights*de_matrix)*factor),'eigenvalue_GPa':float(np.sum(weights*de)*factor),'difference_GPa':float(np.sum(weights*(de_matrix-de))*factor),'max_band_derivative_error_Ry':float(np.max(abs(de_matrix-de)))}
  np.savez(root/f'projected_{step:.0e}.npz',dH=dh,dO=do,weights=weights,energies=np.array([x[0] for x in cv]),eigenvalue_derivative=de,matrix_derivative=de_matrix)
  results.append(result);print(case,result,flush=True)
  (root/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 return results
if __name__=='__main__':run(sys.argv[1])
