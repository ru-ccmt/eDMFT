from pathlib import Path
import hashlib,json,os,shutil,struct,subprocess,sys,time
import numpy as np
from scipy.io import FortranFile,FortranEOFError
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src/python'))
from check_oneparticle_stress_fd import read_basis_matrix
REPO=Path('/Users/haule/projects/eDMFT_new')
base=json.loads((ROOT/'SOURCE_BASELINE.json').read_text())
p='src/dftKS/read_def_file.f90'
if p not in base:
    base[p]=hashlib.sha256((REPO/p).read_bytes()).hexdigest()
    shutil.copy2(REPO/p,ROOT/'before'/p)
    (ROOT/'SOURCE_BASELINE.json').write_text(json.dumps(base,indent=2)+'\n')
env=os.environ.copy()
for k in list(env):
    if k.startswith(('EDMFT_','WIEN_LAPW1_','WIEN_STRESS_','DFTKS_')): del env[k]
env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(d,exe,label,extra,nproc=1):
    t=time.monotonic()
    with (d/(label+'.log')).open('w') as log:
        r=subprocess.run(['/opt/homebrew/bin/mpirun','-n',str(nproc),str(exe),'lapw1.def'],cwd=d,env=env|extra,stdout=log,stderr=subprocess.STDOUT)
    txt=(d/(label+'.log')).read_text()
    if r.returncode or 'ERROR STOP' in txt or 'Fortran runtime error' in txt: raise RuntimeError(txt[-2500:])
    if any(p.read_text().strip() for p in d.glob('lapw1.error*')):raise RuntimeError('lapw1 error file')
    return time.monotonic()-t

def vectors(path,nat,complex_case):
    with FortranFile(path) as f:
        for _ in range(2*nat):f.read_record('u1')
        while True:
            try:h=f.read_record('u1').tobytes()
            except FortranEOFError:return
            kx,ky,kz,name,n,nb,w=struct.unpack('<ddd10siid',h)
            labels=f.read_record('i4').reshape(3,n,order='F')
            es=[];cs=[]
            for _ in range(nb):
                i,e=struct.unpack('<id',f.read_record('u1').tobytes());es.append(e)
                cs.append(f.read_record('c16' if complex_case else 'f8'))
            yield np.array(es),np.array(cs).T,labels

results={}
for case,ref,nat,cplx in [('SrVO3','portable_SrVO3_fixedg',4,True),('FeSe','portable_FeSe_fixedg_real',2,False)]:
    src=Path('/private/tmp/edmft_linear_response_20261108')/ref/'central'
    work=ROOT/'tests'/case;work.mkdir(parents=True,exist_ok=True)
    suffixes=['struct','in1','in1c','klist','vsp','vns']
    for suffix in suffixes:
        p=src/(case+'.'+suffix)
        if p.exists():shutil.copy2(p,work/p.name)
    shutil.copy2(src/'lapw1.def',work/'lapw1.def')
    p=work/(case+'.klist');p.write_text('\n'.join(p.read_text().splitlines()[:3])+ '\nEND\n')
    exe=ROOT/'src/dftKS'/('lapw1c' if cplx else 'lapw1')
    r={};results[case]=r
    r['normal_seconds']=run(work,exe,'normal',{'DFTKS_OVERLAP_DUMP':str(work/'normal')})
    protected=[work/(case+'.'+s) for s in ['vector','energy','nsh','vec']]
    hashes={p.name:sha(p) for p in protected if p.exists()}
    eps=[]
    for ik,(es,cs,labels) in enumerate(vectors(work/(case+'.vector'),nat,cplx),1):
        o=read_basis_matrix(work/f'normal.k{ik:08d}.bin',b'EDMFTOV1')
        h=read_basis_matrix(work/f'normal.ham.k{ik:08d}.bin',b'EDMFTHV1')
        assert np.array_equal(labels,o.labels)
        # Both exported H and vector energies use Ry.
        eps.append({'k':ik,'n':len(labels.T),'nbands':len(es),'metric_error':float(np.max(abs(cs.conj().T@o.matrix@cs-np.eye(len(es))))),'H_error_Ry':float(np.max(abs(cs.conj().T@h.matrix@cs-np.diag(es)))),'H_conjugated_error_Ry':float(np.max(abs(cs.conj().T@h.matrix.conj()@cs-np.diag(es))))})
    r['identities']=eps
    for nproc in [1,4]:
        label=f'matrix{nproc}'
        r[label+'_seconds']=run(work,exe,label,{'DFTKS_MATRICES_ONLY':'1','DFTKS_OVERLAP_DUMP':str(work/label)},nproc)
        assert hashes=={p.name:sha(p) for p in protected if p.exists()},'output changed'
        for ik in range(1,4):
            for middle,magic in [('k',b'EDMFTOV1'),('ham.k',b'EDMFTHV1')]:
                a=read_basis_matrix(work/f'normal.{middle}{ik:08d}.bin',magic)
                b=read_basis_matrix(work/f'{label}.{middle}{ik:08d}.bin',magic)
                assert np.array_equal(a.labels,b.labels) and np.array_equal(a.matrix,b.matrix),'matrix changed'
        r[label+'_exact_match']=True
        r[label+'_protected_outputs_unchanged']=True
    (ROOT/'matrix_worker_results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(case,json.dumps(r,indent=2),flush=True)
