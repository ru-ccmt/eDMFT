      PROGRAM HFSD                                                      
!                                                                       
!               H A R T R E E   F O C K   DIRAC SLATER                  
!                                                                       
!     RELHF1 CALCULATES THE ATOMIC EIGENVALUES OF A SPHERICAL TOTAL     
!     POTENTIAL                                                         
!     J P DESCLAUX   CEA PARIS 1969                                     
!     LAST UPDATE : 26. FEB 87    FOR NAS, IN INSLD TO READ FILE POTE   
!     26 NOV 2019:  ADDED OUTPUT OF TAU = |grad(phi)|**2 (jdoumont)
!                                                                       
!         5            ...   INPUT                                      
!         6            ...   OUTPUT                                     
!         7            ...   CLMCORE                                    
!         8            ...   VSP                                        
!         9 .. 19                                                       
!         20           ...   POTE                                       
!         21           ...   SCFNEW                                     
!         22           ...   SCFOLD                                     
!         28           ...   VRESP
!         82           ...   TAU
!                                                                       
!     PROGRAM HFSD (INPUT,OUTPUT,POTE,VSP,CLMCORE,SCFNEW,TAPE10,        
!    *    SCFOLD,   TAPE5=INPUT,TAPE6=OUTPUT,TAPE7=CLMCORE,TAPE8=VSP,   
!    *              TAPE20=POTE,TAPE21=SCFNEW,TAPE22=SCFOLD)            
!                                                                       
!     
      use core_sp , only: dv1p
      use core_nsp, only: sum_tot
      use struct  , only: nat, vol
      use norm_kub, only: c_kub, init_c_kub
      IMPLICIT REAL*8 (A-H,O-Z)
      INCLUDE 'param.inc'
!fb
!     parameter for calculation of [yu91]-force
      logical force, LDMNorm, there
      parameter (LDMNorm=.false.)
      parameter (force=.true.)
!fe
      CHARACTER *10 BAR                                                 
      CHARACTER *11 STATUS,FORM                                         
      CHARACTER *77 RMARGN                                              
      CHARACTER*67       ERRMSG
      CHARACTER*80       DEFFN, ERRFN
      CHARACTER *180 FNAME, margn
      CHARACTER*4 IREL,cform                                       
      LOGICAL OLD,RELA, dogllb, dodeltagllb
      LOGICAL WRITE_VRESP, WRITE_TAU
      real*8 nel                                        
      COMMON        DEN(30),DQ1(30),DFL(30),NQN(30),NQL(30),NK(30),      &
                    NMAX(30),NEL(30),NORB                               
      COMMON /DIRA/ DV(NRAD+141),DR(NRAD+141),DP(NRAD+141),DQ(NRAD+141), &
           DPAS,Z,NSTOP,NES,TETS,NP,NUC         
      COMMON /PRIMES/ DDP_DR(NRAD+141),DDQ_DR(NRAD+141)
      COMMON  /PS2/ DEXV,DEXE,DCOP,TITRE(30),TEST,TESTE,                 &
                    TESTY,TESTV,NITER,ION,ICUT,IPRAT                    
      COMMON /CHAR/ BAR                                                 
      COMMON /DEUX/ DVN(NRAD+141),DVF(NRAD+141),D(NRAD+141),DC(NRAD+141), &
                    DGC(NRAD+141,30),DPC(NRAD+141,30) 
      DIMENSION VD(NRAD+41), WORK(NRAD+41)
      DIMENSION TAU(NRAD+41)
      integer  :: alpha1, beta1, index_a, jatom1
      real*8   :: tot_core_stress(1:3,1:3)
!                                                                       
!                                                                       
!--------------------------------------------------------------------   
!               INPUT GENERATING                                        
!                                                                       
!    1. WRITE NUMBER OF ATOMORBITALS TO INPUTFILE                       
!    2. WRITE PRINCIPAL QUANTUMNUMBER, QUANTUMNUMBER KAPPA AND          
!             NUMBER OF ELECTRONS FOR EACH ORBITAL IN ONE LINE          
!             OF INPUTFILE                                              
!    3. REPEAT POINT 1 AND 2 FOR THE FOLLOWING ATOMS                    
!                                                                       
!--------------------------------------------------------------------   
!                                                                       
!      CALL XUFLOW(0)                                                   
      CALL W2kinit
      CALL GTFNAM(DEFFN,ERRFN)
      CALL ERRFLG(ERRFN,'Error in CORE')
      OPEN (1,FILE=DEFFN,STATUS='OLD',ERR=910)
      jspin=1
      dogllb = .false.
      dodeltagllb = .false.
      WRITE_VRESP = .FALSE.
      WRITE_TAU = .FALSE.
 8003 CONTINUE
         READ (1,*,END=8001,ERR=960) IUNIT,FNAME,STATUS,FORM,IRECL
         OPEN (IUNIT,FILE=FNAME,STATUS=STATUS,FORM=FORM,ERR=920)
         if(iunit.eq.83) then
             ipos = INDEX(fname,"rsplcoreup")
             if (0.ne.ipos)  jspin=2
             ipos = INDEX(fname,"rsplcoredn")
             if (0.ne.ipos)  jspin=2
         endif
         if(iunit.eq.35) dogllb = .true.
         if(iunit.eq.36) dodeltagllb = .true.
         if(iunit.eq.28) WRITE_VRESP = .TRUE.
         if(iunit.eq.82) WRITE_TAU = .TRUE.
      GOTO 8003
 8001 CONTINUE
      CLOSE (1)
!      call getarg(2,fname)
!      if(fname.eq.'      ') call getarg(1,fname)
!      OPEN(1,FILE=fname,STATUS='OLD',ERR=8000)
! 8003 READ(1,*,END=8001) IUNIT,FNAME,STATUS,FORM,IRECL
!      OPEN(IUNIT,FILE=FNAME,STATUS=STATUS,FORM=FORM,
!     *ERR=8002)
!      rewind iunit
!      GOTO 8003
! 8000 WRITE(*,*) ' ERROR IN OPENING CORE.DEF !!!!'
!      STOP 'CORE.DEF'
! 8002 WRITE(*,*) ' ERROR IN OPENING UNIT:',IUNIT
!      WRITE(*,*) '       FILENAME: ',FNAME,'  STATUS: ',STATUS,
!     *'  FORM:',FORM
!      STOP 'OPEN FAILED'
! 8001 CONTINUE
!      CLOSE (1)
      OLD=.FALSE. 
!====modified for stress 
      index_a = 0
      call init_c_kub    !contains factors of the real spherical harmonics
      call readstruct()  !to extract rotloc and rotij
      REWIND(20)         !keep intact for struct reading afterwards
      allocate(sum_tot(1:9,nat))      
      sum_tot = 0.d0     !total core stress for each atom
      tot_core_stress = 0.d0 !total core stress from all atoms in the system
      call read_vns()    !read non-spherical potential for all l and m
      REWIND(19)         !since it is also read in the force cal.
!=====end modification
      READ(20,1511) NATT,cform,IREL       
!      if(cform.eq.'NEW ') then
       assign 2021 to iform1  
!      else
!       assign 2020 to iform1  
!      end if
      RELA=.TRUE.                                                       
      IF(IREL.EQ.'NREL') RELA=.FALSE.                                   
!      print*,'irel', irel, rela
      JATOM=0                                                           
      READ(8,2032) ISCF                                                      
!     READ FROM TAPE8=VSP TO MOVE THE FILEPOINTER                       
!fb
!     set of insv-label
!     force-calculation only if 
!     non-sph. potential exists, i.e., insv=0
      read(19,'(//)',iostat=insv)
!fe
!                                                                       
!.....READ TAPE22=FERMI-ENERGY OF CASE:SCF2 FOR V_RESP
!                                                                       
!!      READ(22,700,END=7)  RMARGN,EFERM                                 
! 7    CONTINUE                                                          
!      WRITE(6,*)'FERMI-ENERGY:',EFERM                                         
! 700  FORMAT(//////,A39,f9.5)                                        
!                                                                       
      WRITE(9,1960) ISCF                                                
      WRITE(9,*) '    NORM: RHO*R*R*(4.*PI)  '         
      WRITE(9,*)                                                        
!_vresp
      IF (WRITE_VRESP) THEN
         WRITE(28,1960) ISCF                                                
         WRITE(28,*) '    NORM: RHO*R*R*(4.*PI)  '         
         WRITE(28,*)
      END IF
!_vresp
!_begin_tau
      IF (WRITE_TAU) THEN
         WRITE(82,1960) ISCF                                                
         WRITE(82,*) '    NORM: TAU*R*R*(4.*PI)  '         
         WRITE(82,*)
      END IF
!_end_tau                                                                       
!                                                                       
!                                            
!reads the Fermi energy and band gap from case.scf2 for GLLB
      if ((dogllb .eqv. .true.) .or. (dodeltagllb .eqv. .true.)) then
        gap = 1d20
        do
          read(37,'(a)',end=10) margn
          if (margn(2:13) .eq. 'GAP (global)') then
            read(margn,'(17x,f10.4)') gap
          elseif (margn(2:4) .eq. 'FER') then
            read(margn,'(39x,f10.4)') ef
          endif
        enddo
  10    continue
      endif

      iprint=0                           
  1   NSTOP=1   
      write(67,'("# atom ",i3)') jatom+1             
      CALL INSLD(RELA,npxx,cform,shift,iprint)             
! ....core wavefunctions onto unit 29
      write(29,*) norb,' core states for this atom'
      IF(NORB.EQ.0) GOTO 100                                            
 2    ITER=1                                                            
      DO 3 I=1,NP                                                       
      Dp(I)=0.d0                                                       
      Dq(I)=0.d0                                                       
      DO 3 J=1,NORB                                                     
      DGC(I,J)=0.d0                                                       
 3    DPC(I,J)=0.d0                                                       
      WRITE(6,1001) BAR                                                 
      WRITE (6,1002)                                                    
      N=-(ION+1)                                                        
 4    DO 5 I=1,NP                                                       
      vd(I)=0.d0
      TAU(I)=0.d0    
 5    D(I)=0.d0             
      TETS=TEST                                                         
      YMAX=0.d0                                                           
      VMAX=0.d0                                                           
      EMAX=0.d0

      
      
! RESOLUTION DE L EQUATION DE DIRAC POUR CHAQUE ORBITALE                
! **********************************************************************
      DO 25  J=1,NORB                                                   
 !.....fix H and He-case
      if(z.lt.2.1d0) goto 3999                                                
!      if(nel(1).lt.1.d-6) goto 4000                                     
     DE=DEN(J)                                                         
 16   CALL RESLD (NQN(J),NQL(J),NK(J),IMAX,DEN(J),DFL(J),DQ1(J),J,RELA) 
      IF (NSTOP.EQ.0) GO TO 18                                          
      IF (NSTOP.NE.362.OR.ITER.GE.10.OR.TETS.GT.TEST) GO TO 17          
      TETS=TESTV                                                        
      GO TO 16                                                          
 17   WRITE (6,1010) NSTOP,NQN(J),TITRE(J)                              
      GO TO 961                                                           
 18   VAL=ABS((DEN(J)-DE)/DE)                                           
      IF(VAL.GT.EMAX) EMAX=VAL                                          
      NMAX(J)=IMAX                                                      
      DNK = DBLE(NK(J))
      DO 24  I=1,NP                                                     
      VAL=DGC(I,J)-DP(I)                                                
      IF (ABS(DP(I)).GT.1.) VAL=VAL/DP(I)                               
      IF (ABS(VAL).LT.ABS(YMAX)) GO TO 21                               
      YMAX=VAL                                                          
      Y=DP(I)                                                           
      YN=DGC(I,J)                                                       
 21   VAL=DPC(I,J)-DQ(I)                                                
      IF (ABS(DQ(I)).GT.1.) VAL=VAL/DQ(I)                               
      IF (ABS(VAL).LT.ABS(YMAX)) GO TO 23                               
      YMAX=VAL                                                          
      Y=DQ(I)                                                           
      YN=DPC(I,J)                                                       
 23   DGC(I,J)=DP(I)                                                    
      DPC(I,J)=DQ(I)                                                    
!v_resp
      IF (WRITE_VRESP) THEN
         if (dogllb .eqv. .true.) then
            vD(I)=vD(I)+(NEL(J)*(DP(I)*DP(I)+DQ(I)*DQ(I)))*2.0d0*sqrt(abs(0.5d0*ef-den(j)))
         elseif (dodeltagllb .eqv. .true.) then
            vD(I)=vD(I)+(NEL(J)*(DP(I)*DP(I)+DQ(I)*DQ(I)))*2.0d0* &
                 (sqrt(abs(0.5d0*(ef+gap)-den(j)))-sqrt(abs(0.5d0*ef-den(j))))
         else
            vD(I)=vD(I)+(NEL(J)*(DP(I)*DP(I)+DQ(I)*DQ(I)))*(-2.0d0*den(j))
         endif
      END IF
      if (i.eq.1) write (6,*) 'eigenwert von ',j, 'Zustand',den(j)
!v_resp
! Kinetic energy density (tau)
      IF (WRITE_TAU) THEN
         TAU(I) = TAU(I) + (NEL(J)/2.0D0)* &
              ( DDP_DR(I)*DDP_DR(I) + DNK*(DNK+1.0D0)*DP(I)*DP(I)/ (DR(I)*DR(I) ) + &
              DDQ_DR(I)*DDQ_DR(I) + DNK*(DNK-1.0D0)*DQ(I)*DQ(I)/ (DR(I)*DR(I) ) )
      END IF
! tau end

24    D(I)=D(I)+NEL(J)*(DP(I)*DP(I)+DQ(I)*DQ(I))
      
!       Plot wavefunction and derivative for debugging
!       WRITE(100+j,*) "R, DQ, DDQ_DR"
!       DO 92 I=1,NRAD
!          WRITE(100+j,*) DR(I), DP(I)/DR(I), DDP_DR(I)/DR(I)
! 92       CONTINUE

3999  if(iprint.ne.0) then
         WRITE(29,2003)  NQN(J),TITRE(J),DEN(j)*2.0d0+shift        
         write(29,iform1) (dp(i),i=1,np-npxx)
         write(29,iform1) (dq(i),i=1,np-npxx)
      endif
      if(z.lt.2.1d0) goto 4000                                                
 25   CONTINUE ! end loop over NORB                                                          
      CALL POTSL (DC,D,DP,DR,DPAS,DEXV,Z,NP,ION,ICUT)                   
      IF (NUC.LE.0) GO TO 31                                            
      DO 29 I=1,NUC                                                     
 29   DC(I)=DC(I)+Z/DR(I)+Z*((DR(I)/DR(NUC))**2-3.d0)/(DR(NUC)+DR(NUC))   
 31   DO 33 I=1,NP                                                      
      DVAL=ABS(DC(I)-DV(I))                                             
      IF ((DR(I)*DC(I)).LE.N) DVAL=-DVAL/DC(I)                          
      IF (DVAL.LE.VMAX) GO TO 33                                        
      VMAX=DVAL                                                         
      J=I                                                               
 33   CONTINUE                                                          
      WRITE(6,1003) ITER,VMAX,DR(J),DV(J),DC(J),EMAX,YMAX,YN,Y          
      IF(TETS.LE.TEST.AND.EMAX.LE.TESTE.AND.VMAX.LE.TESTV.AND.YMAX.LE.TESTY) GO TO 61                                                     
      ITER=ITER+1                                                       
      IF(ITER.LE.NITER) GO TO 35                                        
      WRITE(6,1004) NITER                                               
      NSTOP=2                                                           
      GO TO 61                                                          
! POTENTIEL POUR L ITERATION SUIVANTE                                   
! **********************************************************************
 35   IF(ITER.EQ.2) GO TO 41                                            
      IF (IPRAT) 41,45,41                                               
 41   DVAL=1.-DCOP                                                      
      DO 43 I=1,NP                                                      
      DVN(I)=DV(I)                                                      
      DVF(I)=DC(I)                                                      
 43   DV(I)=DVAL*DV(I)+DCOP*DC(I)                                       
      IF (.NOT.OLD) GO TO 44                                            
      READ(10,END=431) DV                                               
431   OLD=.FALSE.                                                       
      GO TO 4                                                           
44    REWIND 10                                                         
      WRITE(10) DV                                                      
      GO TO 4                                                           
 45   DO 55  I=1,NP                                                     
      DVAL=DALP(DVN(I),DVF(I),DV(I),DC(I))                              
      DVN(I)=DV(I)                                                      
      DVF(I)=DC(I)                                                      
 55   DV(I)=DVAL*DV(I)+(1.d0-DVAL)*DC(I)                                  
      IF (.NOT.OLD) GO TO 56                                            
      READ(10,END=551) DV                                               
551   OLD=.FALSE.                                                       
      GO TO 4                                                           
56    REWIND 10                                                         
      WRITE(10) DV                                                      
      GO TO 4                                                           
 61   WRITE (6,1001) BAR                                                
!     READ (5,3001) I                                                   
 3001 FORMAT (I3)                                                       
!      if(iprint.ne.0) WRITE(6,3004) (DR(KK),D(KK),KK=1,NP) 
 3004 FORMAT(//' RADII AND CHARGE DENS. ALTERNATELY'/(6(D15.8)))        
!     IF (I.LE.0) GO TO 63                                              
 4000 JATOM=JATOM+1                                                     
      WRITE(21,720) JATOM,BAR,NORB                                      
      WRITE(9,1990) JATOM,BAR                                           
      WRITE(9,2001) 1                                                   
      WRITE(9,2002) ( NQN(JSTATE),TITRE(JSTATE), JSTATE=1,NORB )        
      WRITE(9,1980)                                                     
      WRITE(9,2011) 0,0                                                 
      NP40=NP-npxx

      if(LDMNorm)then
!       Renorm ?
!       Note, use Work so dstart -lcore does not change
        Delta=log(DR(2)/DR(1))
        call CHARGE(DR,DELTA,D,1,NP40,SUM)                         
        work(1:NP40+5)=D(1:NP40+5)
!
!       Don't use if .lcore is present
        inquire(file='.lcore',exist=there)
        if ( (Sum .gt. 1D-2).and. (.not.there)  ) then
            renorm=nint(4.D0*Sum)/(4.D0*Sum)
            work=work*renorm
            if(sum-nint(sum) .gt. 1D-2)then
               write(21,'(a,2F12.8)')'Probable Core Hole', ReNorm,sum-nint(sum)
            else
               write(21,'(a,2F12.8)')'Core Renormalization ',ReNorm,nint(sum)-sum
            endif
        endif
        WRITE(9,iform1) ( WORK(KK), KK=1,NP40)
      else
        WRITE(9,iform1) ( D(KK), KK=1,NP40)
      endif        

      WRITE(9,2030)                                                     
      WRITE(9,2031)                                                     
!_vresp
      IF (WRITE_VRESP) THEN
         WRITE(28,1990) JATOM,BAR                                           
         WRITE(28,2001) 1                                                   
         WRITE(28,2002) ( NQN(JSTATE),TITRE(JSTATE), JSTATE=1,NORB )        
         WRITE(28,1980)                                                     
         WRITE(28,2011) 0,0                                                 
         NP40=NP-npxx                                                        
         WRITE(28,iform1) ( VD(KK), KK=1,NP40)                                 
         WRITE(28,2030)                                                     
         WRITE(28,2031)
      END IF
!_vresp
!_begin_tau
      IF (WRITE_TAU) THEN
         WRITE(82,1990) JATOM,BAR                                           
         WRITE(82,2001) 1                                                   
         WRITE(82,2002) ( NQN(JSTATE),TITRE(JSTATE), JSTATE=1,NORB )        
         WRITE(82,1980)                                                     
         WRITE(82,2011) 0,0                                                 
         NP40=NP-npxx                                                        
         WRITE(82,iform1) (TAU(KK)*2.d0, KK=1,NP40)     ! in Ry                                 
         WRITE(82,2030)                                                     
         WRITE(82,2031)
      END IF
!_end_tau
      WRITE (6,1005)                                                    
! write rsplcore
          WRITE(83,2990)JATOM ,NP,z                                           
          WRITE(83,2901) 1                                               
          WRITE(83,2012) 0,0                                             

          WRITE(83,iform1) (D(KK)/jspin,KK=1,NP)                     
          WRITE(83,2031)                                                 
          WRITE(83,2030) 
 2990 FORMAT(3X,'ATOMNUMBER =',I3,5X,'RADIAL MESH POINTS: ',i5,f9.3)          
 2901 FORMAT(3X,'NUMBER OF LM',I3//)                                   
 2012 FORMAT(3X,'RLM(R) FOR L=',I2,3X,'M=',I2/)     
!                                                    
!fb
      if (force.and.insv.eq.0) call fcore(jatom,np40,dr,d)                        
!fe
!=======The following subroutine calculates the core correction stress======
!        equation (6.48) in the KB thesis
        dv1p = dv                
        call core_corr_stress(natt,np40,dr,d,jatom, index_a)

!-------------CKAMAL--------------------------------      
      if(iprint.ne.0) then
      write(6,*)'-----from hfsd:  r, rho, V, r*V (Ha)-----------'
       do kk = 1, NP
         write(6,'(4ES21.12)') DR(KK),D(KK),DV(kk),DR(kk)*DV(kk)
       enddo  
      write(6,*)'-----end hfsd---------------------------------'  
      endif
!------------END CKAMAL------------------------------  
!
! VALEURS MOYENNES DE R                                                 
! **********************************************************************
      DO 67 I=1,NP                                                      
      DVF(I)=DC(I)                                                      
 67   DQ(I)=0.d0                                                          
      DVAL=0.d0                                                           
      DO 91 I=1,NORB                                                    
      IM=NMAX(I)                                                        
      DVAL=DVAL+NEL(I)*DEN(I)                                           
      DO 73  J=1,IM                                                     
 73   DC(J)=DGC(J,I)*DGC(J,I)+DPC(J,I)*DPC(J,I)                         
      L=5                                                               
      IF (IABS(NK(I)).EQ.1) L=L-1                                       
      DO 88 J=1,L                                                       
      DP(J)=DFL(I)+DFL(I)                                               
      IF (J-2) 74,75,76                                                 
 74   N=4                                                               
      GO TO 88                                                          
 75   N=2                                                               
      GO TO 88                                                          
 76   IF (J-4) 77,78,79                                                 
 77   N=1                                                               
      GO TO 88                                                          
 78   N=-1                                                              
      GO TO 88                                                          
 79   N=-3                                                              
 88   CALL SOMM (DR,DC,DQ,DPAS,DP(J),N,IM)                              
!.... CONVERT TO RYD                                                    
      DENXX=DEN(I)*2.d0
!cccccc
!  shift the eigenvalues back back by 1 Ry
      denxx=denxx+shift
!cccccc
      if(nel(i).lt.1.d-5) denxx=0.d0                    
      WRITE (RMARGN,'(a2)') TITRE(i)
      IF (RMARGN(2:2).EQ.'*') RMARGN(2:2)=RMARGN(1:1)
      WRITE(21,730) NQN(I),RMARGN,JATOM,NQN(i),TITRE(I),DENXX   
 91   WRITE (6,1006)NQN(I),TITRE(I),DEN(I),(DP(J),J=1,L)                
! ENERGIE TOTALE EN MOYENNE SPHERIQUE                                   
! **********************************************************************
      DC(1)=1                                                           
      DO 95 I=1,NP                                                      
 95   DP(I)=D(I)/DR(I)                                                  
      IF (NUC.LE.0) GO TO 99                                            
      DO 97 I=1,NUC                                                     
 97   DP(I)=D(I)*(3.d0-DR(I)*DR(I)/(DR(NUC)*DR(NUC)))/(DR(NUC)+DR(NUC))   
      DC(1)=4.d0                                                           
 99   CALL SOMM (DR,DP,DQ,DPAS,DC(1),0,NP)                              
      DO 105  I=1,NP                                                    
      DP(I)=D(I)*DVF(I)                                                 
 105  D(I)=D(I)*((D(I)*DR(I))**(1.d0/3.d0))                                 
      DC(2)=3.d0                                                           
      DC(3)=1.d0                                                           
      IF (NUC.NE.0) DC(3)=4.d0                                            
      CALL SOMM (DR,DP,DQ,DPAS,DC(3),0,NP)                              
      CALL SOMM (DR,D,DQ,DPAS,DC(2),-1,NP)                              
      DC(2)=-3.d0*DC(2)/(105.27578d0**(1.d0/3.d0))                           
      DC(1)=-Z*DC(1)                                                    
      DC(4)=DVAL-DC(3)                                                  
      DVAL=DVAL+(DC(1)-DC(3)+(DEXE-DEXV)*DC(2))/2.d0                      
      DC(3)=(DC(3)-DC(1)-DEXV*DC(2))/2.d0                                
      DC(2)=DC(2)*DEXE/2.d0                                               
      WRITE (6,1007) DVAL,DC(4),DC(3),DC(2),DC(1)                       
      IF(NORB.EQ.1) GO TO 205                                           
      WRITE (6,1001) BAR                                                
      WRITE (6,1008)                                                    
! INTEGRALES DE RECOUVREMENT                                            
! **********************************************************************
      DO I=2,NORB                                                  
         K=I-1                                                             
         DO J=1,K                                                     
            IF(NQL(I).NE.NQL(J).OR.NK(I).NE.NK(J)) CYCLE
            IM=NMAX(J)                                                        
            IF(NMAX(I).LT.IM) IM=NMAX(I)                                      
            DO L=1,IM                                                    
               DQ(L)=DPC(L,I)*DPC(L,J)
               DC(L)=DGC(L,I)*DGC(L,J)
            ENDDO
            DVAL=DFL(I)+DFL(J)                                                
            CALL SOMM (DR,DC,DQ,DPAS,DVAL,0,IM)                               
            WRITE (6,1009) NQN(I),TITRE(I),NQN(J),TITRE(J),DVAL               
         ENDDO
      ENDDO
!205  CALL CDSLD (TITRE,BAR)                                            
 205  CONTINUE                                                        
  100 NATT=NATT-1                                                      
      IF(NATT.EQ.0) THEN
!          CALL ERRCLR(ERRFN)   !comment K. Belbase
!          STOP ' CORE  END'    !K. Belbase
          go to 151
      ENDIF                                  
      GO TO 1   
      
  151  continue
!======core correction to the stress tensor
!
! The Hellmann-Feynman core correction depends on the core charge density
! and on the strain derivative of the effective potential.  It remains valid
! when the radial core equation is solved fully relativistically: the Dirac
! kinetic operator has no explicit lattice-strain dependence in the atom-
! centered coordinates used for a localized core orbital.  RELA only changes
! RHOC and hence the numerical value of Eq. (21).  Suppressing :STR_CORE in
! RELA mode caused mixer to retain stale NREL data, so write the freshly
! evaluated tensor in both modes.  The separate scalar-relativistic valence
! correction is implemented in LAPW2.
  !below we calculate the total (spherical+non-spherical core correction)  
  WRITE(21,*)
  WRITE(21,*) ' TOTAL CORE CORRECTION STRESS TENSOR in Ry/Bohr^3, EQ. (6.48) '
  WRITE(21,*) repeat('*',60)
  
  DO jatom1 = 1, nat
     index2 = 0
    DO beta1 = 1, 3
        DO alpha1 = 1,3
            index2 = index2 + 1
            tot_core_stress(alpha1,beta1) = tot_core_stress(alpha1,beta1)  &
                                        + sum_tot(index2,jatom1)
        ENDDO     
    ENDDO
  ENDDO
  tot_core_stress = tot_core_stress /vol /jspin  
  DO alpha1 = 1, 3
     WRITE(21,7711) alpha1, (tot_core_stress(alpha1,beta1),beta1 = 1,3)
  ENDDO  
  WRITE(21,*) repeat('*',60)
  WRITE(21,*)
!=======end modfication
   
   IF(NATT.EQ.0) THEN
         CALL ERRCLR(ERRFN)
         STOP ' CORE  END'     
   ENDIF            
!
!        error handling
!
  910 INFO = 1
!
!        'core.def' couldn't be opened
!
      WRITE (ERRMSG,9000) FNAME
      CALL OUTERR('CORE',ERRMSG)
      GOTO 999
  920 INFO = 2
!
!        file FNAME couldn't be opened
!
      WRITE (ERRMSG,9010) IUNIT
      CALL OUTERR('CORE',ERRMSG)
      WRITE (ERRMSG,9020) FNAME
      CALL OUTERR('CORE',ERRMSG)
      WRITE (ERRMSG,9030) STATUS, FORM
      CALL OUTERR('CORE',ERRMSG)
      GOTO 999
  960 INFO = 7
!
!        Error reading file 'core.def'
!
      WRITE (ERRMSG,9040) FNAME
      CALL OUTERR('CORE',ERRMSG)
      GOTO 999
 961  INFO = 8
!
!        Error due to positive eigenvalue
!
      WRITE (ERRMSG,9041) NSTOP,NQN(J),TITRE(J),jatom,bar
      CALL OUTERR('CORE',ERRMSG)
      WRITE (ERRMSG,9042) 
      CALL OUTERR('CORE',ERRMSG)
      GOTO 999
  999 STOP 'CORE - Error'
!                                                                       
!                                                                       
 710  FORMAT(//,5X,'CORE STATES CONTRIBUTION TO TOTAL ENERGY',           &
             '   CALCULATED BY CORE',/)                                 
 720  FORMAT(/6X,I3,'.ATOM ',5X,A10,11X,I2,' CORE STATES')              
 730  FORMAT(':',I1,A2,i3.3,': ',i1,a2,9X,F20.9,' Ry') 
 1000 FORMAT(L7)                                                        
 1001 FORMAT (1H1,40X,A10/)                                             
 1002 FORMAT (' ITER',4X,'DVMAX',10X,'R',14X,'VN-1',13X,'VN',10X,'DEMAX' &
      ,6X,'DPMAX',9X,'PN-1',13X,'PN')                                   
 1003 FORMAT (I5,1PE11.2,3(1PE16.6),2(1PE11.2),2(1PE16.6))              
 1004 FORMAT (' NOMBRE D ITERATIONS SUPERIEUR A',I4)                    
 1005 FORMAT (12X,'ENERGIE',12X,'(R4)',14X,'(R2)',14X,'(R)',15X,'(R-1)', &
      13X,'(R-3)'/)                                                     
 1006 FORMAT (I3,A2,6(1PE18.7))                                         
 1007 FORMAT (1H0,5X,'ET=',1PE14.7,5X,'EC=',1PE14.7,5X,'EE=',1PE14.7,5X, &
      'EX=',1PE14.7,5X,'EN=',1PE14.7)                                   
 1008 FORMAT (1H0,47X,'INTEGRALES DE RECOUVREMENT'/)                    
 1009 FORMAT (34X,I1,A2,I3,A2,F19.7)                                    
 1010 FORMAT ('  NSTOP=',I4,'  POUR L ORBITALE',I3,A2)                  
 1511 FORMAT(/,27X,I3,1x,a4,/,13X,A4,/)                                       
 1960 FORMAT(3X,'SPHERICAL CHARGE DENSITY OF CORESTATES',5X,             &
             'GENERATED BY',I3,' ITERATION' )                           
 1980 FORMAT(3X)                                                        
 1990 FORMAT(3X,'ATOMNUMBER  ',I3,5X,A10)                              
 2001 FORMAT(3X,'NUMBER OF LM',I3)                                     
 2002 FORMAT(3X,'CORE STATES =', 26(I2,A2) )                            
 2003 FORMAT(3X,'CORE STATES =', I2,A2,6x,'CORE ENERGY=',F20.9,' Ry' )
 2011 FORMAT(3X,'CLM(R) FOR L',I3,3X,'M=',I2/)                         
 2020 FORMAT(3X,5E13.7)                                                 
 2021 FORMAT(3X,4ES19.12)                                                 
 2030 FORMAT(///)                                                       
 2031 FORMAT(/)                                                         
 2032 FORMAT(50X,I2,//) 
 4043 FORMAT(3X,A77)    
 9000 FORMAT('can''t open definition file ',A40)
 9010 FORMAT('can''t open unit: ',I2)
 9020 FORMAT('       filename: ',A50)
 9030 FORMAT('         status: ',A,'  form: ',A)
 9040 FORMAT('Error reading file: ',A47)
 9041 FORMAT('NSTOP=',i4,' positive eigenvalue for',I3,A2,' Atom:',i4,1x,a10)
 9042 FORMAT('Try to apply a potential shift in case.inc')
!  7710 FORMAT(':COR_CORR_',i3.3,':',2x,ES21.12)   !added kamal
 7711 FORMAT(':STR_CORE',i3.3,':',2x,3f20.10)   !added kamal
      END                                                               
