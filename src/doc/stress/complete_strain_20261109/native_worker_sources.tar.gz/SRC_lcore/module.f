MODULE struct
  LOGICAL     :: ortho,inversion
  INTEGER     :: nat,nsym,ndif
  CHARACTER*4  :: lattic,irel,cform
  CHARACTER*80 :: title
  CHARACTER*10,ALLOCATABLE :: aname(:)
  REAL*8      :: br1(3,3),aa,bb,cc,br2(3,3),avec(3,3)
  REAL*8      :: a(3),alpha(3),pia(3),vol
  INTEGER,ALLOCATABLE :: iatnr(:),mult(:),jri(:),isplit(:)      !NATO
  REAL*8,ALLOCATABLE  :: r0(:),dx(:)                            !NATO   
  REAL*8,ALLOCATABLE  :: rotloc(:,:,:),rmt(:),zz(:),vsph(:)     !NATO   
  REAL*8,ALLOCATABLE  :: rotij(:,:,:),tauij(:,:)                !NDIF
  REAL*8,POINTER      :: pos(:,:)
END MODULE struct

MODULE symetr
  INTEGER   :: iord
  INTEGER,ALLOCATABLE :: iz(:,:,:),inum(:),kkk(:,:)                 !NSYM
  INTEGER,ALLOCATABLE :: kzz(:,:),kzzr2v(:,:),kzznonloc(:,:),inst(:)!NVAW
  REAL*8,ALLOCATABLE  :: tau(:,:)                                   !NSYM
END MODULE symetr
  
MODULE core_sp   
   include 'param.inc'             
   real*8      :: dv1p(nrad+141)
END MODULE core_sp

MODULE core_nsp 
   !this module is desiganted for the non-spherical part of the core correction
   integer   , allocatable  :: lmmax_st(:), lm11_st(:,:,:)
   complex*16, allocatable  :: vns_st(:,:,:)   
   real*8, allocatable      :: sum_tot(:,:)        
END MODULE core_nsp


	module reallocate
	  !     nur 1 (generischer) Name wird von aussen angesprochen
	  interface doreallocate
	    module procedure doreallocate_r8_d1
	    module procedure doreallocate_r8_d2
	    module procedure doreallocate_i4_d1
	    module procedure doreallocate_i4_d2
	    module procedure hugo     !   ;)
	  end interface
	contains

	  !     leider sind mehrere subroutines notwendig fuer verschiedene Typen
	  subroutine doreallocate_r8_d1(tf, newdimension)
	    real*8, pointer :: hilfsfeld(:), tf(:)
	    allocate(hilfsfeld(newdimension))
	    !     nur 1 mal kopieren reicht
	    !     auch fuer mehrdimensionale Felder schaut die Zuweisung gleich aus
            min1=min(newdimension,size(tf,1))
	    hilfsfeld(1:min1)=tf(1:min1)
	    deallocate(tf)
	    !     der Zeiger wird nur auf das neue Feld umgebogen, nicht neu alloziert
	    tf=>hilfsfeld
	  end subroutine 

	  subroutine doreallocate_r8_d2(tf, newdimension1, newdimension2)
	    real*8, pointer :: hilfsfeld(:,:), tf(:,:)
	    allocate(hilfsfeld(newdimension1,newdimension2))
            min1=min(newdimension1,size(tf,1))
            min2=min(newdimension2,size(tf,2))
	    hilfsfeld(1:min1,1:min2)=tf(1:min1,1:min2)
	    deallocate(tf)
	    tf=>hilfsfeld
	  end subroutine 

	  subroutine doreallocate_i4_d1(tf, newdimension)
	    integer*4, pointer :: hilfsfeld(:), tf(:)
	    allocate(hilfsfeld(newdimension))
            min1=min(newdimension,size(tf,1))
	    hilfsfeld(1:min1)=tf(1:min1)
	    deallocate(tf)
	    tf=>hilfsfeld
	  end subroutine 

	  subroutine doreallocate_i4_d2(tf, newdimension1, newdimension2)
	    integer*4, pointer :: hilfsfeld(:,:), tf(:,:)
	    allocate(hilfsfeld(newdimension1,newdimension2))
            min1=min(newdimension1,size(tf,1))
            min2=min(newdimension2,size(tf,2))
	    hilfsfeld(1:min1,1:min2)=tf(1:min1,1:min2)
	    deallocate(tf)
	    tf=>hilfsfeld
	  end subroutine 

	!     Es gibt auch Methoden, um das Programm unleserlich zu machen :-)
	!     das sollten wir besser vermeiden ;-)
	  subroutine hugo
	    write(*,*) " Hier ist Hugo"
	  end subroutine
	end module 

module norm_kub
  
  real*8   ::  c_kub(0:10,0:10)

 contains
  subroutine init_c_kub
    
    c_kub=0.0d0
    c_kub(0,0)=1.d0
    c_kub(3,2)=1.d0
    c_kub(4,0)=.5d0*SQRT(7.d0/3.d0)
    c_kub(4,4)=.5d0*SQRT(5.d0/3.d0)
    c_kub(6,0)=.5d0*SQRT(.5d0)
    c_kub(6,2)=.25d0*SQRT(11.d0)
    c_kub(6,4)=-.5d0*SQRT(7.d0/2.d0)
    c_kub(6,6)=-.25d0*SQRT(5.d0)
    c_kub(7,2)=.5d0*SQRT(13.d0/6.d0)
    c_kub(7,6)=.5d0*SQRT(11.d0/6.d0)
    c_kub(8,0)=.125d0*SQRT(33.d0)
    c_kub(8,4)=.25d0*SQRT(7.d0/3.d0)
    c_kub(8,8)=.125d0*SQRT(65.d0/3.d0)
    c_kub(9,2)=.25d0*SQRT(3.d0)
    c_kub(9,4)=.5d0*SQRT(17.d0/6.d0)
    c_kub(9,6)=-.25d0*SQRT(13.d0)
    c_kub(9,8)=-.5d0*SQRT(7.d0/6.d0)
    c_kub(10,0)=.125d0*SQRT(65.D0/6.D0)
    c_kub(10,2)=.125d0*SQRT(247.D0/6.D0)
    c_kub(10,4)=-.25d0*SQRT(11.D0/2.D0)
    c_kub(10,6)=0.0625d0*SQRT(19.D0/3.D0)
    c_kub(10,8)=-.125d0*SQRT(187.D0/6.D0)
    c_kub(10,10)=-.0625d0*SQRT(85.d0)

  end subroutine init_c_kub
end module norm_kub

