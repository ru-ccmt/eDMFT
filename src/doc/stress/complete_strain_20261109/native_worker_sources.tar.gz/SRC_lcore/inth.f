      SUBROUTINE INTH (DP,DQ,DV,DR,DDP_DR,DDQ_DR)                                     
!                                                                       
! INTEGRATION PAR LA METHODE DE ADAMS A 5 POINTS DE LA GRANDE COMPOSANTE
! DP ET DE LA PETITE COMPOSANTE DQ AU POINT DR,DV ETANT LE POTENTIEL EN 
! CE POINT
! DDP_DR, DDQ_DR SONT R*(DERIVEES DE (DP/R, DQ/R)) POUR LE CALC DE TAU    
! **********************************************************************
      IMPLICIT REAL*8 (A-H,O-Z)
      COMMON/PS1/DEP(5),DEQ(5),DB,DVC,DSAL,DK,DM                        
!                                                                       
! DEP,DEQ DERIVEES DE DP ET DQ   DB=ENERGIE/DVC    DVC VITESSE DE LA    
! LUMIERE EN U.A.   DSAL=2.*DVC   DK NOMBRE QUANTIQUE KAPPA             
! DM=PAS EXPONENTIEL/720.                                               
! DKOEF1=475./502., DKOEF2=27./502.            (LDM Corrected a Typo here of "405"
!
! See p472 of Handbook of Numerical Analysis: Computational chemistry, edited by P. Ciarlet
! This is a conventional predictor-corrector method
!
! ********************************************************************* 
!     DATA DKOEF1/.9462151394422310D0/,DKOEF2/.5378486055776890D-1/     
      real*8, parameter :: DKOEF1 = 475.D0/502.D0 , DKOEF2=27.D0/502.D0
!     Adams-Bashforth
      DPR=DP+DM*((251.d0*DEP(1)+2616.d0*DEP(3)+1901.d0*DEP(5))-(1274.d0*DEP(2)+2774.d0*DEP(4)))                                                     
      DQR=DQ+DM*((251.d0*DEQ(1)+2616.d0*DEQ(3)+1901.d0*DEQ(5))-(1274.d0*DEQ(2)+2774.d0*DEQ(4)))                                                     
      DO 13 I=2,5                                                       
      DEP(I-1)=DEP(I)                                                   
 13   DEQ(I-1)=DEQ(I)                                                   
      DSUM=(DB-DV/DVC)*DR                                               
      DEP(5)=-DK*DPR+(DSAL*DR+DSUM)*DQR                                 
      DEQ(5)=DK*DQR-DSUM*DPR
!     Adams-Moulton                                            
      DP=DP+DM*((106.d0*DEP(2)+646.d0*DEP(4)+251.d0*DEP(5))-(19.d0*DEP(1)+264.d0*DEP(3)))                                                           
      DQ=DQ+DM*((106.d0*DEQ(2)+646.d0*DEQ(4)+251.d0*DEQ(5))-(19.d0*DEQ(1)+264.d0*DEQ(3)))                                                           
      DP=DKOEF1*DP+DKOEF2*DPR                                           
      DQ=DKOEF1*DQ+DKOEF2*DQR

      
      DEP(5)=-DK*DP+(DSAL*DR+DSUM)*DQ                                   
      DEQ(5)= DK*DQ-DSUM*DP
      DDP_DR = DEP(5)/DR - DP/DR
      DDQ_DR = DEQ(5)/DR - DQ/DR
      RETURN                                                            
      END                                                               
