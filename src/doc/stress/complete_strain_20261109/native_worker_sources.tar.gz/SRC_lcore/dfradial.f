      subroutine dfradial(r,f,df,n)
!
!     Alternative formulation of drho
!
      implicit real*8 (a-h,o-z)
!
      INCLUDE 'param.inc'
!
      dimension r(nrad),x(nrad)
      dimension f(nrad),df(nrad),a(nrad),b(nrad),df2(nrad)
      logical debug
      parameter (debug=.false.)
!
      call spline(n,r,f,df,a,b)
!

      if(debug)then
!
      DO 5005 j=1,n
        x(j)=dlog(r(j))
 5005 CONTINUE
     
      call spline(n,x,f,df2,a,b)
      DO 5006 j=1,n
        df2(j)=df2(j)/r(j)
        write(6,10)j,f(j),df(j),df2(j),df(j)-df2(j)
10      format(i4,4E15.6)
 5006 CONTINUE
!
      endif

      return
      end

