    SUBROUTINE fit_parabola(npt,np,Y,X,vfit)
!npt  781 
!np   921 
!Y    shifted potential up to npt
!X    radial mesh points
!Ai   coefficient of parabola
    IMPLICIT NONE
    INCLUDE 'param.inc'
    
    integer, intent(in)     :: npt,np
    real*8 , intent(in)     :: x(nrad+141),y(nrad+141)
    real*8 , intent(out)    :: vfit(nrad+141)
    real*8                  :: A,B,C
    integer                 :: ii
    
    C = 0.0
    B = 0.0
    A = 0.0
    
    
    C  = (Y(npt-2) - Y(npt))/(X(npt-2) - X(npt))
    C  = C - (Y(npt-1) - Y(npt))/(X(npt-1) - X(npt))
    C  = C /(X(npt-2) - X(npt-1))
    
    B  = (Y(npt-1) - Y(npt))/(X(npt-1) - X(npt))
    B  = B - C*(X(npt-1)+ X(npt))
    
    A  = Y(npt) - B*X(npt) - C*X(npt)*X(npt)

    DO ii = 1, np
       if(ii.le.npt) then
          vfit(ii) = Y(ii)
       else
          Vfit(ii) = A + B*X(ii) + C*X(ii)*X(ii)
       endif   
    ENDDO
        
    DO ii = npt, np
       if(Vfit(ii+1) .lt. Vfit(ii)) then
          Vfit(ii+1) = Vfit(ii)          
       endif  
    ENDDO    
    RETURN
    END SUBROUTINE fit_parabola
