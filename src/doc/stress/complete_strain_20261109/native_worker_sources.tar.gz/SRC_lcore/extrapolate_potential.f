    subroutine extrapolate_potential(npt,np,y,x,vfit)

!Extrapolate the potential for r>RMT with a/r+b/r**2
!a and b are determined such that the potential and its 1st derivative are continuous
!x: radial mesh points
!y: shifted potential up to npt

    implicit none
    include 'param.inc'
    
    integer, intent(in)     :: npt,np
    real*8 , intent(in)     :: x(nrad+141),y(nrad+141)
    real*8 , intent(out)    :: vfit(nrad+141)
    real*8                  :: a,b,dy
    integer                 :: i
        
    dy = (y(npt) - y(npt-1))/(x(npt) - x(npt-1))

    a = 2.0d0*y(npt)*x(npt) + dy*x(npt)**2
    b = -dy*x(npt)**3 - y(npt)*x(npt)**2

    vfit(1:npt) = y(1:npt)
    vfit((npt+1):np) = a/x((npt+1):np) + b/x((npt+1):np)**2
        
    do i = npt, np
       if(vfit(i+1) .lt. vfit(i)) vfit(i+1) = vfit(i)          
    enddo    

!    do i=700,np
!      write(777,*) x(i),vfit(i)*2.d0
!    enddo
    return
    end subroutine extrapolate_potential
