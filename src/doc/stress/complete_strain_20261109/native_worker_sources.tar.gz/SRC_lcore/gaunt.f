      REAL*8 FUNCTION GAUNT(L1,L2,L3,MM1,MM2,MM3)
      IMPLICIT REAL*8 (A-H,O-Z)
!     DATA FPI/12.56637061436D0/                
!     The following subroutines and functions are needed:
!     ph.f
!     t3j.f
!     t3j0.f
      parameter (FPI=4.D0*acos(-1.D0) )
      double precision :: FCT(100)
      Y=1.0D0
      DO I=1,49
         J=2*I-1
         FCT(J)=Y
         Y=Y*I
      END DO

      J1=2*L1
      J2=2*L2
      J3=2*L3
      M1=-2*MM1
      M2=2*MM2
      M3=2*MM3
!     FAC=(-1.D0)**MM1*SQRT( (J1+1)*(J2+1)*(J3+1)/FPI)                     
      FAC=SQRT(DBLE((J1+1)*(J2+1)*(J3+1))/FPI)
      IF( 2*(MM1/2) .ne. MM1)FAC=-FAC
      GAUNT=FAC*T3J0(J1,J2,J3,FCT)*T3J(J1,J2,J3,M1,M2,M3,FCT)
      RETURN
      END

      
      REAL*8 FUNCTION T3J (J1,J2,J3,M1,M2,M3,FCT)                           
!                                                                       
!     ANGULAR MOMENTA ENTER WITH 2X ACTUAL VALUES                       
!     ARRAY FCT MUST BE DECLARED AND FILLED GLOBALLY WITH               
!     J-FACTORIAL IN THE 2J+1 POSITION                                  
!     LARGEST  FACTORIAL NEEDED IS JA+JB+JC+1                           
!     FUNCTION NOTRI(J,K,L) RETURNS 1 IF K,L,J FORM A TRIANGLE,-1 IF NOT
!     FUNCTION PH IS NEEDED TO COMPUTE PHASES                           
!     NOTRI AND M-TEST IN MAIN PROGRAM                                  
!                                                                       
      IMPLICIT REAL*8 (A-H,O-Z)
      double precision :: FCT(100)                        
!                                                                       
      T3J=0.                                                            
!     IF((M1+M2+M3).NE.0) GOTO 101                                      
!     IF(NOTRI(J1,J2,J3).LT.0) GOTO 102                                 
      K0=J1+J2-J3                                                       
      K1=J1-M1                                                          
      K2=J2+M2                                                          
      L1=J2-J3-M1                                                       
      L2=J1-J3+M2                                                       
      KMAX=MIN0(K1,K2,K0)+1                                             
      KMIN=MAX0(0,L1,L2)+1                                              
      C=SQRT(FCT(K0+1)*FCT(J1-J2+J3+1)*FCT(J2-J1+J3+1)/FCT(J1+J2+J3+3)   &
             *FCT(J1+M1+1)*FCT(K1+1)*FCT(J2-M2+1)*FCT(K2+1)*FCT(J3+M3+1) &
             *FCT(J3-M3+1))                                             
      DO 10 I=KMIN,KMAX,2                                               
         K=I-1                                                          
         T3J=T3J+C*PH(K)/FCT(I)/FCT(K0-K+1)/FCT(K1-K+1)/FCT(K2-K+1)    &
               /FCT(I-L1)/FCT(I-L2)                                     
   10 CONTINUE                                                          
      T3J=PH(J1-J2-M3)*T3J                                              
  100 RETURN                                                            
! 101 WRITE(6,1)                                                        
!   1 FORMAT(1H ,"M1+M2+M3.NE0")                                        
!     STOP                                                              
! 102 WRITE(6,2) J1,J2,J3                                               
!   2 FORMAT(1H ," TRIANGLE RULE NOT SATISFIED FOR (",3I4," )/2")       
!     STOP                                                              
      END         
      
      REAL*8 FUNCTION T3J0(J1,J2,J3,FCT)                               
      IMPLICIT REAL*8 (A-H,O-Z)
      double precision :: FCT(100)
      J=J1+J2+J3                                                        
      F1=SQRT(FCT(J-2*J1+1)*FCT(J-2*J2+1)*FCT(J-2*J3+1)/FCT(J+3))       
      F2=FCT(J/2+1)/FCT(J/2-J1+1)/FCT(J/2-J2+1)/FCT(J/2-J3+1)           
      T3J0=PH(J/2)*F1*F2                                                
      RETURN                                                            
      END            
      
      
      REAL*8 FUNCTION PH(N)                                             
      IMPLICIT REAL*8 (A-H,O-Z)
      PH=1.0D0                                                          
      K=MOD(IABS(N),4)                                                  
      IF(K.EQ.0) GOTO 5                                                 
         PH=-1.0D0                                                      
    5 RETURN                                                            
      END
      
      
      FUNCTION NOTRI(K,L,M)                                             
      IMPLICIT REAL*8 (A-H,O-Z)
      NOTRI=-1                                                          
      IF(MOD((K+L+M),2).EQ.1) GOTO 10                                   
      IF((K+L-M).LT.0) GOTO 10                                          
      IF((K-L+M).LT.0) GOTO 10                                          
      IF((M+L-K).LT.0) GOTO 10                                          
      NOTRI=1                                                           
   10 RETURN                                                            
      END    
