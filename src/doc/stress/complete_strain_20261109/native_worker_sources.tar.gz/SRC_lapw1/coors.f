      SUBROUTINE COORS(RKM,NT,SX,SY,SZ,NAT,nmat_only)
!
      use matrices, only: HSROWS, KZZ, XK, YK, ZK, INIT_MATRICES, RK
      use lolog, only : nlo, loor, lapw, ilo
      use char, only  : LATTIC, NAME
      use gener, only : BR2
      use lstapw, only  : RKMT, NV
      use orth, only  : ORTHO
      use cut1, only  : CUT
      use struk, only : POS, ALAT, ALPHA, RMT, V, PIA, VI, IATNR, MULT
      use nmr, only  : korig,dokorig
      use comi, only : nemax_it
      use comr, only : EU
      use parallel, only : NPE
      IMPLICIT NONE
      INCLUDE 'param.inc'
!
!        Arguments
!
      logical            nmat_only
      INTEGER            NAT, NT, nmatmax1,numemin,iplus
      DOUBLE PRECISION   RKM, SX, SY, SZ
!
!     ..................................................................
!
!        LAPW list generator for K-basis
!
!     ..................................................................
!
!        Local Scalars
!
      integer            nvec1loc,nvec2loc,nvec3loc
      INTEGER            I, IV, J, JA, JB, JC, M, N, NDM1, NV1, NV2, NV3
      INTEGER            IOS, FIX_N, FIX_I
      DOUBLE PRECISION   DELTA, Q, RKQ, SBX, SBY, SBZ, SKX, SKY, SKZ
      real*8               SBX0, SBY0, SBZ0,RKQ0, korigx, korigy, korigz
      DOUBLE PRECISION   SXREF, SYREF, SZREF, RKMAXFIX
      CHARACTER*67       ERRMSG
      CHARACTER*80       FIX_MAGIC
      INTEGER            IA
      DOUBLE PRECISION   RNN
      LOGICAL            FIX_INIT, FIX_WRITE, FIX_READ
      LOGICAL            THERE_WRITE, THERE_READ
!
!        External Subroutines
!
      EXTERNAL           LOPW, OUTERR
!
!        Intrinsic Functions
!
      INTRINSIC          ABS, SIGN, SQRT
!
!        Data statements
!
      DATA DELTA /1.0D-2/
      SAVE FIX_INIT, FIX_WRITE, FIX_READ
      DATA FIX_INIT /.FALSE./

!     Optional finite-difference stress diagnostic.
!
!     Analytic LAPW stress differentiates a fixed variational space. A
!     normal finite-difference calculation rebuilds the spherical |k+G|
!     cutoff after strain, so plane waves can enter or leave the basis.
!     The resulting discontinuous energy change can be larger than the
!     stress error being tested. The marker files below enable a strictly
!     opt-in, serial-only diagnostic which keeps the integer G-vector list
!     fixed while the reciprocal lattice is strained:
!
!       lapw1.fixgvec.write  present: write lapw1.fixgvec
!       lapw1.fixgvec.read   present: read  lapw1.fixgvec
!
!     Normal production behavior is unchanged when neither marker exists.
!     Reference and strained runs must have identical k-point ordering,
!     lattice type, symmetry ordering, and local-orbital definitions.
      IF (.NOT.FIX_INIT) THEN
         INQUIRE(FILE='lapw1.fixgvec.write',EXIST=THERE_WRITE)
         INQUIRE(FILE='lapw1.fixgvec.read', EXIST=THERE_READ)
         IF (THERE_WRITE .AND. THERE_READ) THEN
            WRITE(6,*) 'FIXGVEC: both read and write markers exist'
            STOP 'FIXGVEC marker conflict'
         ENDIF
         FIX_WRITE=THERE_WRITE
         FIX_READ =THERE_READ
         IF ((FIX_WRITE .OR. FIX_READ) .AND. NPE.NE.1) THEN
            WRITE(6,*) 'FIXGVEC: diagnostic currently requires serial lapw1'
            STOP 'FIXGVEC serial only'
         ENDIF
         IF (FIX_WRITE) THEN
            OPEN(91,FILE='lapw1.fixgvec',STATUS='REPLACE', &
                 ACTION='WRITE',IOSTAT=IOS)
            IF (IOS.NE.0) STOP 'FIXGVEC cannot open output file'
            WRITE(91,'(A)') 'LAPW1_FIXGVEC_V1'
            WRITE(6,*) 'FIXGVEC: writing fixed G-vector reference'
         ELSEIF (FIX_READ) THEN
            OPEN(91,FILE='lapw1.fixgvec',STATUS='OLD', &
                 ACTION='READ',IOSTAT=IOS)
            IF (IOS.NE.0) STOP 'FIXGVEC cannot open input file'
            READ(91,'(A)',IOSTAT=IOS) FIX_MAGIC
            IF (IOS.NE.0 .OR. TRIM(FIX_MAGIC).NE.'LAPW1_FIXGVEC_V1') &
                 STOP 'FIXGVEC invalid file header'
            WRITE(6,*) 'FIXGVEC: reading fixed G-vector reference'
         ENDIF
         FIX_INIT=.TRUE.
      ENDIF
!
      iplus=0
      IF (ORTHO) THEN
         SKX = SX*PIA(1)
         SKY = SY*PIA(2)
         SKZ = SZ*PIA(3)
         korigx = korig(1)*PIA(1)
         korigy = korig(2)*PIA(2)
         korigz = korig(3)*PIA(3)
      ELSE
         SKX = SX*BR2(1,1) + SY*BR2(1,2) + SZ*BR2(1,3)
         SKY = SX*BR2(2,1) + SY*BR2(2,2) + SZ*BR2(2,3)
         SKZ = SX*BR2(3,1) + SY*BR2(3,2) + SZ*BR2(3,3)

         korigx = korig(1)*BR2(1,1) + korig(2)*BR2(1,2) + korig(3)*BR2(1,3)
         korigy = korig(1)*BR2(2,1) + korig(2)*BR2(2,2) + korig(3)*BR2(2,3)
         korigz = korig(1)*BR2(3,1) + korig(2)*BR2(3,2) + korig(3)*BR2(3,3)
      ENDIF

!     In read mode bypass the usual |k+G| cutoff completely. Keep the
!     reference integer labels and rebuild only their Cartesian components
!     using the strained reciprocal lattice BR2. Preserving the reference
!     order also makes the local-orbital plane-wave selection reproducible.
      IF (FIX_READ) THEN
         CALL INIT_MATRICES(0,0,NMATMAX1)
         NDM1=NMATMAX1+1-NLO
         READ(91,*,IOSTAT=IOS) FIX_N,SXREF,SYREF,SZREF
         IF (IOS.NE.0) STOP 'FIXGVEC missing k-point block'
         IF (FIX_N.LE.0 .OR. FIX_N.GT.NDM1) &
              STOP 'FIXGVEC invalid matrix dimension'
         IF (ABS(SX-SXREF).GT.1.D-8 .OR. &
             ABS(SY-SYREF).GT.1.D-8 .OR. &
             ABS(SZ-SZREF).GT.1.D-8) THEN
            WRITE(6,*) 'FIXGVEC k-point mismatch: ',SX,SY,SZ
            WRITE(6,*) 'FIXGVEC reference k-point:',SXREF,SYREF,SZREF
            STOP 'FIXGVEC k-list mismatch'
         ENDIF
         N=FIX_N
         DO FIX_I=1,N
            READ(91,*,IOSTAT=IOS) KZZ(1,FIX_I),KZZ(2,FIX_I), &
                                  KZZ(3,FIX_I)
            IF (IOS.NE.0) STOP 'FIXGVEC truncated G-vector block'
            JA=KZZ(1,FIX_I)
            JB=KZZ(2,FIX_I)
            JC=KZZ(3,FIX_I)
!           WIEN2k stores CXZ KZZ labels in a transformed convention.
            IF (LATTIC(1:3).EQ.'CXZ') THEN
               IF (MOD(KZZ(1,FIX_I)-KZZ(3,FIX_I),2).NE.0 .OR. &
                   MOD(KZZ(1,FIX_I)+KZZ(3,FIX_I),2).NE.0) &
                    STOP 'FIXGVEC invalid CXZ labels'
               JA=(KZZ(1,FIX_I)-KZZ(3,FIX_I))/2
               JC=(KZZ(1,FIX_I)+KZZ(3,FIX_I))/2
            ENDIF
            SBX=SKX+JA*BR2(1,1)+JB*BR2(1,2)+JC*BR2(1,3)
            SBY=SKY+JA*BR2(2,1)+JB*BR2(2,2)+JC*BR2(2,3)
            SBZ=SKZ+JA*BR2(3,1)+JB*BR2(3,2)+JC*BR2(3,3)
            XK(FIX_I)=SBX
            YK(FIX_I)=SBY
            ZK(FIX_I)=SBZ
            RK(FIX_I)=SQRT(SBX**2+SBY**2+SBZ**2)
         ENDDO
         GOTO 81
      ENDIF

 111  continue
      nvec1loc=nvec1+iplus
      nvec2loc=nvec2+iplus
      nvec3loc=nvec3+iplus
      call INIT_MATRICES(0, 0,nmatmax1)
!      NDM1 = HSROWS + 1
 1    NDM1 = NMATMAX1 + 1 - NLO
      RK(NDM1) = 1.0D+10
      N = 0
      JA = -NVEC1loc
   10 CONTINUE
      JA = JA + 1
      IF (JA .LT. NVEC1loc) THEN
         JB = -NVEC2loc
   20    CONTINUE
         JB = JB + 1
         IF (JB .GE. NVEC2loc) THEN
            GOTO 10
         ELSE
            JC = -NVEC3loc
   30       CONTINUE
            JC = JC + 1
            IF (JC .GE. NVEC3loc) THEN
               GOTO 20
            ELSE
               N = N + 1
               SBX = SKX + JA*BR2(1,1) + JB*BR2(1,2) + JC*BR2(1,3)
               SBY = SKY + JA*BR2(2,1) + JB*BR2(2,2) + JC*BR2(2,3)
               SBZ = SKZ + JA*BR2(3,1) + JB*BR2(3,2) + JC*BR2(3,3)
               RKQ = SQRT(SBX**2+SBY**2+SBZ**2)

               SBX0 = SKX - korigx + JA*BR2(1,1) + JB*BR2(1,2) + JC*BR2(1,3)
               SBY0 = SKY - korigy + JA*BR2(2,1) + JB*BR2(2,2) + JC*BR2(2,3)
               SBZ0 = SKZ - korigz + JA*BR2(3,1) + JB*BR2(3,2) + JC*BR2(3,3)
               RKQ0 = SQRT(SBX0**2+SBY0**2+SBZ0**2)

               IF (RKQ0 .LE. RKM) THEN
!                  IF (N .GT. NDM1) N = NDM1
                  IF (N .GT. NDM1) then
                          N = NDM1
                          cut=.true.
                  endif
!
!        put vector in list according to length
!
                  M = N
   40             CONTINUE
                  IF (M .LE. 1) THEN
                     GOTO 50
                  ELSE
                     M = M - 1
                     IF (RK(M) .GT. RKQ) THEN
                        I = M + 1
                        RK(I) = RK(M)
                        XK(I) = XK(M)
                        YK(I) = YK(M)
                        ZK(I) = ZK(M)
                        KZZ(1,I) = KZZ(1,M)
                        KZZ(2,I) = KZZ(2,M)
                        KZZ(3,I) = KZZ(3,M)
                        GOTO 40
                     ENDIF
                  ENDIF
!
                  M = M + 1
                  IF (M .GE. NDM1) THEN
                     IF (RK(NDM1) .LT. RKQ) GOTO 60
                  ENDIF
!
   50             CONTINUE
                  RK(M) = RKQ
                  XK(M) = SBX
                  YK(M) = SBY
                  ZK(M) = SBZ
                  IF (ORTHO) THEN
                     Q = SBX/PIA(1) - SX
                     KZZ(1,M) = Q + SIGN(DELTA,Q)
                     Q = SBY/PIA(2) - SY
                     KZZ(2,M) = Q + SIGN(DELTA,Q)
                     Q = SBZ/PIA(3) - SZ
                     KZZ(3,M) = Q + SIGN(DELTA,Q)
                  ELSE
                     KZZ(1,M) = JA
                     KZZ(2,M) = JB
                     KZZ(3,M) = JC
!....transfer monocl.CXZ coord into "simple" monoclinc
                     if(lattic(1:3).eq.'CXZ') then
                         KZZ(1,M)=JA+JC
                         KZZ(2,M)=JB
                         KZZ(3,M)=-JA+JC   !fixed CXZ bug
                     endif
                  ENDIF
                  GOTO 30
               ENDIF
   60          CONTINUE
               N = N - 1
               GOTO 30
            ENDIF
         ENDIF
      ENDIF
      IF (N .GE. (NMATMAX1-NLO)) THEN
         cut=.true.
         DO 70 J = 1,NDM1
            N = NDM1 - J
            IF (ABS(RK(N)-RK(N+1)) .GT. 1.0D-5) GOTO 80
   70    CONTINUE
      ENDIF
   80 CONTINUE
   81 CONTINUE
      RNN = RMT(1)
      DO 160 IA = 2, NAT
         IF (RMT(IA) .LT. RNN) RNN = RMT(IA)
  160 CONTINUE
!     The reference order is length-sorted before strain but need not stay
!     sorted after anisotropic strain. RKMT is informational in read mode.
      RKMAXFIX=0.D0
      DO FIX_I=1,N
         IF (RK(FIX_I).GT.RKMAXFIX) RKMAXFIX=RK(FIX_I)
      ENDDO
      RKMT=RKMAXFIX*RNN
!
!        set up the arrays of spherical Bessel functions
!
!     check if nvec1,2,3 are large enough
      IF (FIX_READ) GOTO 165
      if(nv.eq.0) then      !first pass
        NV = N
        iplus=1
        goto 111
      else if(nv.ne.n) then     ! not ok
        write(6,*) 'coors: iplus,nv,n=',iplus, nv,n
        NV = N
        iplus=iplus+1
        goto 111
      endif
      NV = N
         
!      write(6,*) 'calkpt: nv, nlo, nume:', nv, nlo, nume
!      write(6,*) 'size: rk,kzz: ', size(rk,1), size(kzz,1), size(kzz,2)
!      write(6,*) 'size: rk,kzz(1,2): ', size(rk,1), size(kzz,1), size(kzz,2)
!      do iv=1,nv
!      write(6,*) kzz(1,iv),kzz(2,iv),kzz(3,iv),xk(iv),yk(iv),zk(iv)
!      enddo
      DO 100 IV = 1, 2
         IF (IV .EQ. 1) THEN
            NV1 = -NVEC1loc
            NV2 = -NVEC2loc
            NV3 = -NVEC3loc
         ELSE
            NV1 = NVEC1loc
            NV2 = NVEC2loc
            NV3 = NVEC3loc
         ENDIF
         JA = NV1
         JB = 0
         JC = 0
   90    CONTINUE
         SBX = SKX + JA*BR2(1,1) + JB*BR2(1,2) + JC*BR2(1,3)
         SBY = SKY + JA*BR2(2,1) + JB*BR2(2,2) + JC*BR2(2,3)
         SBZ = SKZ + JA*BR2(3,1) + JB*BR2(3,2) + JC*BR2(3,3)
         RKQ = SQRT(SBX**2+SBY**2+SBZ**2)
         IF (RKQ .LT. RK(NV)) THEN
            GOTO 110
         ELSEIF (JB .EQ. NV2) THEN
            JC = NV3
            JB = 0
            GOTO 90
         ELSEIF (JC .NE. NV3) THEN
            JB = NV2
            JA = 0
            GOTO 90
         ENDIF
  100 CONTINUE
!     Write only after the internal sizing pass and vector-bound checks are
!     complete; otherwise the same k-point would be recorded more than once.
      IF (FIX_WRITE) THEN
         WRITE(91,'(I10,3ES26.16)') N,SX,SY,SZ
         DO FIX_I=1,N
            WRITE(91,'(3I12)') KZZ(1,FIX_I),KZZ(2,FIX_I), &
                                KZZ(3,FIX_I)
         ENDDO
         FLUSH(91)
      ENDIF
  165 CONTINUE
      NV=N
      if(nmat_only) then
         write(72,*) nv+nlo
!         stop 'NMAT_ONLY'
         return
      endif
!      numemin=min(nume,(nv+nlo)/2)
      numemin=min(nume,(nv+nlo))
      if(dokorig) then
         numemin=nv+nlo     ! fix for NMR
         nemax_it=nv+nlo
      endif
      if(EU.gt.1.d9) nemax_it=nv+nlo
      if(nemax_it.gt.nv+nlo) nemax_it=nv+nlo
      call INIT_MATRICES(NV + NLO, NUMEmin,nmatmax1)
      IF (NLO .GT. 0) CALL LOPW(NAT)
!
      RETURN
!
!        Error messages
!
  110 CONTINUE
      IF (JA .EQ. NV1) THEN
!         CALL OUTERR('COORS','NVEC1 too small.')
            write(6,*) 'NVEC1 too small.',nvec1loc,ja,rk(nv),rkq
            nvec1loc=nvec1loc*2
      ELSEIF (JB .EQ. NV2) THEN
!         CALL OUTERR('COORS','NVEC2 too small.')
            write(6,*) 'NVEC2 too small.',nvec2loc,jb,rk(nv),rkq
            nvec2loc=nvec2loc*2
      ELSE
!         CALL OUTERR('COORS','NVEC3 too small.')
            write(6,*) 'NVEC3 too small.',nvec3loc,jc,rk(nv),rkq
            nvec3loc=nvec3loc*2
      ENDIF
!      WRITE (ERRMSG,9000) RK(NV), JA, JB, JC, RKQ
!      CALL OUTERR('COORS',ERRMSG)
      goto 1
!
 9000 FORMAT ('RK(NV)=',F7.3,2X,'RK(',I3,',',I3,',',I3,')=',F7.3)
!
!        End of 'COORS'
!
   END
