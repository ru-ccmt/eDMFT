      SUBROUTINE SELECT(L,EI,DE,EMAIN,REL,VR,RNOT,DX,JRI,ZZ,jatom,efermi)
!
      use parallel, only: MYID, abort_parallel
      IMPLICIT REAL*8 (a-h,o-z)
!
!        Arguments
!
      include 'param.inc'
      INTEGER            JRI, L,jatom
      DOUBLE PRECISION   DE, DX, EI, RNOT, ZZ
      DOUBLE PRECISION   VR(*), RNET(NRAD)
      LOGICAL            REL, UP, DEBUG, ShowIter
      CHARACTER*4        EMAIN
!
!     ..................................................................
!
!        automatic energy search:
!           finds energy parameter by looking where value and slope of
!           wavefunction changes sign  (E-top:    u  changes sign)
!                                      (E-bottom: u' changes sign)
!
!     ..................................................................
!
!        Local Scalars
!
      INTEGER            NODE, NODE1, NODE2
      DOUBLE PRECISION   DDNOLD, DNOLD, DU, DUDN, DUPOLD, DUTST, DUUP
      DOUBLE PRECISION   E1, E2, EIDN, EIUP, FL, U, UDN, UPOLD, UTST
      DOUBLE PRECISION   UUP
      CHARACTER*67       ERRMSG
!
!        External Subroutines
!
      EXTERNAL           OUTERR, OUTWINB
!
!        Intrinsic Functions
!
      INTRINSIC          MAX
!
      DEBUG=.false.
!      DEBUG=.true.
      ShowIter=.false.
      numcalls=0
!     Setup RMT mesh. Moved out of loop for efficiency
      do iiij=1,JRI
         RNET(iiij)=RNOT*(exp(DX*(iiij-1.d0)))
      enddo

      Upper = 0.5                       ! This will replicate the original, and is problematic
     if(efermi.gt.0.8) Upper = efermi*0.5D0 + 0.25D0     ! 0.5 Rydbergs above E_F, equally problematic
     if(efermi.gt.0.8.and.l.gt.1) Upper = efermi*0.5D0 + 0.5D0     ! 0.5 Rydbergs above E_F, equally problematic

!     DE = 0.0001D0     ! Temporary hack here
      DE = max(DE,0.02D0)
      NODE1 = -1
      NODE2 = -1
      Reduce = 0.5D0
      FL = L
      eisave=ei
      EI = EI*0.5D+0
      DE = DE*0.5D+0
      CALL OUTWINB(REL,VR,RNET,DX,JRI,EI,FL,U,DU,NODE,ZZ)
      numcalls=numcalls+1
      EIUP = EI
      EIDN = EI
      E1 = -260.0D+0
      E2 = -260.0D+0
      UPOLD = U
      DUPOLD = DU
      DNOLD = U
      DDNOLD = DU
   10 CONTINUE
      EIUP = EIUP + DE
      CALL OUTWINB(REL,VR,RNET,DX,JRI,EIUP,FL,UUP,DUUP,NODE,ZZ)
      numcalls=numcalls+1
      UTST = UPOLD*UUP
      DUTST = DUPOLD*DUUP
!      WRITE(6,99)L,EIUP,UTST,DUTST
!   99 FORMAT(' L,EIUP,UTST,DUTST',I2,F8.4,2E12.3)
      UPOLD = UUP
      DUPOLD = DUUP
      IF (UTST .LT. 0.0D+0) THEN
         E2 = EIUP
         NODE2=NODE
         IF (E1 .GT. -250.0D+0) GOTO 30
      ENDIF
      IF (DUTST .LT. 0.0D+0) THEN
         E1 = EIUP
         NODE1 = NODE
         IF (E2 .GT. -250.0D+0) GOTO 30
      ENDIF
      IF ((E1 .LT. -250.0D+0) .AND. (EIUP .LT. 2.5D+0)) THEN
   20    CONTINUE
         EIDN = EIDN - DE
         CALL OUTWINB(REL,VR,RNET,DX,JRI,EIDN,FL,UDN,DUDN,NODE,ZZ)
         numcalls=numcalls+1
         UTST = DNOLD*UDN
         DUTST = DDNOLD*DUDN
!         WRITE(6,98)L,EIDN,UTST,DUTST
!   98    FORMAT(' L,EIDN,UTST,DUTST',I2,F8.4,2E12.3)
         DNOLD = UDN
         DDNOLD = DUDN
         IF (UTST .LT. 0.0D+0) THEN
            E2 = EIDN
            NODE2 = NODE
            IF (E1 .GT. -250.0D+0) GOTO 30
         ENDIF
         IF (DUTST .LT. 0.) THEN
            E1 = EIDN
            NODE1 = NODE
            IF (E2 .GT. -250.0D+0) GOTO 30
         ENDIF
         IF (E2 .LT. -250.0D+0) THEN
            GOTO 10
         ELSEIF (EIDN .GT. (EI - 3.0D+0)) THEN
            GOTO 20
         ENDIF
      ELSEIF (EIUP .LT. upper) THEN
         GOTO 10
      ENDIF
   30 CONTINUE

      if((myid .eq. 0).and.showiter) write(6,66)0,numcalls,2*E1,2*E2,2*DE
      DExit   = 1D-8
      NumIter = 20 
      DO IIIJ=1,NumIter
!
      IF( E2 .gt. -260.D0 ) then
       EI_Low = E2-DE
       EI_High= E2+DE*5.D0
       Up     =.true.
       call SearchUP(REL,VR,RNET,DX,JRI,FL,ZZ , &
       EIOUT, EI_Low, EI_High, Up, DE, numcalls, ifail, debug  )
       IF(ifail .eq. 0)E2=EIOUT
       if(debug)write(6,*)'Returned UP ',E2,ifail,EIOUT
      ENDIF
      IF( E1 .gt. -260.D0 ) then
       EI_Low = E1-DE
       EI_High= E1+DE*5.D0
       Up     =.true.
       call SearchDN(REL,VR,RNET,DX,JRI,FL,ZZ , &
       EIOUT, EI_Low, EI_High, Up, DE, numcalls, ifail, debug  )
       IF(ifail .eq. 0)E1=EIOUT
       if(debug)write(6,*)'Returned DN ',E1,EIOUT,ifail
      endif

!     End of Search. Now reduce the step size and iterate
!
      if((myid .eq. 0).and.showiter) write(6,66)iiij,numcalls,2*E1,2*E2,2*DE
66    format('Pass ',i4,' Iterations ',i4,' E1 & E2 ',2ES13.5,' Step ',ES12.4,' (Ryd)')
!
      DE=DE*Reduce
      if(DE .lt. DExit)exit                     ! Termination condition
      ENDDO

      EI = EI*2.0D+0
      E1 = E1*2.0D+0
      E2 = E2*2.0D+0
      IF ((E1 .LT. -260.0D+0) .AND. (E2 .LT. -260.0D+0)) THEN
         IF (EMAIN .EQ. 'STOP') THEN
!
!        Error: no energy limits found
!
            GOTO 900
         ELSE
            EI = 2.0D+0
            EI = eisave
         ENDIF
      ELSEIF (E2 .LT. -260.0D+0) THEN
         IF (EMAIN .EQ. 'STOP') THEN
!
!        Error: no energy limits found
!
            GOTO 900
         ELSE
            EI = MAX(E1,EI)
         ENDIF
      ELSEIF (E1 .LT. -260.0D+0) THEN
!
!        Error: no energy limits found
!
         GOTO 900
      ELSE
         EI = (E1+E2)*0.5D+0
      ENDIF
      IF(myid.eq.0) WRITE (6,6000)  l,jatom,L, EI, E1, E2, Node1, Node2, numcalls
      IF(myid.eq.0) WRITE (21,6000) l,jatom,L, EI, E1, E2, Node1, Node2, numcalls

!
      RETURN
!
!        Error messages
!
  900 WRITE (ERRMSG,9000) jatom, L
      CALL OUTERR('SELECT',ERRMSG)
      WRITE (ERRMSG,9010) E1, E2
      CALL OUTERR('SELECT',ERRMSG)
      call abort_parallel
      STOP 'SELECT - Error'
!
 6000 FORMAT (':E',i1,'_',i4.4,':',1X,'E(',I2,')=',F10.4,3X,'E(BOTTOM)=',F9.3,3X,'E(TOP)=', &
              F9.3,2i3,i6)
 9000 FORMAT ('no energy limits found for atom ',i3,'  L=',I2)
 9010 FORMAT ('E-bottom ',F10.5,3X,'E-top ',F10.5)
!
!        End of 'SELECT'
!
      END


      Subroutine SearchDN(REL,VR,RNET,DX,JRI,FL,ZZ , &
        EIOUT, EI_Low, EI_High, Up, DE, numcalls, ifail, debug  )

      implicit real*8 (a-h,o-z)

      include 'param.inc'
!
      DOUBLE PRECISION   VR(*), RNET(NRAD)
      LOGICAL            REL, Up, debug

      IFAIL=0
      IF( UP )then
        DDE=DE
        EA=EI_LOW
        EB=EI_High
      ELSE
        DDE=-DE
        EA=EI_High
        EB=EI_Low
      ENDIF

      CALL OUTWINB(REL,VR,RNET,DX,JRI,EA,FL,UDN,DDNOLD,node,ZZ)
      if(debug)write(6,*)'DN',EA,DDNOLD

      EA=EA+DDE
      DO EI=EA,EB,DDE

        CALL OUTWINB(REL,VR,RNET,DX,JRI,EI,FL,UDN,DUDN,node,ZZ)
        numcalls=numcalls+1
        if(debug)write(6,*)'DN',EI,DUDN
        DUTST = DDNOLD*DUDN
        DDNOLD = DUDN
!
!       Has the sign changed ?
        IF (DUTST .LT. 0.0D+0) then
                EIOUT=min(EI,EI-DDE)
                if(debug)write(6,*)'Sign Dn ',EIOUT,DDNOLD
                return
        endif
      enddo
      IFAIL=1
      return
      end
      Subroutine SearchUP(REL,VR,RNET,DX,JRI,FL,ZZ , &
        EIOUT, EI_Low, EI_High, Up, DE, numcalls, ifail, debug  )

      implicit real*8 (a-h,o-z)

      include 'param.inc'
!
      DOUBLE PRECISION   VR(*), RNET(NRAD)
      LOGICAL            REL, Up, debug

      IFAIL=0
      IF( UP )then
        DDE=DE
        EA=EI_LOW
        EB=EI_High
      ELSE
        DDE=-DE
        EA=EI_High
        EB=EI_Low
      ENDIF

      CALL OUTWINB(REL,VR,RNET,DX,JRI,EA,FL,UPOLD,DDNOLD,node,ZZ)
      if(debug)write(6,*)'UP',EA,UPOLD
      EA=EA+DDE
      DO EI=EA,EB,DDE

        CALL OUTWINB(REL,VR,RNET,DX,JRI,EI,FL,UUP,DUDN,node,ZZ)
        numcalls=numcalls+1
        if(debug)write(6,*)'UP',EI,UUP
!
        UTST = UPOLD*UUP
        UPOLD = UUP
!
!       Has the sign changed ?
        IF (UTST .LT. 0.0D+0) then
                EIOUT=min(EI,EI-DDE)
                if(debug)write(6,*)'Sign Up',EIOUT,UUP
                RETURN
        endif
      enddo
      IFAIL=1

      return
      end
