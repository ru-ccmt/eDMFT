     integer function global2local(ig,np,blocksize)

       integer ig,np,blocksize
       integer il


       li=(ig-1)/(np*blocksize)
       li=li*blocksize + mod(ig-1,blocksize) + 1

       global2local=li
              
     end function global2local
