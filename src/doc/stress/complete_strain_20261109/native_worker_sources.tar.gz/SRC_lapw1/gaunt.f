      REAL*8 FUNCTION GAUNT(L1,L2,L3,MM1,MM2,MM3)
      IMPLICIT REAL*8 (A-H,O-Z)
!     DATA FPI/12.56637061436D0/                
!     The following subroutines and functions are needed:
!     ph.f
!     t3j.f
!     t3j0.f
      parameter (FPI=4.D0*acos(-1.D0) )
      double precision :: FCT(100)
      Y=1.0D0
      DO I=1,49
         J=2*I-1
         FCT(J)=Y
         Y=Y*I
      END DO

      J1=2*L1
      J2=2*L2
      J3=2*L3
      M1=-2*MM1
      M2=2*MM2
      M3=2*MM3
!     FAC=(-1.D0)**MM1*SQRT( (J1+1)*(J2+1)*(J3+1)/FPI)                     
      FAC=SQRT(DBLE((J1+1)*(J2+1)*(J3+1))/FPI)
      IF( 2*(MM1/2) .ne. MM1)FAC=-FAC
      GAUNT=FAC*T3J0(J1,J2,J3,FCT)*T3J(J1,J2,J3,M1,M2,M3,FCT)
      RETURN
      END
