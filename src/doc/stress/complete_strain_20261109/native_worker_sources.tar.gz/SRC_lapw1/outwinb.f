      SUBROUTINE OUTWINB(REL,V,RNET,DH,JRI,EH,FL,VAL,SLO,Nodes,Z)
!         Integration der skalarrel. Schroedingergleichung
! ----------------------------------------------------------------
!  Input:
!    EH    Energie in Hartree 
!    FL    Drehimpuls 
!    Z     Kernladung
!    V     rad.sym. Potential in Hartree
!    RNOT  erster radialer Netzpunkt
!    DH    log. Schrittweite
!    JRI   Anzahl radialer Netzpunkte 
!  Output:
!    VAL,SLO:  Wellenfunktion und Steigung am Kugelrand
!    Nodes:    Anzahl Knoten
!    Radial:A,B,AP,BP: wave function arrays r*u(r) large, small component
!                                           r*u'(r) large, small component         
!
!    Rydberg Einheiten 
!
! ----------------------------------------------------------------
      use radial, only: A,B,AP,BP
      use TestCases
      IMPLICIT REAL*8 (a-h,o-z)

      include 'param.inc'

      DOUBLE PRECISION drdi, dh, sf, aa, r, det, b11, b22, phi
      DOUBLE PRECISION f0, df0, dg0, df1, df2, df3, dg1, dg2, dg3
      DOUBLE PRECISION rnet(NRAD), V(nrad), d(2,3)
      DOUBLE PRECISION u, y, x, s, val, fl, slo, z, eh, e
      DOUBLE PRECISION zz, c, fllp1
      INTEGER          k, nodes, jri, iiij
      logical          rel
!      DIMENSION        D(2,3),V(NRAD),RNET(NRAD)

!     Terms for 2nd-order (Trapezoid)
      real*8, parameter :: S1=1.D0, S83=2.D0, S83SQ=4.D0
!     Terms for 3rd-order Adams-Moulton
      Real*8, parameter :: T1=-1.D0/5.D0, T2=8.D0/5.D0, T83=12.D0/5.D0, T83SQ=144.D0/25.D0
!     Terms for 4th-order Adams-Moulton
      real*8, parameter :: R1=1.D0/9.D0, R2=-5.D0/9.D0, R3=19.D0/9.D0, H83=8.D0/3.D0, R83SQ = 64.D0/9.D0
!     Terms for 5th-order Adams-Moulton
      real*8, parameter :: E0=-19.D0/251.D0, E1 = 106.D0/251.D0, E2 = -264.D0/251.D0, E3 = 646.D0/251.D0, E83=720.D0/251.D0, E83SQ=E83*E83
!     Hartree in Ryd
      E=EH*2.d0

      Nodes = 0
      ZZ = Z + Z
     C = 2.d0 * 137.0359895d0
!
      if(.not.rel) C=1.D+10
!
      FLLP1 = FL*(FL + 1.d0)
!
      IF (Z .LT. 0.9D0) THEN
        S = FL+1.d0
        SF = FL
        F0 = FL/C
      ELSE
        AA = ZZ/C
        S = DSQRT(FLLP1 + 1.D0 - AA*AA)
        SF = S
        F0 = (S - 1.D0)/AA
      ENDIF
      DO  2  K = 1,3
!       Use small r expansion (Koelling & Harmon J. Phys. C: Solid state phys 1977
!         or Loucks Augmented plane wave Method 1967) to calculate A,B(1:3)
        R = RNET(K)
        DRDI = DH*R
        A(K) = (R**S)
        B(K) = (R**SF)*F0
        D(1,K) = DRDI*A(K)*S/R
        D(2,K) = DRDI*B(K)*SF/R
        AP(K) = A(K)*S/R - A(K)/R ! D(1,K)/DRDI - A(K)/R
        BP(K) = B(K)*SF/R - B(K)/R
    2 CONTINUE
!
!
      DG0 = 0.D0  
      DG1 = D(1,1)
      DG2 = D(1,2)
      DG3 = D(1,3)
      DF0 = 0.D0  
      DF1 = D(2,1)
      DF2 = D(2,2)
      DF3 = D(2,3)

      if(StartWin)then
!      Use derivatives (trapezoidal, 3rd order Adams-Moulton) to calculate A,B(2:3)
!      Properly start....
       DO  K = 2, 3
        R = RNET(K)
        DRDI = DH*R
!
!       Faktor zwei vor V wegen Hartree-Rydberg !
!
        PHI = (E - 2.d0*V(K)/R)*DRDI/C
        U = DRDI*C + PHI
        X = -DRDI/R
        Y = -FLLP1*X*X/U + PHI

!       Use 2nd & 3rd order methods
        if( K .eq. 2 )then
                DET = S83SQ - X*X + U*Y
                B11 = A(K-1)*S83 + S1*DG1
                B22 = B(K-1)*S83 + S1*DF1
                A(K) = (B11*(S83-X) + B22*U)/DET
                B(K) = (B22*(S83+X) - B11*Y)/DET
                DG2  = U*B(K) - X*A(K)
                DF2  = X*B(K) - Y*A(K)
                AP(K) = DG2/DRDI - A(K)/R
                BP(K) = DF2/DRDI - B(K)/R
        else if( K .eq. 3)then
                DET = T83SQ - X*X + U*Y
                B11 = A(K-1)*T83 + T1*DG1 + T2*DG2
                B22 = B(K-1)*T83 + T1*DF1 + T2*DF2
                A(K) = (B11*(T83-X) + B22*U)/DET
                B(K) = (B22*(T83+X) - B11*Y)/DET
                DG3  = U*B(K) - X*A(K)
                DF3  = X*B(K) - Y*A(K)
                AP(K) = DG3/DRDI - A(K)/R
                BP(K) = DF3/DRDI - B(K)/R
             endif

          enddo
    endif

      DO  4  K = 4, JRI
        R = RNET(K)
        DRDI = DH*R
!
!       Faktor zwei vor V wegen Hartree-Rydberg !
!
        PHI = (E - 2.d0*V(K)/R)*DRDI/C
        U = DRDI*C + PHI
        X = -DRDI/R
        Y = -FLLP1*X*X/U + PHI

!       Both 4th and 5th order available
        if( (K .eq. 4) .or. WinFour)then
                DET = R83SQ - X*X + U*Y
                B11 = A(K-1)*H83 + R1*DG1 + R2*DG2 + R3*DG3
                B22 = B(K-1)*H83 + R1*DF1 + R2*DF2 + R3*DF3
                A(K) = (B11*(H83-X) + B22*U)/DET
                B(K) = (B22*(H83+X) - B11*Y)/DET
        else
                DET =E83SQ - X*X + U*Y
                B11 = A(K-1)*E83 + E0*DG0 + E1*DG1 + E2*DG2 + E3*DG3
                B22 = B(K-1)*E83 + E0*DF0 + E1*DF1 + E2*DF2 + E3*DF3
                A(K) = (B11*(E83-X) + B22*U)/DET
                B(K) = (B22*(E83+X) - B11*Y)/DET
        endif

        IF (A(K)*A(K-1) .LT. 0D0) Nodes = Nodes + 1
        DG0 = DG1 
        DG1 = DG2
        DG2 = DG3
        DG3 = U*B(K) - X*A(K)
        AP(K) = DG3/DRDI - A(K)/R
        DF0 = DF1
        DF1 = DF2
        DF2 = DF3
        DF3 = X*B(K) - Y*A(K)
        BP(K) = DF3/DRDI - B(K)/R
        
    4 CONTINUE
!
!     
      do 120 iiij=1,JRI
         B(iiij)=B(iiij)*c/2.d0
         BP(iiij)=BP(iiij)*c/2.d0
 120  continue
!
      VAL = A(JRI)/RNET(JRI)
      SLO = DG3/(DH*RNET(JRI))
      SLO = (SLO-VAL)/RNET(JRI) 
      RETURN
      END

