!
      SUBROUTINE CHFAC(A,N)                                                     
      IMPLICIT REAL*8(A-H,O-Z)                                                  
      DIMENSION A(N,N+1)                                                        
      dimension work(20*N),C(N,N),IPIV(10)

      DO 10 I=1,N-1                                                             
      DO 10 J=I+1,N                                                             
   10 A(J,I)=A(I,J)                                                             
!     CALL AINV(A,N,1.D-14,IER,N)                                               
      LWORK=20*N                                                            
      call DSYTRF( 'U', N, A, N, IPIV, WORK, LWORK, INFO )
      call DSYTRI( 'U', N, A, N, IPIV, WORK, INFO )
      DO I=1,N-1
       DO J=I+1,N
        A(J,I)=A(I,J)
       enddo
      enddo
      RETURN                                                                    
      END                                                                       
