  subroutine c_alpha_m(c_matrix)
     implicit none
     complex*16         :: c_matrix(3,-1:1)
     complex*16, parameter :: imag  = (0.D0,1.d0)
     complex*16, parameter :: zeroc = (0.d0,0.d0)
     real*8, parameter     :: pi    = acos(-1.d0)
     real*8, parameter     :: two   = 2.D0
     real*8, parameter     :: three = 3.d0
     real*8, parameter     :: twopi = 2.D0*pi
    
       c_matrix(1,-1) = sqrt(twopi/three)
       c_matrix(1,0)  = zeroc
       c_matrix(1,1)  = -sqrt(twopi/three)

       c_matrix(2,-1) = imag*sqrt(twopi/three)    !our work doesn't have minus, kuppel does
       c_matrix(2,0)  = zeroc
       c_matrix(2,1)  = imag*sqrt(twopi/three)    !our work doesn't have minus, kuppel does

       c_matrix(3,-1) = zeroc
       c_matrix(3,0)  = sqrt(two*twopi/three)
       c_matrix(3,1)  = zeroc
  
  RETURN
  end subroutine c_alpha_m
  
      
  subroutine C_factor(ll,mm, c_ast_lm)
     !=====subroutine to calculate c_ast(l,m) which being used to calculate derivative of the spherical hermonics==========     
     implicit none
     integer,    intent(in)   :: ll,mm     
     complex*16, intent(out)  :: c_ast_lm(3,-1:1,-1:1)
     complex*16, parameter    :: zeroc = (0.d0,0.d0)
     complex*16, parameter    :: imag  = (0.D0,1.D0)
     integer,    parameter    :: one = 1.D0, two = 2.D0, three = 3.D0, f4r = 4.D0      
     integer                  :: index1, ss, tt, index, alpha, beta
     real*8                   :: delta(3,3), C1, C2, FF(6)

                    
     C1  = (ll-mm+one)*(ll-mm+two)
     C2  = f4r*(two*ll+one)*(two*ll+three)
     FF(1) = sqrt(C1/C2)

     C1 = (ll+mm-one)*(ll+mm)
     C2 = f4r*(two*ll-one)*(two*ll+one)
     FF(2) = sqrt(C1/C2)

     C1 = (ll+mm+one)*(ll+mm+two)
     C2 = f4r*(two*ll+one)*(two*ll+three)
     FF(3) = sqrt(C1/C2)

     C1 = (ll-mm-one)*(ll-mm)
     C2 = f4r*(two*ll-one)*(two*ll+one)
     FF(4) = sqrt(C1/C2)

     C1 = (ll+one)*(ll+one) - mm*mm
     C2 = (two*ll+one)*(two*ll+three)
     FF(5) = sqrt(C1/C2)

     C1 = ll*ll - mm*mm
     C2 = (two*ll-one)*(two*ll+one)
     FF(6) = sqrt(C1/C2)
     
                                                  
     delta  = 0
     DO alpha = 1, 3
        DO beta = 1, 3
           if(alpha .eq. beta) then
               delta(alpha,beta) = 1.d0
           else
               delta(alpha,beta) = 0.d0
           endif
        ENDDO
     ENDDO
     
     c_ast_lm(:,0,:) = zeroc
         
     DO alpha = 1, 3
           
        c_ast_lm(alpha,-1,-1) = -(ll+1)*(delta(alpha,1)+imag*delta(alpha,2))*FF(2)
        c_ast_lm(alpha,-1, 0) =  (ll+1)*delta(alpha,3)*FF(6)
        c_ast_lm(alpha,-1, 1) =  (ll+1)*(delta(alpha,1)-imag*delta(alpha,2))*FF(4)
              
        c_ast_lm(alpha, 1,-1) = -ll*(delta(alpha,1)+imag*delta(alpha,2))*FF(1)
        c_ast_lm(alpha, 1, 0) = -ll*delta(alpha,3)*FF(5)
        c_ast_lm(alpha, 1, 1) =  ll*(delta(alpha,1) - imag*delta(alpha,2))*FF(3)
                           
     ENDDO     
  return
  end subroutine C_factor


