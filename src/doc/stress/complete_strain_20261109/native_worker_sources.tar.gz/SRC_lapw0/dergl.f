!     Calculate the first derivate of f
!
      subroutine dergl(n,r,f,der1,even,g0)
!
!     Spline derivative, can be unstable at end points
!
      implicit real*8 (a-h,o-z)
!
      real*8 r(N), f(N), der1(N)
      real*8,allocatable  :: W1(:),W2(:),W3(:),W4(:),rw(:)
!
!     For origin corrections
      logical even, correct
!
       allocate (w1(-N+1:N),W2(-N+1:N),rw(-N+1:N),w3(-N+1:N),w4(-N+1:N))
       N2=2*N
       N0=-N+1
       rw(1:n)=r(1:n)
       w1(1:n)=f(1:n)
       if(.not.even)then
                do J=1,n
                        rw(-J+1)=-r(j)
                        w1(-J+1)=-f(J)
                enddo
        else
                do J=1,n
                        rw(-J+1)=-r(j)
                        w1(-J+1)= f(J)
                enddo
        endif
        call spline(n2,rw,w1,w2,w3,w4)
        DER1(1:N)=w2(1:N)

        G0=Der1(1)
!
      deallocate (w1,W2,rw,w3,w4)
      return
      end
