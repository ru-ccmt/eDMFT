      SUBROUTINE gpointm(spt,weight,npt1,LUSE)
!
!************************************************
!
!     Generate quadrature points for Vxc
!     This version anti-aliases and avoids sampling problems to the extent possible
!
!     There are four issues that need to be confronted:
!       1) The phi grid should not a multiple of the M harmonics. If it is then in
!          effect that harmonic is only sampled and Nphi/M points
!       2) The theta grid should also not be a multiple of the L harmonic, although
!          this is a weaker effect.
!       3) The sampling must be much larger than the input maximum L, particularly
!          for a GGA. The phi grid is more susceptible to aliasing effects. (The theta 
!          grid is a Gauss quadrature which is somewhat more resistant.)
!       4) The convergence of the individual Vxc harmonics is exponential, and can be
!          relatively slow.
!
!     The only way to do this in general seems to be if the theta and phi sampling is a 
!     number prime
!
!     Note:
!     Sampling and aliasing effect along phi can be severe
!     Sampling along theta is not so severe, but choosing a prime number helps
!     Numerical tests indicate that it is better to oversample phi by 3 w.r.t. theta
!     As a slight compromise, the numbers 11x11, 11x13 and 13x13 have been added to
!     the set of possible sizes.
!
!     Note 1: if there is ever a real need to include L=11 harmonics then remove the
!     multiples of 11.
!     Note 2: I don't like this code
!
!     L. D. Marks, March 2008
!
!************************************************
!
      use parallel, only: abort_parallel
      IMPLICIT REAL*8(A-H,O-Z)
!
      INCLUDE 'param.inc'
!
      dimension spt(3,nspd),weight(nspd)
      dimension z(nspd),w(nspd)
!
!     Prime numbers >= 7 up to 211, + 11*11, 11*13, 13*13
      dimension primes(47)
      data primes/7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79, &
        83,89,97,101,103,107,109,113,127,131,137,139,143,149,151,157,163,167,169, &
        173, 179,181,187,191,193,197,199,211/ 
      save primes
      REAL*8 SUM
!     
!     Constant
      PI=ACOS(-1.D0)

!     Check dimensions
      LBIG=min(LUSE+1,LMAX1D)
!
!     This is a fairly small limit, perhaps OK for normal lapw0
!     Probably should use 18 instead, to pick 19 points for theta
!     For -eece a bigger number, e.g. 30 is probably needed!
      LBIG=max(LBIG,10)
      
!     Find smallest prime number for theta > LBIG
      xthe=LBIG
      do J=1,46
             if(primes(j).lt.xthe)LBIG=primes(j+1)
      enddo

!     This trap is "OK", but not fully correct and may not catch everything
      IF(LBIG .gt. LMAX1D)then
        CALL OUTERR('LAPW0','Too large an L value for compiled LMAX1D')
        CALL OUTERR('LAPW0','Increase LMAX1D in param.inc or reduced harmonics')
        call abort_parallel
        STOP 'LAPW0 - Error. Check file lapw0.error.'
      ENDIF  

!     Changed to make iphi even, as PB noted force issue with odd numbers
!     Find smallest prime number for phi > 1.5*LBIG
      xphi=1.5*LBIG
      iphi=2*LBIG+1
      do J=1,46
             if(primes(j).lt.xphi)iphi=primes(j+1)
      enddo
      iphi=iphi*2
!
!     Now do a classic Gauss-Legendre quadrature
      NPT1=0
!     Setup z values and weights
      call gauleg(z,w,LBIG)
      PHISHIFT=exp(-4.D0)
      DO J=1,LBIG
        ZZ=Z(J)
        RXY=SQRT(1.D0-ZZ*ZZ)
        WW=W(J)/dble(IPHI)
        DO I=0,IPHI-1
                NPT1=NPT1+1
                PHI=PI*(DBLE(I*2)/DBLE(IPHI)+PHISHIFT)
                WEIGHT(NPT1)=WW
                SPT(1,NPT1)=COS(PHI)*RXY
                SPT(2,NPT1)=SIN(PHI)*RXY
                SPT(3,NPT1)=ZZ
        ENDDO
      ENDDO
!
      write(6,*)'Mod.Gauss-Legendre grid of ',NPT1, LBIG,' x ',IPHI
!
!     Renormalize the sum
      SUM=0.D0
      DO J=1,NPT1
        SUM=SUM+weight(j)
      enddo
      sum=4.D0*PI/sum
      do J=1,NPT1
        weight(j)=weight(j)*sum
!       write(6,666)j,spt(1,j),spt(2,j),spt(3,j),weight(j)
666     format(i5,3F12.8,E15.6)
      enddo
      return
      end
!

      SUBROUTINE gauleg(x,w,n)
!
!     Gauss-Legendre quadrature for theta values
!     Essentially the same as the older version
!
      implicit real*8 (a-h,o-z)
      INTEGER n
      REAL*8 x1,x2,x(n),w(n)
      DOUBLE PRECISION EPS,PI
      PARAMETER (EPS=3.d-14)
      INTEGER i,j,m
      DOUBLE PRECISION p1,p2,p3,pp,xl,xm,z,z1
      pi=acos(-1.D0)      
      m=(n+1)/2
      do i=1,m
        z=cos(PI*(dble(i)-0.25d0)/(dble(n)+0.5d0))
 1      continue
        p1=1.d0
        p2=0.d0
        do j=1,n
          p3=p2
          p2=p1
          p1=((2.d0*dble(j)-1.d0)*z*p2-(dble(j)-1.d0)*p3)/j
        end do
        pp=dble(n)*(z*p1-p2)/(z*z-1.d0)
        z1=z
        z=z1-p1/pp
        if(abs(z-z1).gt.EPS) goto 1
        x(i)=-z
        x(n+1-i)=+z
        w(i)=2.d0/((1.d0-z*z)*pp*pp)
        w(n+1-i)=w(i)
      end do
      return
      end

      SUBROUTINE gpointn(spt,weight,npt1,LUSE)
!
!************************************************
!
!     Generate quadrature points for Vxc
!     This version anti-aliases and avoids sampling problems to the extent possible
!
!     There are four issues that need to be confronted:
!       1) The phi grid should not a multiple of the M harmonics. If it is then in
!          effect that harmonic is only sampled and Nphi/M points
!       2) The theta grid should also not be a multiple of the L harmonic, although
!          this is a weaker effect.
!       3) The sampling must be much larger than the input maximum L, particularly
!          for a GGA. The phi grid is more susceptible to aliasing effects. (The theta 
!          grid is a Gauss quadrature which is somewhat more resistant.)
!       4) The convergence of the individual Vxc harmonics is exponential, and can be
!          relatively slow.
!
!     The only way to do this in general seems to be if the theta and phi sampling is a 
!     number prime
!
!     Note:
!     Sampling and aliasing effect along phi can be severe
!     Sampling along theta is not so severe, but choosing a prime number helps
!     Numerical tests indicate that it is better to oversample phi by 3 w.r.t. theta
!     As a slight compromise, the numbers 11x11, 11x13 and 13x13 have been added to
!     the set of possible sizes.
!
!     Note 1: if there is ever a real need to include L=11 harmonics then remove the
!     multiples of 11.
!     Note 2: I don't like this code
!
!     L. D. Marks, March 2008
!
!************************************************
!
      use parallel, only: abort_parallel
      IMPLICIT REAL*8(A-H,O-Z)
!
      INCLUDE 'param.inc'
!
      dimension spt(3,nspd),weight(nspd)
      dimension z(nspd),w(nspd)
!
!     Prime numbers >= 7 up to 211, + 11*11, 11*13, 13*13
      dimension primes(47)
      data primes/7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79, &
        83,89,97,101,103,107,109,113,127,131,137,139,143,149,151,157,163,167,169, &
        173, 179,181,187,191,193,197,199,211/ 
      save primes
      REAL*8 SUM
!     
!     Constant
      PI=ACOS(-1.D0)

!     Check dimensions
      LBIG=min(LUSE+1,LMAX1D)
!
!     This is a fairly small limit, perhaps OK for normal lapw0
!     Probably should use 18 instead, to pick 19 points for theta
!     For -eece a bigger number, e.g. 30 is probably needed!
      LBIG=max(LBIG,10)
      
!     Find smallest prime number for theta > LBIG
!     xthe=LBIG
!     do J=1,46
!            if(primes(j).lt.xthe)LBIG=primes(j+1)
!     enddo

!     This trap is "OK", but not fully correct and may not catch everything
      IF(LBIG .gt. LMAX1D)then
        CALL OUTERR('LAPW0','Too large an L value for compiled LMAX1D')
        CALL OUTERR('LAPW0','Increase LMAX1D in param.inc or reduced harmonics')
        call abort_parallel
        STOP 'LAPW0 - Error. Check file lapw0.error.'
      ENDIF  

!     Changed to use twice this (as PB noted that even values break forces)
!     Find smallest prime number for phi > 2*LBIG
!     xphi=2*LBIG
      iphi=2*LBIG
!     do J=1,46
!            if(primes(j).lt.xphi)iphi=primes(j+1)
!     enddo
!
!     Now do a classic Gauss-Legendre quadrature
      NPT1=0
!     Setup z values and weights
      call gauleg(z,w,LBIG)
      PHISHIFT=exp(-4.D0)
      DO J=1,LBIG
        ZZ=Z(J)
        RXY=SQRT(1.D0-ZZ*ZZ)
        WW=W(J)/dble(IPHI)
        DO I=0,IPHI-1
                NPT1=NPT1+1
                PHI=PI*(DBLE(I*2)/DBLE(IPHI)+PHISHIFT)
                WEIGHT(NPT1)=WW
                SPT(1,NPT1)=COS(PHI)*RXY
                SPT(2,NPT1)=SIN(PHI)*RXY
                SPT(3,NPT1)=ZZ
        ENDDO
      ENDDO
!
      write(6,*)'Mod.Gauss-Legendre grid of ',NPT1, LBIG,' x ',IPHI
!
!     Renormalize the sum
      SUM=0.D0
      DO J=1,NPT1
        SUM=SUM+weight(j)
      enddo
      sum=4.D0*PI/sum
      do J=1,NPT1
        weight(j)=weight(j)*sum
!       write(6,666)j,spt(1,j),spt(2,j),spt(3,j),weight(j)
666     format(i5,3F12.8,E15.6)
      enddo
      return
      end
!

      SUBROUTINE gpointv(spt,weight,npt1,LUSE)
!
!
      use parallel, only: abort_parallel
      IMPLICIT REAL*8(A-H,O-Z)
!
      INCLUDE 'param.inc'
!
      dimension spt(3,nspd),weight(nspd)
      dimension z(nspd),w(nspd)
!
!     Prime numbers >= 7 up to 211, + 11*11, 11*13, 13*13
      dimension primes(47)
      data primes/7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79, &
        83,89,97,101,103,107,109,113,127,131,137,139,143,149,151,157,163,167,169, &
        173, 179,181,187,191,193,197,199,211/ 
      save primes
      REAL*8 SUM
!     
!     Constant
      PI=ACOS(-1.D0)

      open(unit=79,file='Mesh')
      read(79,*,err=10,end=10)LBIG,IPHI
      goto 20
10    continue
!     Check dimensions
      LBIG=min(LUSE+1,LMAX1D)
!
!     This is a fairly small limit, perhaps OK for normal lapw0
!     Probably should use 18 instead, to pick 19 points for theta
!     For -eece a bigger number, e.g. 30 is probably needed!
      LBIG=max(LBIG,10)
      
!     Find smallest prime number for theta > LBIG
!     xthe=LBIG
!     do J=1,46
!            if(primes(j).lt.xthe)LBIG=primes(j+1)
!     enddo

!     This trap is "OK", but not fully correct and may not catch everything
      IF(LBIG .gt. LMAX1D)then
        CALL OUTERR('LAPW0','Too large an L value for compiled LMAX1D')
        CALL OUTERR('LAPW0','Increase LMAX1D in param.inc or reduced harmonics')
        call abort_parallel
        STOP 'LAPW0 - Error. Check file lapw0.error.'
      ENDIF  

!     Find smallest prime number for phi > 2*LBIG
      xphi=2*LBIG
      iphi=2*LBIG
      do J=1,46
             if(primes(j).lt.xphi)iphi=primes(j+1)
      enddo
!
!     Now do a classic Gauss-Legendre quadrature
20    NPT1=0
!     Setup z values and weights
      call gauleg(z,w,LBIG)
      PHISHIFT=exp(-4.D0)
      DO J=1,LBIG
        ZZ=Z(J)
        RXY=SQRT(1.D0-ZZ*ZZ)
        WW=W(J)/dble(IPHI)
        DO I=0,IPHI-1
                NPT1=NPT1+1
                PHI=PI*(DBLE(I*2)/DBLE(IPHI)+PHISHIFT)
                WEIGHT(NPT1)=WW
                SPT(1,NPT1)=COS(PHI)*RXY
                SPT(2,NPT1)=SIN(PHI)*RXY
                SPT(3,NPT1)=ZZ
        ENDDO
      ENDDO
!
      write(6,*)'Mod.Gauss-Legendre grid of ',NPT1, LBIG,' x ',IPHI
!
!     Renormalize the sum
      SUM=0.D0
      DO J=1,NPT1
        SUM=SUM+weight(j)
      enddo
      sum=4.D0*PI/sum
      do J=1,NPT1
        weight(j)=weight(j)*sum
!       write(6,666)j,spt(1,j),spt(2,j),spt(3,j),weight(j)
!666     format(i5,3F12.8,E15.6)
      enddo
      return
      end
!

