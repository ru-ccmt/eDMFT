      subroutine rhopw(rhok,yka,ABSK,Rhopw0r,jrjstart,jrj,rhopw0,l,index)
      IMPLICIT REAL*8     (A-H,O-Z)
      COMPLEX*16 rhok,yka,rhopw0(*)
      real*8 rhopw0r(*),bes(13)
      do i=jrjstart,jrj+index
        ARG=Rhopw0r(i)*ABSK
        CALL SPHBES(l+2,ARG,BES)
        rhopw0(i)= rhopw0(i) + rhOK*BES(l+1)*YKA
      enddo
      return
      end


