! ** 
! ** 
! **                                                   September 4, 2014
! ** Dear Colleague, 
! ** 
! ** 
! ** Please find below the routines for our new PBE-type functional, 
! ** acGGA, designed with the intention of proper correlation and exchange 
! ** energies
! ** 
! ** For most purposes, it should yield energies very close to those of
! ** PBE, but significantly outperforms it for heavier elements.  
! ** 
! -----------------------------------------------------------------
! acGGA:
! asymptotically correct generalized gradient approximation to the
! density functional for exchange-correlation energy of a many-electron
! system.
!
! This applies a small modification of the PBE routine, primarily but
! not exclusively affecting large-Z atoms.  Users who experience --large--
! changes from the PBE, please consult accancio@bsu.edu or kieron@uci.edu. 
!  --------------------------------------------------------------------
! Note: Neglects small grad (zeta) contributions to the correlation
! energy.
!
! Programs implement functional in BCGP paper, September 2014. 
!  see arxiv.org/abs/1409.4834.
! 
!----------------------------------------------------------------------
      subroutine acggac(up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap, &
                 agr,delgr,lcor,lpot,ecpbe,vcuppbe,vcdnpbe)
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! EASYPBE is a driver for the PBE subroutines, using simple inputs
! K. Burke, May 14, 1996.
! inputs: up=up density
!        : agrup=|grad up|
!        : delgrup=(grad up).(grad |grad up|) 
!        : uplap=grad^2 up=Laplacian of up
!        : dn,agrdn,delgrdn,dnlap=corresponding down quantities
!        : agr=|grad rho|
!        : delgr=(grad rho).(grad |grad rho|) 
!        : lcor=flag to do correlation(=0=>don't)
!        : lpot=flag to do potential(=0=>don't)
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! needed constants:
! pi32=3 pi**2
! alpha=(9pi/4)**thrd
      implicit real*8(a-h,o-z)
      parameter(thrd=1.d0/3.d0,thrd2=2.d0*thrd)
      parameter(pi32=29.608813203268075856503472999628d0)
      parameter(pi=3.1415926535897932384626433832795d0)
      parameter(alpha=1.91915829267751300662482032624669d0)
!----------------------------------------------------------------------
! Now do correlation
! zet=(up-dn)/rho
! g=phi(zeta)
! rs=(3/(4pi*rho))^(1/3)=local Seitz radius=alpha/fk
! sk=Ks=Thomas-Fermi screening wavevector=sqrt(4fk/pi)
! twoksg=2*Ks*phi
! t=correlation dimensionless gradient=|grad rho|/(2*Ks*phi*rho)
! uu=delgrad/(rho^2*twoksg^3)
! rholap=Laplacian
! vv=Laplacian/(rho*twoksg^2)
! ww=(|grad up|^2-|grad dn|^2-zet*|grad rho|^2)/(rho*twoksg)^2
! ec=lsd correlation energy
! vcup=lsd up correlation potential
! vcdn=lsd down correlation potential
! h=gradient correction to correlation energy
! dvcup=gradient correction to up correlation potential
! dvcdn=gradient correction to down correlation potential
      rho=up+dn
      if(rho.lt.1.d-18)return
      zet=(up-dn)/rho
      g=((1.d0+zet)**thrd2+(1.d0-zet)**thrd2)/2.d0
      fk=(pi32*rho)**thrd
      rs=alpha/fk
      sk=sqrt(4.d0*fk/pi)
      twoksg=2.d0*sk*g
      t=agr/(twoksg*rho)
      uu=delgr/(rho*rho*twoksg**3)
      rholap=uplap+dnlap
      vv=rholap/(rho*twoksg**2)
      ww=(agrup**2-agrdn**2-zet*agr**2)/(rho*rho*twoksg**2)
      call CORacgga(RS,ZET,T,UU,VV,WW,1,lpot,ec,vcup,vcdn, &
                        H,DVCUP,DVCDN)
      ecpbe=ec+h
      vcuppbe=vcup+dvcup
      vcdnpbe=vcdn+dvcdn
      return
      end
!----------------------------------------------------------------------
!######################################################################
!----------------------------------------------------------------------
      SUBROUTINE coracgga(RS,ZET,T,UU,VV,WW,lgga,lpot, &
                        ec,vcup,vcdn,H,DVCUP,DVCDN)
!----------------------------------------------------------------------
!  Official PBE correlation code. K. Burke, May 14, 1996.
!  INPUT: RS=SEITZ RADIUS=(3/4pi rho)^(1/3)
!       : ZET=RELATIVE SPIN POLARIZATION = (rhoup-rhodn)/rho
!       : t=ABS(GRAD rho)/(rho*2.*KS*G)  -- only needed for PBE
!       : UU=(GRAD rho)*GRAD(ABS(GRAD rho))/(rho**2 * (2*KS*G)**3)
!       : VV=(LAPLACIAN rho)/(rho * (2*KS*G)**2)
!       : WW=(GRAD rho)*(GRAD ZET)/(rho * (2*KS*G)**2
!       :  UU,VV,WW, only needed for PBE potential
!       : lgga=flag to do gga (0=>LSD only)
!       : lpot=flag to do potential (0=>energy only)
!  output: ec=lsd correlation energy from [a]
!        : vcup=lsd up correlation potential
!        : vcdn=lsd dn correlation potential
!        : h=NONLOCAL PART OF CORRELATION ENERGY PER ELECTRON
!        : dvcup=nonlocal correction to vcup
!        : dvcdn=nonlocal correction to vcdn
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! References:
! [a] J.P.~Perdew, K.~Burke, and M.~Ernzerhof, 
!     {\sl Generalized gradient approximation made simple}, sub.
!     to Phys. Rev.Lett. May 1996.
! [b] J. P. Perdew, K. Burke, and Y. Wang, {\sl Real-space cutoff
!     construction of a generalized gradient approximation:  The PW91
!     density functional}, submitted to Phys. Rev. B, Feb. 1996.
! [c] J. P. Perdew and Y. Wang, Phys. Rev. B {\bf 45}, 13244 (1992).
! [d] K. Burke, A. Cancio, T. Gould, S. Pittalis, arxiv.org/abs/1409.4834
!----------------------------------------------------------------------
!----------------------------------------------------------------------
      IMPLICIT REAL*8 (A-H,O-Z)
! thrd*=various multiples of 1/3
! numbers for use in LSD energy spin-interpolation formula, [c](9).
!      GAM= 2^(4/3)-2
!      FZZ=f''(0)= 8/(9*GAM)
! numbers for construction of PBE
!      gamm=(1-log(2))/pi^2
!      bet=coefficient in gradient expansion for correlation, [a](4).
!      eta=small number to stop d phi/ dzeta from blowing up at 
!          |zeta|=1.
      parameter(thrd=1.d0/3.d0,thrdm=-thrd,thrd2=2.d0*thrd)
      parameter(sixthm=thrdm/2.d0)
      parameter(thrd4=4.d0*thrd)
      parameter(GAM=0.5198420997897463295344212145565d0)
      parameter(fzz=8.d0/(9.d0*GAM))
      parameter(gamm=0.03109069086965489503494086371273d0)
      parameter(bet=0.06672455060314922d0,delt=bet/gamm)
      parameter(eta=1.d-12)
!Cancio
! version of ACPBE:
!     icflag = 0  -- original PBE
!     icflag = 1  -- hu-langreth(rs) correction
!     icflag = 2  -- P(t^2) correction
!     icflag = 3  -- hu-langreth(rs)*P(t^2)
!     icflag = 4  -- P(t) more asymptotically correct model
!     icflag = 5  -- hu-langreth(rs)*P(t) 
!
      parameter(icflag=4)
!Cancio
      external gcor2, hulatpss, pfuncburke, pfuncbrkalt, &
           pfunccanbrk, fcpbe

!----------------------------------------------------------------------
!----------------------------------------------------------------------
! find LSD energy contributions, using [c](10) and Table I[c].
! EU=unpolarized LSD correlation energy
! EURS=dEU/drs
! EP=fully polarized LSD correlation energy
! EPRS=dEP/drs
! ALFM=-spin stiffness, [c](3).
! ALFRSM=-dalpha/drs
! F=spin-scaling factor from [c](9).
! construct ec, using [c](8)
      rtrs=dsqrt(rs)
      CALL gcor2(0.0310907D0,0.21370D0,7.5957D0,3.5876D0,1.6382D0, &
          0.49294D0,rtrs,EU,EURS)
      CALL gcor2(0.01554535D0,0.20548D0,14.1189D0,6.1977D0,3.3662D0, &
          0.62517D0,rtRS,EP,EPRS)
      CALL gcor2(0.0168869D0,0.11125D0,10.357D0,3.6231D0,0.88026D0, &
          0.49671D0,rtRS,ALFM,ALFRSM)
      ALFC = -ALFM
      Z4 = ZET**4
      F=((1.D0+ZET)**THRD4+(1.D0-ZET)**THRD4-2.D0)/GAM
      EC = EU*(1.D0-F*Z4)+EP*F*Z4-ALFM*F*(1.D0-Z4)/FZZ
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! LSD potential from [c](A1)
! ECRS = dEc/drs [c](A2)
! ECZET=dEc/dzeta [c](A3)
! FZ = dF/dzeta [c](A4)
      ECRS = EURS*(1.D0-F*Z4)+EPRS*F*Z4-ALFRSM*F*(1.D0-Z4)/FZZ
      FZ = THRD4*((1.D0+ZET)**THRD-(1.D0-ZET)**THRD)/GAM
      ECZET = 4.D0*(ZET**3)*F*(EP-EU+ALFM/FZZ)+FZ*(Z4*EP-Z4*EU &
              -(1.D0-Z4)*ALFM/FZZ)
      COMM = EC -RS*ECRS/3.D0-ZET*ECZET
      VCUP = COMM + ECZET
      VCDN = COMM - ECZET
      if(lgga.eq.0)return
!----------------------------------------------------------------------
!----------------------------------------------------------------------

!Cancio -- modifications for Ec atomic project 
! variables
!      hula = an rs-correction to beta
!      pfunc = an t2-correction to beta or t2?
!      dhula = dhula/drs
!      dpfunc = dpfunc/dt2, etc.
! functions
!      hulatpss = TPSS model for Hu-Langreth correction
!      pfuncburke = old BCGP14 model for P(t)
!      pfuncbrkalt = BCGP14 model for P(t)
!
      t2 = t*t
      if ( icflag .eq. 0 ) then
           hula= 1.d0
           dhula = 0.d0
           pfunc = 1.d0
           dpfunc = 0.d0
           d2pfunc = 0.d0
      elseif ( icflag .eq. 1 ) then
           pfunc = 1.d0
           dpfunc = 0.d0
           d2pfunc = 0.d0
           call hulatpss(rs, hula, dhula)
      elseif ( icflag .eq. 2 ) then
           hula = 1.d0
           dhula = 0.d0
           call pfuncburke(0, t2, pfunc, dpfunc, d2pfunc)
      elseif ( icflag .eq. 3 ) then
           call hulatpss(rs, hula, dhula)
           call pfuncburke(1, t2, pfunc, dpfunc, d2pfunc)
      elseif ( icflag .eq. 4 ) then
           hula = 1.d0
           dhula = 0.d0
           call pfuncbrkalt(0, t2, pfunc, dpfunc, d2pfunc)
      elseif ( icflag .eq. 5 ) then
           call hulatpss(rs, hula, dhula)
           call pfuncbrkalt(1, t2, pfunc, dpfunc, d2pfunc)
!      elseif ( icflag .eq. 6 ) then
!           call hulatpss(rs, hula, dhula)
!           G=((1.d0+ZETA)**thrd2+(1.d0-ZETA)**thrd2)/2.d0
!           G3 = G**3
!           PON=-EC0/(G3*gamm)
!           B = delt/(EXP(PON)-1.D0)
!           call pfunccanbrk(1, t2, B, pfunc, dpfunc, d2pfunc)
      endif
!
! basic trick of acGGA is to consider beta in PBE correlation to be 
! a function of rs and t, and likewise delt = beta/gamm, and do 
! this everywhere in the following PBE routine.
!
      deltfunctional = delt*hula*pfunc
      betfunctional = gamm*deltfunctional
!EndCancio


!c----------------------------------------------------------------------
!c----------------------------------------------------------------------
! PBE correlation energy
! G=phi(zeta), given after [a](3)
! deltfunctional=bet(rs,t)/gamm, using variable rs, t of ACPBE
! B=A of [a](8)
      G=((1.d0+ZET)**thrd2+(1.d0-ZET)**thrd2)/2.d0
      G3 = G**3
      PON=-EC/(G3*gamm)
      B = deltfunctional/(DEXP(PON)-1.D0)
      B2 = B*B
      T2 = T*T
      T4 = T2*T2
      RS2 = RS*RS
      RS3 = RS2*RS
      Q4 = 1.D0+B*T2
      Q5 = 1.D0+B*T2+B2*T4
      H = G3*(betfunctional/deltfunctional)* &
           DLOG(1.D0+deltfunctional*Q4*T2/Q5)
      if(lpot.eq.0)return
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! ENERGY DONE. NOW THE POTENTIAL, using appendix E of [b].
      G4 = G3*G
      T6 = T4*T2
      RSTHRD = RS/3.D0
      GZ=(((1.d0+zet)**2+eta)**sixthm- &
      ((1.d0-zet)**2+eta)**sixthm)/3.d0
      FAC = deltfunctional/B+1.D0
      BG = -3.D0*B2*EC*FAC/(betfunctional*G4)
      BEC = B2*FAC/(betfunctional*G3)
      Q8 = Q5*Q5+deltfunctional*Q4*Q5*T2
      Q9 = 1.D0+2.D0*B*T2
      hB = -betfunctional*G3*B*T6*(2.D0+B*T2)/Q8
      hRS = -RSTHRD*hB*BEC*ECRS
      FACT0 = 2.D0*deltfunctional-6.D0*B
      FACT1 = Q5*Q9+Q4*Q9*Q9
      hBT = 2.D0*betfunctional*G3*T4* &
           ((Q4*Q5*FACT0-deltfunctional*FACT1)/Q8)/Q8
      hRST = RSTHRD*T2*hBT*BEC*ECRS
      hZ = 3.D0*GZ*h/G + hB*(BG*GZ+BEC*ECZET)
      hT = 2.d0*betfunctional*G3*Q9/Q8
      hZT = 3.D0*GZ*hT/G+hBT*(BG*GZ+BEC*ECZET)
      FACT2 = Q4*Q5+B*T2*(Q4*Q9+Q5)
      FACT3 = 2.D0*B*Q5*Q9+deltfunctional*FACT2
      hTT = 4.D0*betfunctional*G3*T*(2.D0*B/Q8-(Q9*FACT3/Q8)/Q8)
! zeta independent
      COMM = H+HRS+HRST+T2*HT/6.D0+7.D0*T2*T*HTT/6.D0
! sign dependent
      PREF = HZ-GZ*T2*HT/G
! zeta dependent
      FACT5 = GZ*(2.D0*HT+T*HTT)/G
      COMM = COMM-PREF*ZET-UU*HTT-VV*HT-WW*(HZT-FACT5)
      DVCUP = COMM + PREF
      DVCDN = COMM - PREF
! *******************************************************
! optional test to see if H, HT, HTT, HTRS are done correctly above,
! within new functional.
!      include 'reverseengineer' 
! ********************************************************
! acGGA correction:
! add functional derivatives with delta(rs,t):
!
!c Cancio:
! set up my preferred variable list: 
!
      prefactor = gamm*g3
      call fcpbe( b*t2, fc, fcx, fcxx )

      y = deltfunctional*t2*fc
!     alth = prefactor*dlog(1.d0+y)
      hy = prefactor/(1.d0+y)
      hyy = -prefactor/(1.d0+y)**2

! no sense to convert from P(t) to P(t2) back to P(t) but specs 
! keep changing.  remove later on.
      dpfuncdt = (2*t)*dpfunc
      d2pfuncdt2 = (4*t2)*d2pfunc + 2*dpfunc

!     deltfunctional = delt*pfuncrs*pfunc
      delt_rs = delt*dhula*pfunc
      delt_t = delt*hula*dpfuncdt
      delt_rst = delt*dhula*dpfuncdt
      delt_tt = delt*hula*d2pfuncdt2
!
! from here on out, del --> short for deltfunctional(rs,t)
! 
!    h = prefactor*dlog(1 + y)
!    y = delt*t2*fc(x)
!    x = b*t^2
!    b = deltfunctional / (exp(PON) - 1)
!
! partial derivs of x
!    xt = 2*b*t = 2*x/t
!    xrs = t^2 (partial b) / (partial rs) = t2*bec*ecrs
!    xdel = x/deltfunctional 
!
! partials of y
!    yrs = (partial y) / (partial rs) holding delta and t fixed.
!    ydel = (partial y) / (partial del) holding t and rs (outside of del) fixed.
! partials of h
!    hy = dh/dy
!
      x = t2*b
      xrs = t2*bec*ecrs
      xz = t2*(BG*GZ+BEC*ECZET)

      yrs = deltfunctional*t2*xrs*fcx
      yz  = deltfunctional*t2*xz*fcx
      yt = 2*deltfunctional*t*(fc + x*fcx)
      ydel = t2*(fc + x*fcx)
      yrsdel = t2*xrs*(2*fcx + x*fcxx)    
      yzdel  = t2*xz*(2*fcx + x*fcxx)
      ytdel = 2*t*(fc + 3*x*fcx + x*x*fcxx)
      ydel2 = (t2/deltfunctional) * (2*x*fcx + x*x*fcxx)
!
! partial derivatives of h, ht, hrs, hzeta with respect to 
!     del(rs,t) = beta(rs)P(t)/gamm
!
      hdel = hy*ydel
      hdel2 = hyy*ydel*ydel + hy*ydel2
      htdel = hyy*ydel*yt + hy*ytdel
      hrsdel = hyy*ydel*yrs + hy*yrsdel
      hzdel = hyy*ydel*yz + hy*yzdel + (3.d0*GZ/G)*hdel

! overall changes in various partial derivatives of h:
!
!    delta_hrs = change in (partial h)/(partial rs) because of P(t)beta(rs)
!    delta_ht = change in (partial h)/(partial t) because of P(t)beta(rs)
!
      delta_hrs = hdel*delt_rs
      delta_z = 0.d0
      delta_ht = hdel*delt_t
      delta_hrst = htdel*delt_rs + hrsdel*delt_t + &
           hdel2*delt_t*delt_rs + hdel*delt_rst
      delta_hzt = hzdel*delt_t
      delta_htt = 2.0d0*htdel*delt_t + hdel2*delt_t*delt_t + & 
           hdel*delt_tt
      varht = delta_ht/t
      varhzt = delta_hzt/t
      varhtt = delta_htt - varht

! ** put all spin-independent corrections in
      delcomm = - rsthrd*delta_hrs + rsthrd*t*delta_hrst + &
           t2*varht/6.D0 + 7.D0*t2*varhtt/6.D0
      delcomm = delcomm - UU*varhtt/t - VV*varht

! ** spin-polarization corrections:
! term in appendix E with a sign(spin) in it.
      delpref = -(GZ/G)*t*delta_ht
! term with phi'/phi as prefactor in appendix E
      delfact5 = (GZ/G)*(2.D0*varht + varhtt)
! total zeta dependent
      delcomm = delcomm - delpref*ZET - WW*(varhzt - delfact5)

! ** total potential includes a spin switch term.
      dvcup = dvcup + delcomm + delpref
      dvcdn = dvcdn + delcomm - delpref

      RETURN
      END
!----------------------------------------------------------------------
!######################################################################
!----------------------------------------------------------------------
      SUBROUTINE GCOR2(A,A1,B1,B2,B3,B4,rtrs,GG,GGRS)
! slimmed down version of GCOR used in PW91 routines, to interpolate
! LSD correlation energy, as given by (10) of
! J. P. Perdew and Y. Wang, Phys. Rev. B {\bf 45}, 13244 (1992).
! K. Burke, May 11, 1996.
      IMPLICIT REAL*8 (A-H,O-Z)
      Q0 = -2.D0*A*(1.D0+A1*rtrs*rtrs)
      Q1 = 2.D0*A*rtrs*(B1+rtrs*(B2+rtrs*(B3+B4*rtrs)))
      Q2 = DLOG(1.D0+1.D0/Q1)
      GG = Q0*Q2
      Q3 = A*(B1/rtrs+2.D0*B2+rtrs*(3.D0*B3+4.D0*B4*rtrs))
      GGRS = -2.D0*A*A1*Q2-Q0*Q3/(Q1*(1.d0+Q1))
      RETURN
      END

!----------------------------------------------------------------------
!######################################################################
!----------------------------------------------------------------------

      subroutine hulatpss(rs, fhula, fphula)
!
! Implements revTPSS correction to Beta in Hc of PBE.
!
      implicit none
      double precision rs, fhula, fphula

      double precision one, bnum, bdenom
      parameter (one=1.0d0, bnum=0.1d0, bdenom=0.1778d0)

      double precision denominator

      denominator = one + bdenom*rs
      fhula = (one + bnum*rs)/denominator
      fphula = (bnum - bdenom) / denominator**2

      return
      end
!----------------------------------------------------------------------
!######################################################################
!----------------------------------------------------------------------

      subroutine pfuncburke(icflag, t2, pfunc, dpfunc, d2pfunc)
!
! Implements revised PBE correction to Beta in Hc of PBE.
!  corrects rs=0, t--> infinity limit with Burke model:
!       beta t^2 --> beta * f(t) * t^2
! Variables: 
!  icflag -- model without/with Hu-Langreth correction
!  t2 -- t^2
!  pfunc = f(t2)
!  dpfunc = f'(t2)   (first derivative)
!  d2pfunc = f''(t2) (second derivative)
!
      implicit none
      integer icflag
      double precision t2, pfunc, dpfunc, d2pfunc

      double precision one, bnum, bdenom2, bdenom3
!      parameter (one=1.0d0, bnum=0.1d0, bdenom=0.23d0)
      parameter (one=1.0d0, bnum=0.1d0, bdenom2=0.1638d0, &
           bdenom3=0.1515d0)

      double precision denominator, bdenom

! kludge to handle multiple ac options.
      if ( icflag .eq. 0 ) then
          bdenom = bdenom2
      else
          bdenom = bdenom3
      endif
      denominator = one + bdenom*t2
      pfunc = (one + bnum*t2)/denominator
      dpfunc = (bnum - bdenom) / denominator**2
      d2pfunc = -2*bdenom*dpfunc / denominator

      return
      end

!----------------------------------------------------------------------
!######################################################################
!----------------------------------------------------------------------

      subroutine pfuncbrkalt(icflag, t2, pfunc, dpfunc, d2pfunc)
!
! Implements re-revised PBE correction to Beta in Hc of PBE.
! As of kn8_20.pdf.
!
!  corrects rs=0, t--> infinity limit with Burke model:
!       beta t^2 --> beta * f(t) * t^2
!  with f(t) given by
!
!       f(t) = (1 + eta*t)/(1 + C*eta*t)
!
! Variables: 
!  icflag -- model without/with Hu-Langreth correction
!  t2 -- t^2
!  pfunc = f(t2)
!  dpfunc = f'(t2)   (first derivative)
!  d2pfunc = f''(t2) (second derivative)
!
      implicit none
      integer icflag
      double precision t2, pfunc, dpfunc, d2pfunc

      double precision one, onehalf, bnum, bdenom4, bdenom5
      parameter (one=1.0d0, onehalf=0.5d0)
!      parameter (bnum=one/4.5d0, bdenom=2.4683d0*bnum)
      parameter (bnum=one/4.5d0, bdenom4=1.467d0*bnum, &
           bdenom5=1.370d0*bnum)

      double precision t, dtdx, d2tdx2, bdenom, denominator, f, fp, fpp

! convert from function of t2 expected in PBE to function of t
      t = dsqrt(t2)
      dtdx = onehalf/t
      d2tdx2 = -onehalf*dtdx/t2

! kludge to handle multiple ac options.
      if ( icflag .eq. 0 ) then
          bdenom = bdenom4
      else
          bdenom = bdenom5
      endif

! function and derivatives with respect to t
      denominator = one + bdenom*t
      f = (one + bnum*t)/denominator
      fp = (bnum - bdenom) / denominator**2
      fpp = -2*bdenom*fp / denominator

! chain derivatives
      pfunc = f
      dpfunc = fp*dtdx
      d2pfunc = fpp*dtdx*dtdx + fp*d2tdx2

      return
      end
!----------------------------------------------------------------------
!######################################################################
!----------------------------------------------------------------------

      subroutine pfunccanbrk(icflag, t2, A, pfunc, dpfunc, &
           d2pfunc)
!
! Implements re-revised PBE correction to Beta in Hc of PBE.
! As of kn8_20.pdf.
!
!  corrects rs=0, t--> infinity limit with Burke model:
!       beta t^2 --> beta * f(t) * t^2
!  with f(t) given by
!
!       f(t) = (1 + eta*t)/(1 + C*eta*t)
!
! Variables: 
!  icflag -- model without/with Hu-Langreth correction
!  t2 -- t^2
!  A -- A(rs) of the PBE
!  pfunc = f(t2)
!  dpfunc = f'(t2)   (first derivative)
!  d2pfunc = f''(t2) (second derivative)
!
      implicit none
      integer icflag
      double precision t2, pfunc, dpfunc, d2pfunc
      double precision A

      double precision one, onehalf, bnum, bdenom, fdenom
      parameter (one=1.0d0, onehalf=0.5d0)
      parameter (bnum=one/4.5d0, bdenom=2.4683d0*bnum, fdenom=3.0d0)
!      parameter (bnum=one/4.5d0, bdenom=1.467d0*bnum)

      double precision t, dtdx, d2tdx2, denominator, f, fp, fpp
      double precision bdenomfactor

! convert from function of t2 expected in PBE to function of t
      t = dsqrt(t2)
      dtdx = onehalf/t
      d2tdx2 = -onehalf*dtdx/t2

      bdenomfactor = bdenom*(one + fdenom*A)/(one + bdenom*fdenom*A)
! function and derivatives with respect to t
      denominator = one + bdenomfactor*t
      f = (one + bnum*t)/denominator
      fp = (bnum - bdenomfactor) / denominator**2
      fpp = -2*bdenomfactor*fp / denominator

! chain derivatives
      pfunc = f
      dpfunc = fp*dtdx
      d2pfunc = fpp*dtdx*dtdx + fp*d2tdx2

      return
      end
!----------------------------------------------------------------------
!######################################################################
!----------------------------------------------------------------------

      subroutine fcpbe(x, fc, fcx, fcxx)
!
! Implements PBE Pade factor in Hc of PBE.
!   x = A*t^2
!   fc = pade(x)
!   fcx = dfc/dx
!   fcxx = d^2fc/dx^2
!
      implicit none
      double precision x, fc, fcx, fcxx

      double precision one, two
      parameter (one=1.0d0, two=2.0d0)

      double precision numer, denom, ddenom

      numer = one + x
      denom = one + x + x*x
      ddenom = one + two*x
      fc = numer/denom
      fcx = (one - fc*ddenom)/denom
!      dfcx = (one - fc)/denom - two*fc*fc - fcx
      fcxx = -two*(fc + ddenom*fcx)/denom
!      dfcxx = 

      return
      end
