      function id_func_get(xc_switch)

      implicit none

      integer :: i, id_func_get
      character(len=*), intent(in) :: xc_switch
      character*80 :: parseline, tmp1, tmp2

      id_func_get = -1

      rewind(63)

      do
         read(63,'(a)',end=10) parseline
         do i=1, len(parseline)-len(trim(xc_switch))
            if (parseline(i:i+len(trim(xc_switch))) .eq. xc_switch//' ') then
               read(parseline,*) tmp1, tmp2, id_func_get
               goto 10
            endif
         enddo
      enddo

  10  continue

      end function id_func_get
