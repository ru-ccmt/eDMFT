      subroutine optb86b(up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap, &
                         exup,exdn,vxup,vxdn)

!J. Klimes et al., Phys. Rev. B 83, 195131 (2011).

      implicit none

      real*8, intent(in) :: up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap
      real*8, intent(out) :: exup,exdn,vxup,vxdn
      real*8 :: fk,pi32,rho2,s,thrd,u,v

      parameter(thrd=1.d0/3.d0)
      parameter(pi32=3d0*(4d0*atan(1d0))**2)

      rho2=2.d0*up
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrup/(2.d0*fk*rho2)
        u=4.d0*delgrup/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*uplap/(rho2*(2.d0*fk)**2)
        call exchoptb86b(rho2,s,u,v,exup,vxup)
      else
        exup=0.d0
        vxup=0.d0
      endif
      
      rho2=2.d0*dn
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrdn/(2.d0*fk*rho2)
        u=4.d0*delgrdn/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*dnlap/(rho2*(2.d0*fk)**2)
        call exchoptb86b(rho2,s,u,v,exdn,vxdn)
      else
        exdn=0.d0
        vxdn=0.d0
      endif

      return
      end

!-----------------------------------------------------------------------

      subroutine exchoptb86b(rho,s,u,v,ex,vx)

      implicit none

      real*8, intent(in) :: rho,s,u,v
      real*8, intent(out) :: ex,vx
      real*8 :: ax, exunif, fs, fss, fx, mu, s2, thrd, thrd4

      parameter(thrd=1.d0/3.d0,thrd4=4.d0/3.d0)
      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(mu=0.1234d0)

! construct lda exchange energy density
      exunif = ax*rho**thrd

! construct optB86b enhancement factor
      s2 = s*s

      fx = 1d0 + mu*s2/(1d0 + mu*s2)**(4d0/5d0)

      ex = exunif*fx
!  energy done. now the potential:
!  find first and second derivatives of fx w.r.t s.
!  fs=(1/s)*d fx/ ds
!  fss=d fs/ds

      fs = 2d0*mu*(1d0 + 1d0/5d0*mu*s2)/(1d0 + mu*s2)**(9d0/5d0)

      fss = -16d0/5d0*mu**2*s*(2d0 + 1d0/5d0*mu*s2)/(1d0 + mu*s2)**(14d0/5d0)

      vx = exunif*(thrd4*fx-(u-thrd4*s2*s)*fss-v*fs)

      return
      end
