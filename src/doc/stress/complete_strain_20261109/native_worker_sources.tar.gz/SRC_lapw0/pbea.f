      subroutine PBEA(up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap, &
                      exuppbea,exdnpbea,vxuppbea,vxdnpbea)

!G. K. H. Madsen, Phys. Rev. B 75, 195108 (2007).

      implicit real*8(a-h,o-z)
      parameter(thrd=1.d0/3.d0,thrd2=2.d0*thrd)
      parameter(pi32=29.608813203268075856503472999628d0)

      rho2=2.d0*up
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrup/(2.d0*fk*rho2)
        u=4.d0*delgrup/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*uplap/(rho2*(2.d0*fk)**2)
        call exchpbea(rho2,s,u,v,exuppbea,vxuppbea)
      else
        exuppbea=0.d0
        vxuppbea=0.d0
      endif
      
      rho2=2.d0*dn
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrdn/(2.d0*fk*rho2)
        u=4.d0*delgrdn/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*dnlap/(rho2*(2.d0*fk)**2)
        call exchpbea(rho2,s,u,v,exdnpbea,vxdnpbea)
      else
        exdnpbea=0.d0
        vxdnpbea=0.d0
      endif

      return
      end

!-----------------------------------------------------------------------

      SUBROUTINE EXCHPBEA(rho,S,U,V,EX,VX)

      USE xcparam, only : XC1

      IMPLICIT REAL*8 (A-H,O-Z)
      parameter(thrd=1.d0/3.d0,thrd4=4.d0/3.d0)
      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(CKAPPA=0.804D0, CMU=0.21951D0)

! construct LDA exchange energy density
      exunif = AX*rho**THRD

! construct PBEA enhancement factor
      S2 = S*S

      IF (DABS(XC1) .LE. 1D-12) THEN
        FxPBEA = 1D0
      ELSE
        FxPBEA = 1D0 + CKAPPA*(1D0 - 1D0/(1D0 + CMU*S2/(CKAPPA*XC1))**XC1)
      ENDIF

      EX = exunif*FxPBEA

!  ENERGY DONE. NOW THE POTENTIAL:
!  find first and second derivatives of Fx w.r.t s.
!  Fs=(1/s)*d FxPBEA/ ds
!  Fss=d Fs/ds

      IF (DABS(XC1) .LE. 1D-12) THEN
        FS = 0D0
        FSS = 0D0
      ELSE
        FS = 2D0*CMU/(1D0 + CMU*S2/(CKAPPA*XC1))**(XC1+1D0)
        FSS = -4D0*(CMU*CMU/CKAPPA)*((XC1+1D0)/XC1)*S/ &
              (1D0 + CMU*S2/(CKAPPA*XC1))**(XC1+2D0)
      ENDIF

      VX = exunif*(THRD4*FxPBEA-(U-THRD4*S2*S)*FSS-V*FS)

      RETURN
      END
