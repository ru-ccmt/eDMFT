      subroutine lb94(rho,grho,vxlb94)

!R. van Leeuwen and E. J. Baerends, Phys. Rev. A 49, 2421 (1994).

      implicit none

      real*8 :: beta, pi, x
      real*8, intent(in) :: rho, grho
      real*8, intent(out) :: vxlb94

      parameter(beta=0.05d0,pi=4.0d0*atan(1d0))

      x = grho/rho**(4.0d0/3.0d0)

      vxlb94 = -(6.0d0*rho/pi)**(1.0d0/3.0d0) - &
         beta*rho**(1.0d0/3.0d0)*x**2/(1.0d0 + 3.0d0*beta*x*asinh(x))

      return

      end
