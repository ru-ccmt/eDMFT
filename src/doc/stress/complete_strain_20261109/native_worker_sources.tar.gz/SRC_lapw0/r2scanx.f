      subroutine r2scanx(rhoup,gmagup,tauup,rhodn,gmagdn,taudn,exup,exdn)

!J. W. Furness et al., J. Phys. Chem. Lett. 11, 8208 (2020).

      implicit none

      real*8, intent(in) :: rhoup, gmagup, tauup, rhodn, gmagdn, taudn

      real*8, intent(out) :: exup, exdn

      if (rhoup .gt. 1d-18) then
         call exr2scanx(rhoup,gmagup,tauup,exup)
      else
         exup = 0d0
      endif

      if (rhodn .gt. 1d-18) then
         call exr2scanx(rhodn,gmagdn,taudn,exdn)
      else
         exdn = 0d0
      endif

      return

      end

!-----------------------------------------------------------------------

      subroutine exr2scanx(rho,gmag,tau,ex)

      implicit none

      real*8, intent(in) :: rho, gmag, tau

      real*8, intent(out) :: ex

      real*8 :: a1, alpha, ax, c2x, dx, exlda, &
         fxa, fxsa, gx, hx0, hx1, k1, muak, pi, s, tautf, tauw, x, &
         c0, c1, c2, c3, c4, c5, c6, c7, eta, ceta, c2xnew, dp2

      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(pi=3.1415926535897932384626433832795d0)
      parameter(k1=0.065d0)
      parameter(muak=10d0/81d0)
      parameter(a1=4.9479d0)
      parameter(c2x=0.8d0)
      parameter(dx=1.24d0)
      parameter(hx0=1.174d0)
      parameter(c0=1d0,c1=-0.667d0,c2=-0.4445555d0,c3=-0.663086601049d0, &
         c4=1.451297044490d0,c5=-0.887998041597d0,c6=0.234528941479d0, &
         c7=-0.023185843322d0)
      parameter(eta=1d-3)
      parameter(ceta=20d0/27d0+eta*5d0/3d0)
      parameter(c2xnew=-0.162742d0)
      parameter(dp2=0.361d0)

      exlda = ax*(2d0*rho)**(1d0/3d0)

      s = gmag/((3d0*pi**2)**(1d0/3d0)*(2d0*rho)**(4d0/3d0))

      tautf = 0.6d0*(6d0*pi**2)**(2d0/3d0)*rho**(5d0/3d0)

      tauw = 0.25d0*gmag**2/rho

      alpha = (max(2d0*tau,tauw) - tauw)/(tautf + eta*tauw)

      x = (ceta*c2xnew*exp(-s**4/dp2**4) + muak)*s**2

      if (alpha .lt. 2.5d0) then
         fxa = c0 + c1*alpha + c2*alpha**2 + c3*alpha**3 + c4*alpha**4 + &
            c5*alpha**5 + c6*alpha**6 + c7*alpha**7
      elseif (alpha .ge. 2.5d0) then
         fxa = -dx*exp(c2x/(1d0-alpha))
      endif

      if (s .gt. 1d-18) then
         gx = 1d0 - exp(-a1/s**(1d0/2d0))
      else
         gx = 1d0
      endif

      hx1 = 1d0 + k1 - k1/(1d0 + x/k1)

      fxsa = (hx1 + fxa*(hx0 - hx1))*gx

      ex = exlda*fxsa

      return

      end
