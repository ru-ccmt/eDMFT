      subroutine pbeint(up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap, &
          exuppbeint,exdnpbeint,vxuppbeint,vxdnpbeint)

!E. Fabiano, L. A. Constantin, and F. Della Sala, Phys. Rev. B 82, 113104 (2010)

      implicit real*8(a-h,o-z)
      parameter(thrd=1.d0/3.d0,thrd2=2.d0*thrd)
      parameter(pi32=29.608813203268075856503472999628d0)

      rho2=2.d0*up
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrup/(2.d0*fk*rho2)
        u=4.d0*delgrup/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*uplap/(rho2*(2.d0*fk)**2)
        call exchpbeint(rho2,s,u,v,exuppbeint,vxuppbeint)
      else
	exuppbeint=0.d0
	vxuppbeint=0.d0
      endif

      rho2=2.d0*dn
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrdn/(2.d0*fk*rho2)
        u=4.d0*delgrdn/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*dnlap/(rho2*(2.d0*fk)**2)
        call exchpbeint(rho2,s,u,v,exdnpbeint,vxdnpbeint)
      else
	exdnpbeint=0.d0
	vxdnpbeint=0.d0
      endif

      return
      end

!----------------------------------------------------------------------

      SUBROUTINE EXCHPBEINT(rho,S,U,V,EX,VX)

      IMPLICIT REAL*8 (A-H,O-Z)
      parameter(thrd=1.d0/3.d0,thrd4=4.d0/3.d0)
      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(alpha=0.197d0,uk=0.8040d0)
      parameter(umge2=10.0d0/81.0d0,umpbe=0.2195149727645171d0)

! construct LDA exchange energy density
      exunif = AX*rho**THRD

! construct PBEint enhancement factor
      s2 = s*s
      um = umge2 + (umpbe - umge2)*alpha*s2/(1.0d0 + alpha*s2)
      FxPBEint = 1.0d0 + uk - uk/(1.0d0 + um*s2/uk)
      EX = exunif*FxPBEint

!  ENERGY DONE. NOW THE POTENTIAL:
!  find first and second derivatives of Fx w.r.t s.
!  Fs=(1/s)*d FxPBEint/ ds
!  Fss=d Fs/ds

      ump = (umpbe - umge2)*2.0d0*alpha*s/(1.0d0 + alpha*s2)**2

      ump2 = (umpbe - umge2)*2.0d0*alpha*(1.0d0 - 3.0d0*alpha*s2)/ &
         (1.0d0 + alpha*s2)**3

      Fs = (s*ump + 2.0d0*um)/(1.0d0 + um*s2/uk)**2

      Fss = (3.0d0*ump + s*ump2 - 5.0d0/uk*s2*um*ump + s**3*um*ump2/uk - &
         2.0d0*s**3*ump**2/uk - 8.0d0/uk*s*um**2)/(1.0d0 + um/uk*s2)**3

      VX = exunif*(THRD4*FxPBEint-(U-THRD4*S2*s)*FSS-V*FS)

      RETURN
      END
