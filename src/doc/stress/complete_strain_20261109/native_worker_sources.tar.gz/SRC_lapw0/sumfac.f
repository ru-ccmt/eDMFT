      SUBROUTINE SUMFAC(LLMM,YY,IND,LM,LMMAX)
!                                                                       
      use parallel, only: abort_parallel
      use norm_kub, only: c_kub  
      IMPLICIT REAL*8 (A-H,O-Z)
!
      INCLUDE 'param.inc'
!
      INTEGER     :: LM(2,NCOM+3)
      DIMENSION YY(NCOM,nspd),C(7)                                       

!      sqrt2=SQRT(2.d0)

      llmm=0
      i=1
      DO
         IF(i.gt.lmmax) EXIT
         IF(lm(1,i).EQ.0.AND.lm(2,i).EQ.0) THEN
            llmm=llmm+1
            yy(llmm,ind)=yy(i,ind)
            i=i+1
         ELSEIF (lm(1,i).EQ.-3.AND.lm(2,i).EQ.2) THEN  
            llmm=llmm+1
            yy(llmm,ind)=yy(i,ind)
            i=i+1
         ELSEIF (lm(1,i).EQ.4.OR.lm(1,i).EQ.6.OR. &
                 lm(1,i).EQ.-7.OR.lm(1,i).EQ.-9 ) THEN  
            llmm=llmm+1
            yy(llmm,ind)=c_kub(abs(lm(1,i)),lm(2,i))*yy(i,ind)  &
                       + c_kub(abs(lm(1,i)),lm(2,i)+4)*yy(i+1,ind)
            i=i+2
         ELSEIF (lm(1,i).EQ.8.OR.lm(1,i).EQ.10) THEN 
            llmm=llmm+1
            yy(llmm,ind)=c_kub(lm(1,i),lm(2,i))*yy(i,ind) + &
                          c_kub(lm(1,i),lm(2,i)+4)*yy(i+1,ind) +  &
                          c_kub(lm(1,i),lm(2,i)+8)*yy(i+2,ind) 
            i=i+3
         ELSE
            WRITE(6,*) 'UNCORRECT LM LIST FOR CUBIC STRUCTURE'
            call abort_parallel
            STOP
         ENDIF
      END DO
      RETURN                                                            
      END                                                               
