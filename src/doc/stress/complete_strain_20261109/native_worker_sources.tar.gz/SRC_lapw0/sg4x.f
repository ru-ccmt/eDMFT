      subroutine sg4x(up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap, &
                      exup,exdn,vxup,vxdn)

!L. A. Constantin et al., Phys. Rev. B 93, 045126 (2015).

      implicit none

      real*8, intent(in) :: up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap
      real*8, intent(out) :: exup,exdn,vxup,vxdn
      real*8 :: fk,pi32,rho2,s,thrd,u,v

      parameter(thrd=1.d0/3.d0)
      parameter(pi32=3d0*(4d0*atan(1d0))**2)

      rho2=2.d0*up
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrup/(2.d0*fk*rho2)
        u=4.d0*delgrup/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*uplap/(rho2*(2.d0*fk)**2)
        call exchsg4(rho2,s,u,v,exup,vxup)
      else
        exup=0.d0
        vxup=0.d0
      endif
      
      rho2=2.d0*dn
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrdn/(2.d0*fk*rho2)
        u=4.d0*delgrdn/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*dnlap/(rho2*(2.d0*fk)**2)
        call exchsg4(rho2,s,u,v,exdn,vxdn)
      else
        exdn=0.d0
        vxdn=0.d0
      endif

      return
      end

!-----------------------------------------------------------------------

      subroutine exchsg4(rho,s,u,v,ex,vx)

      implicit none

      real*8, intent(in) :: rho,s,u,v
      real*8, intent(out) :: ex,vx
      real*8 :: ax, exunif, fs, fss, fx, k1, k2, mk1, mk2, mu1, mu2, &
        mumge2, numge4, s2, thrd, thrd4

      parameter(thrd=1.d0/3.d0,thrd4=4.d0/3.d0)
      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(mumge2=0.26d0)
      parameter(numge4=-0.195d0)
      parameter(mu1=0.042d0)
      parameter(mu2=mumge2-mu1)
      parameter(k2=-mu2**2/numge4)
      parameter(k1=0.804d0-k2)
      parameter(mk1=mu1/k1)
      parameter(mk2=mu2/k2)

! construct lda exchange energy density
      exunif = ax*rho**thrd

! construct CAP enhancement factor
      s2 = s*s

      fx = 1d0 + k1 + k2 - k1*(1d0-mk1*s2)/(1d0-(mk1*s2)**5) - k2/(1d0+mk2*s2)

      ex = exunif*fx
!  energy done. now the potential:
!  find first and second derivatives of fx w.r.t s.
!  fs=(1/s)*d fx/ ds
!  fss=d fs/ds

      fs = -k1*(-2d0*mk1 - 8d0*mk1**6*s**10 + 10d0*mk1**5*s**8)/ &
        (1d0-(mk1*s2)**5)**2 + 2d0*mu2/(1d0+mk2*s2)**2

      fss = -k1*( &
        (-80d0*mk1**6*s**9 + 80d0*mk1**5*s**7)*(1d0-mk1**5*s**10)**2 + &
        (-2d0*mk1 - 8d0*mk1**6*s**10 + 10d0*mk1**5*s**8)*20d0*(1d0 - mk1**5*s**10)*mk1**5*s**9 &
        )/(1d0-(mk1*s2)**5)**4 - 8d0*mu2*mk2*s/(1d0+mk2*s2)**3

      vx = exunif*(thrd4*fx-(u-thrd4*s2*s)*fss-v*fs)

      return
      end
