      SUBROUTINE XCPOT1Q (luse2,LM,JATOM,LMMAX,LR2V,JSPIN,sigmaj,&
                         imfield,bextene,iprint,switch1)
!      use efeld
      use struct
      use densit
      use work
      use vresp1
      use parallel, only :nstart,nstop,myid
      USE xcparam
!                                                                       
!     XCPOT1 CALCULATES THE EXCHANGE-CORRELATION POTENTIAL INSIDE       
!     THE SPHERES.                                                      
!     AFTER SUMATION OF  CHARGE DENSITY  BY CLM(R) FOR TEN  THETA       
!     VALUES PER MESH-POINT, THE ( CUBIC ) HARMONIC-EXPANSION  OF       
!     EXCHANGE-POTENTIAL IS GENERATED AND STORED IN ARRAY VEX.
!                                                                       
!                                                                       
      IMPLICIT REAL*8 (A-H,O-Z)
!
      INCLUDE 'param.inc'
!

      REAL*8         :: sigmaj(2)
      COMPLEX*16           YL,dyt,dyt2,dyp,dyp2,dytp         
      LOGICAL           LR2V, robfit, spin,nospin, debug
!for fit
!      REAL*8            AA2(NCOM,NCOM),WSPACE(NCOM)
!      DIMENSION         KPVT(NCOM) 
!
      DIMENSION         YY(NCOM,nspd)
      REAL*8            bbu(NCOM),bbbu(NCOM),bbd(NCOM),          &
                        bbbd(NCOM), tmp1, tmp2, tmp3, tmp4
!      DIMENSION         spt_vxcu(nspd),spt_excu(nspd),spt_vxcd(nspd), &
!                        spt_excd(nspd)
!                                                                       
      DIMENSION  YL((lmax2X+1)*(lmax2X+1))
      DIMENSION  LM(2,NCOM+3,NAT),LMMAX(NAT)         
      DIMENSION  A2(3),ROTA1(3) !,RINV(3,3)
!
!
      dimension spt(3,nspd),weight(nspd), &
                vxcsu(nspd),vxcsd(nspd), &
                vxu(nspd),vxd(nspd),exu(nspd),exd(nspd), &
                dcsp(ncom,nrad,2),ddcsp(ncom,nrad,2), &
                dyt((lmax2X+1)*(lmax2X+1)),dyt2((lmax2X+1)*(lmax2X+1)), &
                dyp((lmax2X+1)*(lmax2X+1)),dyp2((lmax2X+1)*(lmax2X+1)), &
                dytp((lmax2X+1)*(lmax2X+1)), &
                dydt(ncom,nspd),dydt2(ncom,nspd), &
                dydp(ncom,nspd),dydp2(ncom,nspd),dydtp(ncom,nspd), &
                qrhou(ncom),qrhod(ncom), &
                qsin(nspd),qcos(nspd) !, qyy(ncom)
       integer quadtest
!      COMMON /phil/ dcsp,ddcsp

!      DATA THRD/0.3333333333333333D0/
       parameter (thrd=1.D0/3.D0, debug=.false. )
       parameter (CutMuffin=1D-8)  !-12)
!                                                                       
!      *** Variables for Alternative Mode, density weighted fit ***
       real*8,allocatable :: rhoval(:), matval(:,:), work1(:), work2(:), rhs(:,:)
       integer,allocatable:: iwork(:)
!      logical AltMode
!
!      ***** EECE Patching *****
       real*8 du_h(nspd), dd_h(nspd), tmpup(nspd), tmpdn(nspd)
       logical UseLM(ncom), UseInterp, UseLDA, there, EECE_SWITCH
       character*6 EECE_Show
       character*5 switch1
       UseInterp= .false.
       UseLDA   = .false.
       EECE_SWITCH=.false.
       if(switch1.eq.' EECE') EECE_SWITCH=.true.
       if(switch1.eq.' HYBR') EECE_SWITCH=.true.

!      AltMode=.true.
       if(EECE_SWITCH)then

!       Experimental Options
        inquire(file='EECE_LDA',exist=there)
        if(there)UseLDA=.true.
        inquire(file='EECE_INT',exist=there)
        if(there)UseInterp=.true.

       endif

       UseLM=.true.
       write(6,'(a)' )'Note: Using XCPOT1Q'
       if(EECE_SWITCH)then
        iatj = IATNR( JATOM )   
!       Set odd values to zero
        do L=1,LMMAX( JATOM )
                LL=IABS(LM(1,L,JATOM)) 
                if( 2*(LL/2) .ne. LL) UseLM(L)=.false.
!       Cubic -3,2
                if(iatj.GT.0)then
                        if(lm(1,L,jatom).EQ.-3.AND.lm(2,L,jatom).EQ.2)UseLM(L)=.true.
                endif
!               write(6,*)L,LL,LM(1:2,L,JATOM),UseLM(L)
        enddo
       endif
!
!       **** EECE End ****

       dmaxup=0
       dmaxdn=0
       sigmamaxup=0.d0
       sigmamaxdn=0.d0
       irsigmaup = jri(jatom)
       irsigmadn = jri(jatom)

!      Spin simplifications
        if(jspin .eq. 2)then
                spin=.true.
        else
                spin=.false.
        endif
!       Debug
        if(debug)spin=.true.
        nospin=.not. spin
!---------------------------------------------------------------------  
!.....DEFINE CONSTANTS, INITIALIZE VARIABLES 
      IF(.NOT.ALLOCATED(vclmsp)) allocate(vclmsp(1:nrad,1:lmmaxx,nstart(myid):nstop(myid),1:2))
         pi=acos(-1.d0)
         pi2=2*pi
         rpi=sqrt(pi)
         rtpi=sqrt(4.D0*pi)
         pisq=pi*pi
         wnorm=4.D0*pi
       1980 FORMAT(3X)                                                        
        iatest=-1

 2000 FORMAT(16X,I2//)                                                  
 2010 FORMAT(16X,I2,5X,I2/)                                             
 2020 FORMAT(3X,5E13.7)                                                 
 2021 FORMAT(3X,4E19.12)                                                 
 2030 FORMAT(///)                                                       
 2031 FORMAT(/)                                                         
!                                                                       
!                                                                       
!fit      aa2=0.d0
      NCOMX=NCOM                                                        
!      PI=ACOS(-1.D0)                                                    
      TPI=2.D0*PI                                                       
      SQFPI=1.D0/rtpi                                                
      PIST=PI/36.D0                                                     
      PIN=PI/9.D0-1.D-10
      PI4=PI*0.25D0                                                  
!
      INDEX=1
      DO J=1,JATOM-1
        INDEX=INDEX+MULT(J)
      ENDDO
!     WARNING: LLMM is used here as a dummy, but sumfac replaces it
      LLMM=LMMAX( JATOM )
      iatj = IATNR( JATOM )                                                 
!************************************************
!
!     generates Gauss-Legendre points on sphere
!
      quadtest = 0
      LUSE=LUSE2
      if(LUSE .gt. 100)then
        quadtest=LUSE/100
        LUSE = LUSE - quadtest*100
      endif
!       LUSE=abs(LUSE)
!      luse=max(luse,abs(luse2))
      do L=1,LLMM
        LUSE=MAX(LUSE,abs(lm(1,L,JATOM)))
      enddo               
      luse=min(luse,lmax2X) 
!print*,'luse,luse2,quadtest',luse,luse2,quadtest
!     Some alternatives -- not useful
!      if (quadtest .eq. 1)then
!         call gpointn(spt,weight,npt1,LUSE)
!      else if (quadtest .eq. 2)then
!         call gpointv(spt,weight,npt1,LUSE)
!      else 
      if(luse2.ge.0) then     !1.11.2010. use gpoint by default, gpointm breaks forces symmetry
         call gpoint(spt,weight,npt1,LUSE)
      else
         call gpointm(spt,weight,npt1,LUSE)
      endif
!-----------
!     Since EECE is symmetric, only need half the points
      if( EECE_SWITCH .and.( 2*(npt1/2) .eq. npt1) )then
        npt1=npt1/2
        weight(1:npt1)=weight(1:npt1)*2.0D0
      endif
!-----------
!     Note, we don't need LUSE later to be big
      LUSE=0
      do LM1=1,LLMM
        luse = max( iabs(LM(1,LM1,JATOM)), luse)
      enddo
      LUse=LUse+2

      Sum0 = 0.D0
      do 1 ind=1,npt1
         rota1(1)=spt(1,ind)
         rota1(2)=spt(2,ind)
         rota1(3)=spt(3,ind)
         CALL YLM (ROTA1,luse,YL)                                          
!
         if(GGA_SWITCH.eqv..true.) then
         call dylm(rota1,luse,yl,dyt,dyt2,dyp,dyp2,dytp,qsin(ind),qcos(ind))
         endif
!
         DO 3 LM1=1,LMMAX(JATOM)                                             
          CALL SUML(LM1,YY(LM1,IND),YL,LM(1,1,JATOM))                      
 3       CONTINUE                                                          
!
         sum0 = sum0 + YY(1,ind)*weight(ind)

         if(GGA_SWITCH.eqv..true.) then
         do 1001 lm1=1,LMMAX(JATOM)
          call suml(lm1,dydt(lm1,ind),dyt,lm(1,1,jatom))
          call suml(lm1,dydt2(lm1,ind),dyt2,lm(1,1,jatom))
          call suml(lm1,dydp(lm1,ind),dyp,lm(1,1,jatom))
          call suml(lm1,dydp2(lm1,ind),dyp2,lm(1,1,jatom))
          call suml(lm1,dydtp(lm1,ind),dytp,lm(1,1,jatom))
 1001    continue
         endif       
!        
         IF(iatj.GT.0.AND.LLMM.GT.1) THEN                  
!        WARNING: LLMM is overwritten for cubic to be the number of unique combinations
         CALL SUMFAC(llmm,YY,IND,LM(1,1,jatom),LMMAX(JATOM))
!
!         if(iex.gt.10) then
         if(GGA_SWITCH.eqv..true.) then
         call sumfac(llmm,dydt,ind,LM(1,1,jatom),LMMAX(JATOM))
         call sumfac(llmm,dydt2,ind,LM(1,1,jatom),LMMAX(JATOM))
         call sumfac(llmm,dydp,ind,LM(1,1,jatom),LMMAX(JATOM))
         call sumfac(llmm,dydp2,ind,LM(1,1,jatom),LMMAX(JATOM))
         call sumfac(llmm,dydtp,ind,LM(1,1,jatom),LMMAX(JATOM))
         endif
!        
         ENDIF                                                             
!
  1   CONTINUE
!                                                                       
!========================================================
!         derivatives dCLM/dR and ddCLM/ddR
!========================================================
      if(GGA_SWITCH.eqv..true.) then
         call dfundr(jatom,jri(jatom),lmmax(jatom),clmsp,dcsp,ddcsp,spin,LM)
      end if
!========================================================
!
!     Alt mode. Setup sizes for arrays later used for the fits
!     if(AltMode)then
        
!       Reduce number for EECE modes
        LLMMU=0
        DO L=1,LMMAX(JATOM)
                if(UseLM(L))LLMMU=LLMMU+1
        enddo
        if(allocated(rhoval)) &
                deallocate(rhoval, matval, work1, work2, rhs, iwork )
        allocate(matval(NPT1,LLMMU) , rhoval(npt1) )
        allocate(work1(LLMMU))
        NRHS=2
        if(spin)NRHS=4
        allocate(rhs(npt1,nrhs) )
!
!       Find out sizes to use
        LWORK=2
        RCOND=1D-12
        allocate(work2(LWORK),IWORK(LWORK))
        LWORK=-1
        call DGELSD(NPT1,LLMMU, NRHS, MatVal, NPT1 , RHS, NPT1, work1, &
                RCOND, IRANK, WORK2, LWORK, IWORK, INFO)
!
!       Use 1024 larger, probably not needed. 1024 for I should be OK
        LWORK=nint(work2(1)) + 1024
        I    =1024
        deallocate(work2,iwork)
        allocate(work2(LWORK),IWORK(I))

!     endif
!
!     LOOP OVER ALL RADIAL MESH POINTS                                  
!
      init=1
!
      DO 34 ir=1,JRI(JATOM)                                               
!
!if(ir.lt.20) print*,r(ir),dcsp(1,ir,1),ddcsp(1,ir,1)
!if(ir.gt.JRI(JATOM)-20) print*,r(ir),dcsp(1,ir,1),ddcsp(1,ir,1)
       bbu=0.0D0
       bbbu=0.0D0
       if(spin)then
        bbd=0.0D0
        bbbd=0.0D0
       endif
!
       rp=r(ir)
       rpp=1.D0/(r(ir)*r(ir))
!
       DO 77 k=1,npt1

        qrhou(1:LMMAX(JATOM))=clmsp(ir,1:LMMAX(JATOM),jatom,1)
        if(spin)qrhod(1:LMMAX(JATOM))=clmsp(ir,1:LMMAX(JATOM),jatom,2)
        call srolyl(qrhou,qrhod,yy(1,k),sqfpi,iatj,llmm, &
                    fu,fd,ft,LM(1,1,jatom),LMMAX(JATOM),nospin)
!
!       Store the density for larger use
        rhoval(k)=ft

        ft=ft*RPP
        fu=fu*RPP
        fd=fd*RPP
!
        if(VRESP_SWITCH.eqv..true.) then

         qrhou(1:LMMAX(JATOM))=vclmsp(ir,1:LMMAX(JATOM),jatom,1)
         if(spin)qrhod(1:LMMAX(JATOM))=vclmsp(ir,1:LMMAX(JATOM),jatom,2)

        call srolyl(qrhou,qrhod,yy(1,k),sqfpi,iatj,llmm, &
                    tauup,taudn,tautot,LM(1,1,jatom),LMMAX(JATOM),nospin)
        tautot=-tautot*RPP
        tauup=-tauup*RPP
        taudn=-taudn*RPP

         qrhou(1:LMMAX(JATOM))=v(ir,1:LMMAX(JATOM),jatom)
         if(spin)qrhod(1:LMMAX(JATOM))=v(ir,1:LMMAX(JATOM),jatom)
         qrhou(1)=qrhou(1)*RTPI
         if(spin)qrhod(1)=qrhod(1)*RTPI
        call srolyl(qrhou,qrhod,yy(1,k),sqfpi,iatj,llmm, &
                    vhup,vhdn,vhtot,LM(1,1,jatom),LMMAX(JATOM),nospin)
!.......v was not multiplied with r**2
        if ((VX_SWITCH(1:7) .eq. 'VX_GLLB') .or. (EX_SWITCH(1:12) .eq. 'EX_DELTAGLLB')) then
           tautot=-tautot
           tauup=-tauup
           taudn=-taudn
        else
           tautot=tautot-vhtot*ft
           tauup=tauup -vhup*fu
           taudn=taudn -vhdn*fd
        endif
        endif
!
!--------------------------------
!        if (iex .eq. 28 .or. iex .eq. 30) then
        if((VX_SWITCH.eq.'VX_BR89') .or. (VX_SWITCH.eq.'VX_SLATER') .or. &
           (VX_SWITCH.eq.'VX_MBJ') .or. (VX_SWITCH.eq.'VX_SMBJ') .or. &
           (VX_SWITCH.eq.'VX_GBJ') .or. (VX_SWITCH.eq.'VX_KLI') .or. &
           (VX_SWITCH.eq.'VX_R2V') .or. (VDISP_SWITCH.eq.'VDISP_NLVDW') .or. &
           (VHALF_SWITCH.ne.'VHALF_NONE') .or. (VX_SWITCH.eq.'VX_LMBJ') .or. &
           (id_func_x .eq. 207) .or. (id_func_x .eq. 208) .or. (id_func_x .eq. 209)) then

          qrhou(1:LMMAX(JATOM)) = vxcold(ir,1:LMMAX(JATOM),jatom,1)
          if (spin) qrhod(1:LMMAX(JATOM)) = vxcold(ir,1:LMMAX(JATOM),jatom,2)

          call srolyl(qrhou,qrhod,yy(1,k),1d0,iatj,llmm, &
                      vxuold,vxdold,vxtold,LM(1,1,jatom),LMMAX(JATOM),nospin)

          vxuold = vxuold*rpp
          vxdold = vxdold*rpp

        endif

        if((VX_SWITCH.eq.'VX_SLATER') .or. (VX_SWITCH.eq.'VX_SMBJ') .or. &
           (VX_SWITCH.eq.'VX_KLI') .or. (EX_SWITCH(1:12).eq.'EX_DELTAGLLB') .or. &
           (VX_SWITCH.eq.'VX_LMBJ')) then

          qrhou(1:LMMAX(JATOM)) = vxcnonloc(ir,1:LMMAX(JATOM),jatom,1)
          if (spin) qrhod(1:LMMAX(JATOM)) = vxcnonloc(ir,1:LMMAX(JATOM),jatom,2)

          call srolyl(qrhou,qrhod,yy(1,k),1d0,iatj,llmm, &
                      vxunonloc,vxdnonloc,vxtnonloc,LM(1,1,jatom),LMMAX(JATOM),nospin)

          vxunonloc = vxunonloc*rpp
          vxdnonloc = vxdnonloc*rpp

        endif

!        if(iex.gt.10) then
        if(GGA_SWITCH.eqv..true.) then
!
        if(spin)qrhod(1:LMMAX(JATOM))=ddcsp(1:LMMAX(JATOM),ir,2)
        call srolyl(ddcsp(1,ir,1),qrhod,yy(1,k),sqfpi,iatj,llmm, &
                    d2ndru,d2ndrd,d2ndrt,LM(1,1,jatom),LMMAX(JATOM),nospin)
!
         qrhou(1:LMMAX(JATOM))=clmsp(ir,1:LMMAX(JATOM),jatom,1)*rpp
         if(spin)qrhod(1:LMMAX(JATOM))=clmsp(ir,1:LMMAX(JATOM),jatom,2)*rpp

        call srolyl(qrhou,qrhod,dydt(1,k),sqfpi,iatj,llmm, &
                    dndtu,dndtd,dndtt,LM(1,1,jatom),LMMAX(JATOM),nospin)
!
        call srolyl(qrhou,qrhod,dydt2(1,k),sqfpi,iatj,llmm, &
                    d2ndtu,d2ndtd,d2ndtt,LM(1,1,jatom),LMMAX(JATOM),nospin)
!
        call srolyl(qrhou,qrhod,dydp(1,k),sqfpi,iatj,llmm, &
                    dndpu,dndpd,dndpt,LM(1,1,jatom),LMMAX(JATOM),nospin)
!
        call srolyl(qrhou,qrhod,dydp2(1,k),sqfpi,iatj,llmm, &
                    d2ndpu,d2ndpd,d2ndpt,LM(1,1,jatom),LMMAX(JATOM),nospin)
!
        call srolyl(qrhou,qrhod,dydtp(1,k),sqfpi,iatj,llmm, &
                    dndtpu,dndtpd,dndtpt,LM(1,1,jatom),LMMAX(JATOM),nospin)
!
        if(spin)qrhod(1:LMMAX(JATOM))=dcsp(1:LMMAX(JATOM),ir,2)
        call srolyl(dcsp(1,ir,1),qrhod,dydt(1,k),sqfpi,iatj,llmm, &
                    dndrtu,dndrtd,dndrtt,LM(1,1,jatom),LMMAX(JATOM),nospin)
!
        call srolyl(dcsp(1,ir,1),qrhod,dydp(1,k),sqfpi,iatj,llmm, &
                    dndrpu,dndrpd,dndrpt,LM(1,1,jatom),LMMAX(JATOM),nospin)
!
        call srolyl(dcsp(1,ir,1),qrhod,yy(1,k),sqfpi,iatj,llmm, &
                    dndru,dndrd,dndrt,LM(1,1,jatom),LMMAX(JATOM),nospin)

!
!--------------------------------         
        endif                                                          
                                                                       
       if(GGA_SWITCH.eqv..true.) then

         call grans(rp,qsin(k),qcos(k),dndrt,dndtt,dndpt, &
                    d2ndrt,d2ndtt,d2ndpt,dndrtt,dndrpt,dndtpt, &
                    gx,gy,gz,gmag,g2,ggx,ggy,ggz,gdggt,ir)
         call grans(rp,qsin(k),qcos(k),dndru,dndtu,dndpu, &
                    d2ndru,d2ndtu,d2ndpu,dndrtu,dndrpu,dndtpu, &
                    gxu,gyu,gzu,gmagu,g2u,ggxu,ggyu,ggzu,gdggu,ir)
         if(spin)then
                 call grans(rp,qsin(k),qcos(k),dndrd,dndtd,dndpd, &
                    d2ndrd,d2ndtd,d2ndpd,dndrtd,dndrpd,dndtpd, &
                    gxd,gyd,gzd,gmagd,g2d,ggxd,ggyd,ggzd,gdggd,ir)
         else
                 gxd=gxu
                 gyd=gyu
                 gzd=gzu
                 gmagd=gmagu
                 g2d=g2u
                 ggxd=ggxu
                 ggyd=ggyu
                 ggzd=ggzu
                 gdggd=gdggu
         endif
       endif
!      MGGA-related quantities added (but still unused in xcpot1q!!)
       CALL VXCLM2(FU,GXU,GYU,GZU,GMAGU,G2U,GGXU,GGYU,GGZU,&
            FD,GXD,GYD,GZD,GMAGD,G2D,GGXD,GGYD,GGZD,&
            VXCU,VXCD,excu,excd,&
            vtauc_up, vtauc_dn, vlaplc_up, vlaplc_dn,&
            dtau_drho,dtau_u_drho_u,dtau_u_drho_d,dtau_d_drho_u,dtau_d_drho_d,&
            VXUOLD,VXDOLD,VXUNONLOC,VXDNONLOC,&
            GGX,GGY,GGZ,GDGGT,gdggu,gdggd,tauup,taudn,&
            ir,CutMuffin,JSPIN,JATOM,sig_str_u,sig_str_d,sig_str_ud)
        ! CALL VXCLM2(FU,GXU,GYU,GZU,GMAGU,G2U,GGXU,GGYU,GGZU, &
        !             FD,GXD,GYD,GZD,GMAGD,G2D,GGXD,GGYD,GGZD, &
        !             VXCU,VXCD,excu,excd,VXUOLD,VXDOLD,VXUNONLOC,VXDNONLOC, &
        !             GGX,GGY,GGZ,GDGGT,tauup,taudn,ir,CutMuffin,JSPIN,JATOM)

!
        if(imfield.gt.0) then
         vxcu=vxcu - Bextene
         vxcd=vxcd + Bextene
        endif   
!
!       if(ir.eq.jri(jatom)) then
         vxcsu(k)=vxcu
         vxcsd(k)=vxcd
         exu  (k)=excu
         exd  (k)=excd
        if(ir.eq.jri(jatom).and.iprint.eq.2) then
          write(789,'(29f10.5)') spt(1,k),spt(2,k),spt(3,k),fu,GXU,GYU,GZU,&
          GMAGU,G2U,GGXU,GGYU,GGZU,fd,GXD,GYD,GZD,GMAGD,G2D,GGXD,GGYD,GGZD,excu,excd,vxcu,vxcd
        endif
! *** LDM Change
77      continue
!                                                                       
! AltMode, weighted fit
! if(AltMode)then
!       Perform a weighted least-squares fit, the weight being the density
!       This is justified as it corresponds to the relevant term in the Hamiltonian
!
!       Form is to find MatVal * C = XC*density*quadrature weight
!               MatVal is density*quadrature weight*YY
!               C are the harmonic coeffidients
!               XC is the potential or density
!
!       The same MatVal is used for all the cases, which is efficient
!
!       It might be useful to subtract the mean, or not. This will have the downside
!       of removing one large singular value. To be tested later
!
!       Density times quadrature weight
!       The full density is used as spin-resolved can go wrong. There is some justification
!       for taking the sqrt here, a pseudo-robust fit.
        rhoval(1:npt1)=rhoval(1:npt1)*weight(1:npt1)
!       Matrix, only using terms that matter (otherwise blows up!)
        LL=0
        DO L=1,LMMAX(JATOM)
                if(UseLM(L))then
                        LL=LL+1
                        MatVal(1:npt1,LL)=rhoval(1:npt1)*YY(L,1:npt1)
                endif
        ENDDO
!
!       Right hand sides, potential and energy for spin up and if needed down
        rhs(1:npt1,1) = rhoval(1:npt1)*VXCSU(1:npt1)
        rhs(1:npt1,2) = rhoval(1:npt1)*EXU  (1:npt1)
        if(spin)then
                rhs(1:npt1,3) = rhoval(1:npt1)*VXCSD(1:npt1)
                rhs(1:npt1,4) = rhoval(1:npt1)*EXD  (1:npt1)
        endif
!
!       Truncate singular values below 1D-12. This might want to be changed, and the Wiener-filter used
!       in mixer might be a better approach.
        RCOND=1D-12
!
!       Fit using a truncated SVD approach
        call DGELSD(NPT1,LLMMU, NRHS, MatVal, NPT1 , RHS, NPT1, work1, &
                RCOND, IRANK, WORK2, LWORK, IWORK, INFO)

        if(info .ne. 0)then
                write(6,*)'Ooops ',info
                stop
        endif
!
!       Copy back ones being used
        LL0=0
        bbu=0 ; bbbu=0 ; bbd=0 ; bbbd=0
        DO L=1,LMMAX(JATOM)
                if(UseLM(L))then
                        LL0=LL0+1
                        bbu (L)=RHS(LL0,1)
                        bbbu(L)=RHS(LL0,2)
                        if(spin)then
                                bbd (L)=RHS(LL0,3)
                                bbbd(L)=RHS(LL0,4)
                        endif
                endif
        enddo
!
!      if(debug)then
!         if(nospin)then
!           DO LM1=1,LMMAX(JATOM)
!              bbd (lm1)=bbu (lm1)
!              bbbd(lm1)=bbbu(lm1)
!           enddo
!         endif
!
!         do LM1=1,LMMAX(JATOM)
!               write(6,1551)IR,LM1,bbd(LM1),bbu(LM1),bbbu(LM1),bbbd(LM1)
!         enddo
!      endif

1551   format(2I5,4D26.18)
!
!================= VXC, UP ==================
!
!
      IF(iatj.LT.0) THEN                                        
       IF(ir.EQ.JRI(JATOM)) THEN                                          
         WRITE(6,1540)                                                 
       endif
          SIGMA=0.D0                                                      
          DO 12 k=1,npt1                                                
          TEST=0.D0                                                       
          DO 13 LM1=1,LLMM                                              
  13      TEST=TEST+bbu(LM1)*YY(LM1,k)                                   
          if(ir.eq.jri(jatom).and.k.eq.1) WRITE(6,1550)k,vxcsu(k),TEST,vxcsu(k)-TEST
          if(ir.eq.jri(jatom).and.iprint.gt.0) then
             IF(MOD(k,2).EQ.0) THEN
                DIFVXC=vxcsu(k)-TEST                                           
                WRITE(6,1550)k,vxcsu(k),TEST,DIFVXC                            
             ENDIF   
          endif
          if(dmaxup.lt.abs(vxcsu(k)-TEST)) dmaxup= abs(vxcsu(k)-TEST)
  12      SIGMA=SIGMA+weight(k)*(vxcsu(k)-TEST)**2  
          SIGMA=SQRT(SIGMA/wnorm)                                        
          if(sigmamaxup.lt.sigma) then
            sigmamaxup=sigma
            irsigmaup=ir
          endif
          if(ir.eq.jri(jatom))then
           WRITE(6,'(a,i4,a,10x,2e20.5)') 'ATOM',JATOM, &
               '  AT RMT: SIGMA OF V-XC FIT: ',SIGMA 
           WRITE(6,'(a,i4,a,i3,")=",f6.3,a,2e13.5)') 'ATOM',JATOM, &
               '  LARGEST SIGMA AT R(',irsigmaup,r(irsigmaup),' and MAX DIFF:'&
                ,sigmamaxup,dmaxup                                   
          sigmaj(1)=sigma
          else
           sigmaup=sigma
          endif
!       END IF                                                         
          DO 11 LM1=1,LLMM                                                 
   11     VXC(ir,LM1,JATOM,1)=bbu(LM1)                                   
      ELSE                                                              
          SIGMA=0.D0                                                      
          DO 112 k=1,npt1                                               
          TEST=0.D0                                                       
          DO 113 LM1=1,LLMM                                             
 113      TEST=TEST+bbu(LM1)*YY(LM1,k)                                   
          IF(k.EQ.1.and.(ir.eq.JRI(JATOM))) WRITE(6,*) k,vxcsu(k),TEST
          IF((MOD(k,2).EQ.0).and.(ir.eq.JRI(JATOM)).and.iprint.gt.0) &
                 WRITE(6,*) k,vxcsu(k),TEST                   
          if(dmaxup.lt.abs(vxcsu(k)-TEST)) dmaxup= abs(vxcsu(k)-TEST)
 112      SIGMA=SIGMA+weight(k)*(vxcsu(k)-TEST)**2                                
          SIGMA=SQRT(SIGMA/wnorm)                                        
          if(sigmamaxup.lt.sigma) then
            sigmamaxup=sigma
            irsigmaup=ir
          endif
          if(ir.eq.jri(jatom))then
           WRITE(6,'(a,i4,a,10x,2e20.5)') 'ATOM',JATOM, &
               '  AT RMT: SIGMA OF V-XC FIT: ',SIGMA 
           WRITE(6,'(a,i4,a,i3,")=",f6.3,a,2e13.5)') 'ATOM',JATOM, &
               '  LARGEST SIGMA AT R(',irsigmaup,r(irsigmaup),' and MAX DIFF:'&
                ,sigmamaxup,dmaxup                                   
          sigmaj(1)=sigma
          else
                sigmaup=sigma
          endif
!       END IF                                                         
       CALL cub_xc_back(vxc(1,1,jatom,1),ir,llmm, &
                        lm(1,1,jatom),bbu,lmmax(jatom))
      ENDIF                                                         
!
!================= VXC, DN ==================
!
      if(spin)then
!      dmax=0.d0
       IF(iatj.LT.0) THEN                                        
        IF(ir.EQ.JRI(JATOM)) THEN                                          
          WRITE(6,1540)                                                 
        endif
          SIGMA=0.D0                                                      
          DO 5012 k=1,npt1                                           
           TEST=0.D0                                                       
           DO 5013 LM1=1,LLMM                                              
 5013      TEST=TEST+bbd(LM1)*YY(LM1,k)                                   
           IF(ir.EQ.JRI(JATOM).and.k.eq.1) WRITE(6,1550)k,vxcsd(k),TEST,vxcsd(k)-TEST
           IF(ir.EQ.JRI(JATOM).and.iprint.gt.0) then
              IF(MOD(k,2).EQ.0) THEN                                       
                 DIFVXC=vxcsd(k)-TEST                                           
                 WRITE(6,1550)k,vxcsd(k),TEST,DIFVXC        
              ENDIF                                
           endif                         
           if(dmaxdn.lt.abs(vxcsd(k)-TEST)) dmaxdn= abs(vxcsd(k)-TEST)
 5012     SIGMA=SIGMA+weight(k)*(vxcsd(k)-TEST)**2        
          SIGMA=SQRT(SIGMA/wnorm)                                        
          if(sigmamaxdn.lt.sigma) then
            sigmamaxdn=sigma
            irsigmadn=ir
          endif
          if(ir.eq.jri(jatom))then
           WRITE(6,'(a,i4,a,10x,2e20.5)') 'ATOM',JATOM, &
               '  AT RMT: SIGMA OF V-XC FIT: ',SIGMA 
           WRITE(6,'(a,i4,a,i3,")=",f6.3,a,2e13.5)') 'ATOM',JATOM, &
               '  LARGEST SIGMA AT R(',irsigmadn,r(irsigmadn),' and MAX DIFF:'&
                ,sigmamaxdn,dmaxdn                                   
          sigmaj(2)=sigma
          endif
!        END IF                                                         
          DO 5011 LM1=1,LLMM                                                 
 5011     VXC(ir,LM1,JATOM,2)=bbd(LM1)                                   
       ELSE                                                              
          SIGMA=0.D0                                                      
          DO 5112 k=1,npt1                                          
             TEST=0.D0                                                       
             DO 5113 LM1=1,LLMM                                             
 5113        TEST=TEST+bbd(LM1)*YY(LM1,k)                                   
             IF(k.EQ.1.and.(ir.eq.JRI(JATOM))) WRITE(6,*) k,vxcsd(k),TEST
             IF((MOD(k,2).EQ.0).and.(ir.eq.JRI(JATOM)).and.iprint.gt.0) &
                WRITE(6,*) k,vxcsd(k),TEST
             if(dmaxdn.lt.abs(vxcsd(k)-TEST)) dmaxdn= abs(vxcsd(k)-TEST)
 5112     SIGMA=SIGMA+weight(k)*(vxcsd(k)-TEST)**2    
          SIGMA=SQRT(SIGMA/wnorm)                                        
          if(sigmamaxdn.lt.sigma) then
            sigmamaxdn=sigma
            irsigmadn=ir
          endif
          if(ir.eq.jri(jatom))then
           WRITE(6,'(a,i4,a,10x,2e20.5)') 'ATOM',JATOM, &
               '  AT RMT: SIGMA OF V-XC FIT: ',SIGMA 
           WRITE(6,'(a,i4,a,i3,")=",f6.3,a,2e13.5)') 'ATOM',JATOM, &
               '  LARGEST SIGMA AT R(',irsigmadn,r(irsigmadn),' and MAX DIFF:'&
                ,sigmamaxdn,dmaxdn                                   
           sigmaj(2)=sigma
          endif
!        END IF                                                         
         CALL cub_xc_back(vxc(1,1,jatom,2),ir,llmm, &
                        lm(1,1,jatom),bbd,lmmax(jatom))
       ENDIF
      endif                                                         
!                                                                       
!================= EXC, UP ==================
!
      IF(iatj.LT.0) THEN                                        
       DO 19 LM1=1,LLMM                                                  
  19   EXC(ir,LM1,JATOM,1)=bbbu(LM1)                                   
      ELSE                                                              
         CALL cub_xc_back(exc(1,1,jatom,1),ir,llmm, &
                        lm(1,1,jatom),bbbu,lmmax(jatom))
      ENDIF                                                         
!                                                                       
!================= EXC, DN ==================
!
      if(spin)then
        IF(iatj.LT.0) THEN
                DO 5019 LM1=1,LLMM                                            
 5019           EXC(ir,LM1,JATOM,2)=bbbd(LM1)                                
        ELSE                                                              
                CALL cub_xc_back(exc(1,1,jatom,2),ir,llmm, &
                        lm(1,1,jatom),bbbd,lmmax(jatom))
        ENDIF                                                         
      endif
 34   CONTINUE                                                          
!********************************************************
!      LOOP OVER ALL RADIAL MESH COMPLETED
!                                                                       
!     For unpolarized case, copy values
      if(nospin)then
        sigmaj(2)=sigmaj(1)
        ir=jri(jatom)
        exc(1:ir,1:lmmax(jatom),JATOM,2)=exc(1:ir,1:lmmax(jatom),JATOM,1)
        vxc(1:ir,1:lmmax(jatom),JATOM,2)=vxc(1:ir,1:lmmax(jatom),JATOM,1)
      endif

!      DO  LM1=1,LLMM
!      if(lm(1,lm1,jatom).eq.1) then
!              vxc(1:ir,lm1,JATOM,1:2)=0.d0
!      endif
!      if(lm(1,lm1,jatom).eq.2) then
!              vxc(1:ir,lm1,JATOM,1:2)=0.d0
!      endif
!      if(lm(1,lm1,jatom).eq.3) then
!              vxc(1:ir,lm1,JATOM,1:2)=0.d0
!      endif
!      enddo

 1530 FORMAT(3X,'CONDITION PARAMETER ATOM',I3,2X,A10,2X,'RCOND= ',       &
             F8.5)                                                      
 1540 FORMAT(3X,'INDEX',6X,'V-XC',7X,'FIT',5X,'DIFFERENCE')             
 1550 FORMAT(I8,2F10.5,F15.5)                                           
      RETURN                                                            
      END
                                                               
