       module ChargeOpts
       use TestCases
       end module ChargeOpts
!
!     General integration forms, with origin term included
!
!     Both flang & pgf90 complain about the prior Entry, so avoid
!     Maybe a template could be used (?)
!
      SUBROUTINE CHARGEL2(RX,S,FPIV,FUNCT,DELTA,N,SUM) 
      use ChargeOpts
      IMPLICIT Real(8) (A-H,O-Z)
!
      DIMENSION RX(N),FUNCT(N)     
      Real(8) S,FPIV, DELTA, SUM

      CALL CHARGE(RX,DELTA,FUNCT,1,N,SUM) 
      SUM=SUM*S*FPIV
      RETURN
      END

      SUBROUTINE Charg2(RX,DELTA,FUNCT,JSTART,JEND,SUM)
      IMPLICIT Real(8) (A-H,O-Z)
      dimension RX(*),FUNCT(*)
      Real(8) DELTA, SUM
      CALL Charge(RX,DELTA,FUNCT,JSTART,JEND,SUM)
      RETURN
      END

      SUBROUTINE Charg3(RX,DELTA,FUNCT,JSTART,JEND,SUM)
      IMPLICIT Real(8) (A-H,O-Z)
      dimension RX(*),FUNCT(*)
      Real(8) DELTA, SUM
      CALL Charge(RX,DELTA,FUNCT,JSTART,JEND,SUM)
      RETURN
      END

      SUBROUTINE CHARGE(RX,DELTA,FUNCT,JSTART,JEND,SUM)
!
!     New replacement. It could have some other traps (see lapw0.F)
!
      use ChargeOpts
      implicit Real(8) (a-h,o-z)
      dimension RX(*),FUNCT(*),F(JEND)
      Real(8) DELTA, SUM

!     flang & pgf complain about entry statement
!     Entry Charg2(RX,DELTA,FUNCT,JSTART,JEND,SUM)
!     Entry Charg3(RX,DELTA,FUNCT,JSTART,JEND,SUM)

      if(SimpInt)then
        call  SIMPSONK(RX,DELTA,FUNCT,JSTART,JEND,SUM)  
        return
      endif
!
      NPoint=JEND-JSTART+1
      if(NPoint .eq. 2)then
        SUM=(FUNCT(JSTART)+FUNCT(JSTART+1))*0.5D0*(RX(JSTART+1)-RX(JSTART))
      else if(NPoint .eq. 1)then
        SUM=0.0D0
      else
        N=0
        DO J=JSTART,JEND
           N=N+1
           F(N)=RX(J)*FUNCT(J)
        ENDDO
        CALL CHARGEF(RX,Delta,F,1,n,SUM)
      endif
      RETURN
      END

      SUBROUTINE CHARGEF(RX,Delta,F,JSTART,JEND,SUM)
!DIR$ OPTIMIZE:0
!
!     New version to minimize oscillations and bias
!     Uses an Alternative extended Simpson's rule
!     see Numerical Recipes (Press)
!
!     For a given set of points, this is NOT as good as the standard Simpson rule
!     which is hard to beat.
!
!     However, we Really want an integration method which has some degree of accuracy
!     and is stable to perturbations. The standard Simpson rule can be a little unstable
!     to perturbations with a frequency of 2M points (M an integer) and can lead to a
!     Coulomb potential with slight oscillations. The flat form is more stable in this
!     sense. Since the number of radial points can be increased at minimal time cost,
!     there seems to be more advantages to stability.
!
!     See http://mathworld.wolfram.com/Newton-CotesFormulas.html for some formulae
!
      use ChargeOpts
      implicit Real(8) (A-H,O-Z)
      dimension RX(*), F(*)
      Real(8)  SUM, DELTA
!     Extended Rule
      Real(8),parameter :: T0=17.D0/48.D0, T1=59.D0/48.D0, T2=43.D0/48.D0, T3=49.D0/48.D0 

!     Five point Newton-Coates (Boole)
      Real(8), parameter :: F0=14.D0/45.D0, F1=64.D0/45.D0, F2=24.D0/45.D0

!     Six point Newton-Coates
      Real(8), parameter :: S0=95.D0/288.D0, S1=375.D0/288.D0, S2=250.D0/288.D0

!     Seven point Newton-Coates
      Real(8), parameter :: N0=41.D0/140.D0, N1=216.D0/140.D0, N2=27.D0/140.D0, N3=272.D0/140.D0

!     Optimized Flat average for 7 points, 0.25*(1/3) + 0.75*(3/8)
      Real(8), parameter :: O0=35.D0/96.D0, O1=113.D0/96.D0, O2=97.D0/96.D0, O3=86.D0/96.D0

!     Average of 3/8 + Simpson for 6 points
      Real(8), parameter :: A0=17.D0/48.D0, A1=59.D0/48.D0, A2=44.D0/48.D0

!     Average of 3/8 + Simpson for 7 points
!      Real(8), parameter :: B0=17.D0/48.D0,B1=59.D0/48.D0, B2=43.D0/48.D0, B3=50.D0/48.D0

!
      SUM=0.0D0
      Npoint=JEND-JSTART+1
      if(Npoint .le. 1)then
        Return
      else if(Npoint .eq. 2)then
!       SUM=(F(JSTART)+F(JEND))*0.5D0
        SUM=( F(JSTART)/RX(JSTART)+F(Jend)/RX(JEND) )*0.5D0       &
                               *( RX(Jend)-RX(Jstart)       )          
        return
      else if(NPoint .eq. 3)then       ! Simpson
        SUM=(F(JSTART)+4.D0*F(JSTART+1)+F(JSTART+2))/3.D0

      else if(Npoint .eq. 4)then       ! 3/8
        SUM=(F(JSTART)+3.D0*(F(JSTART+1)+F(JSTART+2))+F(JSTART+3))*0.375D0

      else if(Npoint .eq. 5)then
        if(ConOpt)then                 ! Simpson
          SUM= (F(JSTART)+4.D0*F(JSTART+1)+2.D0*F(JSTART+2)+4.D0*F(JSTART+3)+F(JSTART+4))/3.D0
        else                           ! Newton-Coates
          SUM=  F0*(F(JSTART)+F(JSTART+4))+F1*(F(JSTART+1)+F(JSTART+3))+F2*F(JSTART+2)
        endif
      else if(NPoint .eq. 6)then
        if(ConOpt)then                 ! Simpson & 3/8
          SUM=(A0*(F(JSTART)+F(JSTART+5))+A1*(F(JSTART+1)+F(JSTART+4))+A2*(F(JSTART+2)+F(JSTART+3)))
        else                           ! Newton Coates
          SUM=(S0*(F(JSTART)+F(JSTART+5))+S1*(F(JSTART+1)+F(JSTART+4))+S2*(F(JSTART+2)+F(JSTART+3)))
        endif
      else if(NPoint .eq. 7)then
        if(ConOpt)then                 ! Optimized Flat 7-point
          SUM= O0*(F(JSTART)+F(JSTART+6))+O1*(F(JSTART+1)+F(JSTART+5))+O2*(F(JSTART+2)+F(JSTART+4)) &
                +O3*F(JSTART+3)
        else                           ! Newton-Coates
          SUM= N0*(F(JSTART)+F(JSTART+6))+N1*(F(JSTART+1)+F(JSTART+5))+N2*(F(JSTART+2)+F(JSTART+4)) &
                +N3*F(JSTART+3)
        endif
      else

        C = 0.D0

        SUM1=T0*F(JSTART)+T1*F(JSTART+1)+T2*F(JSTART+2)+T3*F(JSTART+3)
        SUM2=(T3*F(JEND-3)+T2*F(JEND-2)+T1*F(JEND-1)+T0*F(JEND))
        NOFF=4
!
!   Kahan sum (may not matter or be optimized away)
        C = 0.D0
        sum3=0.d0
!$omp simd private(y,t) reduction(+:c,sum3)
        DO J=JSTART+NOFF,JEND-NOFF
                Y = F(J) - C
                T = SUM3 + Y
                C = (T-SUM3) -Y
                SUM3 = T
        ENDDO
        SUM= SUM+(SUM1+SUM2+SUM3 - C*0.5D0)

      endif
      SUM=SUM*DELTA

      return
      end
!
      SUBROUTINE SIMPSONK(RX,DELTA,FUNCT,JSTART,JEND,SUM)                 
!DIR$ OPTIMIZE:0
      use ChargeOpts
      IMPLICIT Real(8) (A-H,O-Z)
!
      DIMENSION RX(*),FUNCT(*)
      Real(8) DELTA, SUM                                    
!                                                                       
      SUM=0.0D0                                                         
      NPOINT=JEND-JSTART+1                                              

      JS    =JSTART+1-MOD(NPOINT,2)                                     
      JF    =JEND-2                               
!   Kahan sum (may not matter or be optimized away)
        C = 0.D0
        DO J=JS,JF,2                                                    
                F = FUNCT(J)*RX(J)+4.D0*FUNCT(J+1)*RX(J+1)+FUNCT(J+2)*RX(J+2)
                Y = F - C
                T = SUM + Y
                C = (T-SUM) -Y
                SUM = T
        ENDDO
!                                                                       
      SUM=SUM*DELTA/3.0D0                                               
      if(1-mod(npoint,2).gt.0)then
      SUM=SUM+( FUNCT(JSTART)+FUNCT(JS) )/ 2.0D0       &
                               *( RX(JS)-RX(JSTART)       )             
      endif
!
      RETURN                                                            
      END                         

        subroutine KSum(sum,add,C)
!DIR$ OPTIMIZE:0
        implicit Real(8) (a-h,o-z)
!       Do a single step of a Kahan summation
!       Note that "C" has to be set the first time to zero, and later not touched
!       Note as well that we have to hope the compiler does not optimize this away!
        Y = add - C
        T = sum + Y
        C = (T-Sum) -Y
        Sum = T
        return
        end

        subroutine KSumC(sum,add,C)
!DIR$ OPTIMIZE:0
        implicit Real(8) (a-h,o-z)
        Complex(8) sum, add, C, Y, T
!       Do a single step of a Complex Kahan summation
!       Note that "C" has to be set the first time to zero, and later not touched
!       Note as well that we have to hope the compiler does not optimize this away!
        Y = add - C
        T = sum + Y
        C = (T-Sum) -Y
        Sum = T
        return
        end

        subroutine KSub(sum,sub,C)
!DIR$ OPTIMIZE:0
        implicit Real(8) (a-h,o-z)
!       Do a single step of a Kahan subtraction
!       Note that "C" has to be set the first time to zero, and later not touched
!       Note as well that we have to hope the compiler does not optimize this away!
        Y = -sub - C
        T = sum + Y
        C = (T-Sum) -Y
        Sum = T
        return
        end

        subroutine KSum2(sum,add1,add2,C)
!DIR$ OPTIMIZE:0
        implicit Real(8) (a-h,o-z)
!       Do a single step of a Kahan summation, allowing for possible FMA
!       Note that "C" has to be set the first time to zero, and later not touched
!       Note as well that we have to hope the compiler does not optimize this away!
        Y = add1*add2 - C
        T = sum + Y
        C = (T-Sum) -Y
        Sum = T
        return
        end

        subroutine KSum3(sum,add1,add2,add3,C)
!DIR$ OPTIMIZE:0
        implicit Real(8) (a-h,o-z)
!       Do a single step of a Kahan summation, allowing for possible FMA
!       Note that "C" has to be set the first time to zero, and later not touched
!       Note as well that we have to hope the compiler does not optimize this away!
        Y = add1*add2*add3 - C
        T = sum + Y
        C = (T-Sum) -Y
        Sum = T
        return
        end

        Real(8) function ddotK(n,vec1,id1,vec2,id2)
!DIR$ OPTIMIZE:0
        implicit Real(8) (a-h,o-z)
!       Kaham sum dot product, id1 & id2 are dummies at the moment
        Real(8), intent(IN) ::  vec1(n),vec2(n)
        C=0.D0
        Sum=0.D0
!$omp simd private(y,t) reduction(+:c,sum)
        DO J=1,N
                Y = vec1(J)*vec2(j) - C
                T = sum + Y
                C = (T-Sum) -Y
                Sum = T
        enddo
        ddotK=Sum - C*0.5D0
        return
        end
        Real(8) function ddotK2(n,vec1,id1,vec2,id2)
!DIR$ OPTIMIZE:0
        implicit Real(8) (a-h,o-z)
!       Kaham sum dot product, id1 & id2 are dummies at the moment
        dimension vec1(n*2),vec2(n*2)
        C=0.D0
        Sum=0.D0
!$omp simd private(y,t) reduction(+:c,sum)
        DO J=1,2*N,2
                Y = vec1(J)*vec2(j) - C
                T = sum + Y
                C = (T-Sum) -Y
                Sum = T
        enddo
        ddotK2=Sum -C*0.5D0
        return
        end
        Real(8) function zdotK(n,vec1,id1,vec2,id2)
!DIR$ OPTIMIZE:0
        implicit Real(8) (a-h,o-z)
!       Kaham sum dot product, id1 & id2 are dummies at the moment
!       Complex version
        Complex(8),intent(IN) :: vec1(n),vec2(n)
        C=0.D0
        Sum=0.D0
!$omp simd private(y,t) reduction(+:c,sum)
        DO J=1,N
                Y = dble(vec1(J))*dble(vec2(j)) + dimag(vec1(j))*dimag(vec2(j)) - C
                T = sum + Y
                C = (T-Sum) -Y
                Sum = T
        enddo
        zdotK=Sum - C*0.5D0
        return
        end
        Real(8) function zddotK(n,vec1,id1,vec2,id2)
!DIR$ OPTIMIZE:0
        implicit Real(8) (a-h,o-z)
!       Kaham sum dot product, id1 & id2 are dummies at the moment
!       Mixed version
        Complex(8),intent(IN) :: vec1(n)
        Real(8),intent(IN)    :: vec2(n)
        C=0.D0
        Sum=0.D0
!$omp simd private(y,t) reduction(+:c,sum)
        DO J=1,N
                Y = dble(vec1(J))*vec2(j) - C
                T = sum + Y
                C = (T-Sum) -Y
                Sum = T
        enddo
        zddotK=Sum - C*0.5D0
        return
        end
!
        Real(8) function zzdotK(n,vec1,id1,vec2,id2)
!DIR$ OPTIMIZE:0
        implicit Real(8) (a-h,o-z)
!       Kaham sum dot product, id1 & id2 are dummies at the moment
!       Complex version
        Complex(8),intent(IN) :: vec1(n),vec2(n)
        C=0.D0
        Sum=0.D0
!$omp simd private(y,t) reduction(+:c,sum)
        DO J=1,N
                Y = dble(dconjg(vec1(J))*vec2(j)) - C
                T = sum + Y
                C = (T-Sum) -Y
                Sum = T
!
        enddo
        zzdotK=Sum - C*0.5D0
        return
        end
!
        Real(8) function dnrm2K(n,vec,id1)
!DIR$ OPTIMIZE:0
        implicit Real(8) (a-h,o-z)
!       Kaham sum rms product, id1 dummy
        Real(8),intent(IN) :: vec(n)
        C=0.D0
        Sum=0.D0
!$omp simd private(y,t) reduction(+:c,sum)
        DO J=1,N
                Y = vec(J)*vec(j) - C
                T = sum + Y
                C = (T-Sum) -Y
                Sum = T
        enddo
        SUM = SUM -C*0.5D0
        dnrm2K=dsqrt(Sum)
        return
        end

