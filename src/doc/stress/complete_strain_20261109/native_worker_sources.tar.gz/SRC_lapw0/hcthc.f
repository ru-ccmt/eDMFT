      subroutine hcthc(up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap, &
        grupgrdn,delgrupdn,delgrdnup,ec,vcup,vcdn)

!F. A. Hamprecht et al., J. Chem. Phys. 109, 6264 (1998).
!A. D. Boese et al., J. Chem. Phys. 112, 1670 (2000).
!A. D. Boese and N. C. Handy, J. Chem. Phys. 114, 5497 (2001).

      implicit none

      real*8, intent(in) :: up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap, &
        grupgrdn,delgrupdn,delgrdnup
      real*8, intent(out) :: ec,vcup,vcdn
      real*8 :: ecssdn, ecssup, vcssdn, vcssup, ecud, vcudup, vcuddn

      if((up.gt.1d-18) .and. (agrup.gt.1d-18))then
        call exchhcthcss(up,agrup,delgrup,uplap,ecssup,vcssup)
      else
        ecssup=0d0
        vcssup=0d0
      endif
      
      if((dn.gt.1d-18) .and. (agrdn.gt.1d-18))then
        call exchhcthcss(dn,agrdn,delgrdn,dnlap,ecssdn,vcssdn)
      else
        ecssdn=0d0
        vcssdn=0d0
      endif

      ec = ecssup + ecssdn
      vcup = vcssup
      vcdn = vcssdn

      call exchhcthcud(up,dn,agrup,agrdn,grupgrdn,grupgrdn,delgrup, &
        delgrdn,delgrupdn,delgrdnup,uplap,dnlap,ecud,vcudup,vcuddn)

      ec = (ec + ecud)/(up+dn)
      vcup = vcup + vcudup
      vcdn = vcdn + vcuddn

      return
      end

!-----------------------------------------------------------------------

      subroutine exchhcthcss(rho,ngrho,grhogngrho,lrho,ecss,vcss)

      use xcparam, only : EC_SWITCH, VC_SWITCH, xc2

      implicit none

      integer :: i
      real*8, intent(in) :: rho, ngrho, grhogngrho, lrho
      real*8, intent(out) :: ecss, vcss
      real*8 :: pi, gammac, c(0:4), chcthc, rs, zet, eclsd, vlsdu, vlsdd, &
        ecrs, eczet, alfc, ecssunif, vcssunif, s2, ds2dngrho, &
        d2s2dngrho2, ds2drho, d2s2drho2, d2s2drhodngrho, uc, ducds2, &
        d2ucds22, gc, dgcduc, d2gcduc2, dgcdrho, dgcdngrho, &
        d2gcdngrho2, d2gcdngrhodrho

      parameter(pi=acos(-1d0))
      parameter(gammac=0.2d0)

!Same paramaters as in libxc (some values in the original publications are wrong).
      if ((EC_SWITCH .eq. 'EC_HCTH93') .or. (VC_SWITCH .eq. 'VC_HCTH93')) then
        c(0) =  0.222601d0
        c(1) = -0.0338622d0
        c(2) = -0.0125170d0
        c(3) = -0.802496d0
        c(4) =  1.55396d0
      elseif ((EC_SWITCH .eq. 'EC_HCTH120') .or. (VC_SWITCH .eq. 'VC_HCTH120')) then
        c(0) =  0.489508d0
        c(1) = -0.260699d0
        c(2) =  0.432917d0
        c(3) = -1.99247d0
        c(4) =  2.48531d0
      elseif ((EC_SWITCH .eq. 'EC_HCTH147') .or. (VC_SWITCH .eq. 'VC_HCTH147')) then
        c(0) =  0.562576d0
        c(1) =  0.0171436d0
        c(2) = -1.30636d0
        c(3) =  1.05747d0
        c(4) =  0.885429d0
      elseif ((EC_SWITCH .eq. 'EC_HCTH407') .or. (VC_SWITCH .eq. 'VC_HCTH407')) then
        c(0) =  1.18777d0
        c(1) = -2.40292d0
        c(2) =  5.61741d0
        c(3) = -9.17923d0
        c(4) =  6.24798d0
      endif

      if (xc2 .lt. 0d0) then
        chcthc = 1d0
      else
        chcthc = xc2
      endif

      rs = (0.75d0/(pi*rho))**(1d0/3d0)
      zet = 1d0
      call corlsd(rs,zet,eclsd,vlsdu,vlsdd,ecrs,eczet,alfc)

      ecssunif = eclsd*rho

      vcssunif = vlsdu

      s2 = ngrho**2/rho**(8d0/3d0)

      ds2dngrho = 2d0*ngrho/rho**(8d0/3d0)

      d2s2dngrho2 = 2d0/rho**(8d0/3d0)

      ds2drho = -8d0/3d0*ngrho**2/rho**(11d0/3d0)

      d2s2drho2 = 88d0/9d0*ngrho**2/rho**(14d0/3d0)

      d2s2drhodngrho = -16d0/3d0*ngrho/rho**(11d0/3d0)

      uc = gammac*s2/(1d0 + gammac*s2)

      ducds2 = gammac/(1d0 + gammac*s2)**2      

      d2ucds22 = -2d0*gammac**2/(1d0 + gammac*s2)**3

      gc = 0d0
      do i=0, 4
        gc = gc + c(i)*uc**i
      enddo

      dgcduc = 0d0
      do i=1, 4
        dgcduc = dgcduc + i*c(i)*uc**(i-1)
      enddo

      d2gcduc2 = 0d0
      do i=2, 4
        d2gcduc2 = d2gcduc2 + i*(i-1)*c(i)*uc**(i-2)
      enddo

      dgcdrho = dgcduc*ducds2*ds2drho

      dgcdngrho = dgcduc*ducds2*ds2dngrho

      d2gcdngrho2 = d2gcduc2*ducds2**2*ds2dngrho**2 + &
        dgcduc*d2ucds22*ds2dngrho**2 + dgcduc*ducds2*d2s2dngrho2

      d2gcdngrhodrho = d2gcduc2*ducds2**2*ds2dngrho*ds2drho + &
        dgcduc*d2ucds22*ds2dngrho*ds2drho + &
        dgcduc*ducds2*d2s2drhodngrho

      ecss = chcthc*ecssunif*gc

      vcss = chcthc*(vcssunif*gc + ecssunif*dgcdrho - vcssunif*dgcdngrho*ngrho - &
             ecssunif*(d2gcdngrhodrho*ngrho + d2gcdngrho2*grhogngrho/ngrho - &
             dgcdngrho*grhogngrho/ngrho**2 + dgcdngrho*lrho/ngrho))

      return
      end

!-----------------------------------------------------------------------

      subroutine exchhcthcud(rhoup,rhodn,ngrhoup,ngrhodn, &
        grhoupgrhodn,grhodngrhoup,grhoupgngrhoup,grhodngngrhodn, &
        grhoupgngrhodn,grhodngngrhoup,lrhoup,lrhodn,ecud,vcudup,vcuddn)

      use xcparam, only : EC_SWITCH, VC_SWITCH, xc2

      implicit none

      integer :: i
      real*8, intent(in) :: rhoup,rhodn,ngrhoup,ngrhodn, &
        grhoupgrhodn,grhodngrhoup,grhoupgngrhoup,grhodngngrhodn, &
        grhoupgngrhodn,grhodngngrhoup,lrhoup,lrhodn
      real*8, intent(out) :: ecud,vcudup,vcuddn
      real*8 :: pi, gammac, c(0:4), chcthc, rho, rs, zet, eclsd, &
        vlsdu, vlsdd, ecrs, eczet, alfc, ecunif, vcunifup, vcunifdn, &
        ecupunif, vcupunif, ecdnunif, vcdnunif, ecunifud, vcunifudup, vcunifuddn, &
        sup2, sdn2, sa2, dsa2dngrhoup, dsa2dngrhodn, d2sa2dngrhoup2, d2sa2dngrhodn2, &
        dsa2drhoup, dsa2drhodn, d2sa2drhoup2, d2sa2drhodn2, &
        d2sa2drhoupdngrhoup, d2sa2drhodndngrhodn, uc, ducdsa2, d2ucdsa22, &
        gc, dgcduc, d2gcduc2, dgcdrhoup, dgcdrhodn, dgcdngrhoup, dgcdngrhodn, &
        d2gcdngrhoup2, d2gcdngrhodn2, d2gcdngrhoupdrhoup, d2gcdngrhodndrhodn, &
        d2gcdngrhoupdngrhodn, d2gcdngrhodndngrhoup, &
        d2gcdngrhoupdrhodn, d2gcdngrhodndrhoup
      
      parameter(pi=acos(-1d0))
      parameter(gammac=0.006d0)

!Same paramaters as in libxc (some values in the original publications are wrong).
      if ((EC_SWITCH .eq. 'EC_HCTH93') .or. (VC_SWITCH .eq. 'VC_HCTH93')) then
        c(0) =   0.729974d0
        c(1) =   3.35287d0
        c(2) = -11.5430d0
        c(3) =   8.08564d0
        c(4) =  -4.47857d0
      elseif ((EC_SWITCH .eq. 'EC_HCTH120') .or. (VC_SWITCH .eq. 'VC_HCTH120')) then
        c(0) =   0.514730d0
        c(1) =   6.92982d0
        c(2) = -24.7073d0
        c(3) =  23.1098d0
        c(4) = -11.3234d0
      elseif ((EC_SWITCH .eq. 'EC_HCTH147') .or. (VC_SWITCH .eq. 'VC_HCTH147')) then
        c(0) =   0.542352d0
        c(1) =   7.01464d0
        c(2) = -28.3822d0
        c(3) =  35.0329d0
        c(4) = -20.4284d0
      elseif ((EC_SWITCH .eq. 'EC_HCTH407') .or. (VC_SWITCH .eq. 'VC_HCTH407')) then
        c(0) =   0.589076d0
        c(1) =   4.42374d0
        c(2) = -19.2218d0
        c(3) =  42.5721d0
        c(4) = -42.0052d0
      endif

      if (xc2 .lt. 0d0) then
        chcthc = 1d0
      else
        chcthc = xc2
      endif

      rho = rhoup + rhodn

      if (rho .gt. 1d-18) then
        rs = (0.75d0/(pi*rho))**(1d0/3d0)
        zet = (rhoup-rhodn)/rho
        call corlsd(rs,zet,eclsd,vlsdu,vlsdd,ecrs,eczet,alfc)
        ecunif = eclsd*rho
        vcunifup = vlsdu
        vcunifdn = vlsdd
      else
        ecunif = 0d0
        vcunifup = 0d0
        vcunifdn = 0d0
      endif

      if (rhoup .gt. 1d-18) then
        rs = (0.75d0/(pi*rhoup))**(1d0/3d0)
        zet = 1d0
        call corlsd(rs,zet,eclsd,vlsdu,vlsdd,ecrs,eczet,alfc)
        ecupunif = eclsd*rhoup
        vcupunif = vlsdu
      else
        ecupunif = 0d0
        vcupunif = 0d0
      endif

      if (rhodn .gt. 1d-18) then
        rs = (0.75d0/(pi*rhodn))**(1d0/3d0)
        zet = -1d0
        call corlsd(rs,zet,eclsd,vlsdu,vlsdd,ecrs,eczet,alfc)
        ecdnunif = eclsd*rhodn
        vcdnunif = vlsdd
      else
        ecdnunif = 0d0
        vcdnunif = 0d0
      endif

      ecunifud = ecunif - ecupunif - ecdnunif
      vcunifudup = vcunifup - vcupunif
      vcunifuddn = vcunifdn - vcdnunif

      if (rhoup .gt. 1d-18) then
        sup2 = ngrhoup**2/rhoup**(8d0/3d0)
        dsa2dngrhoup = ngrhoup/rhoup**(8d0/3d0)
        d2sa2dngrhoup2 = 1d0/rhoup**(8d0/3d0)
        dsa2drhoup = -4d0/3d0*ngrhoup**2/rhoup**(11d0/3d0)
        d2sa2drhoup2 = 44d0/9d0*ngrhoup**2/rhoup**(14d0/3d0)
        d2sa2drhoupdngrhoup = -8d0/3d0*ngrhoup/rhoup**(11d0/3d0)
      else
        sup2 = 0d0
        dsa2dngrhoup = 0d0
        d2sa2dngrhoup2 = 0d0
        dsa2drhoup = 0d0
        d2sa2drhoup2 = 0d0
        d2sa2drhoupdngrhoup = 0d0
      endif

      if (rhodn .gt. 1d-18) then
        sdn2 = ngrhodn**2/rhodn**(8d0/3d0)
        dsa2dngrhodn = ngrhodn/rhodn**(8d0/3d0)
        d2sa2dngrhodn2 = 1d0/rhodn**(8d0/3d0)
        dsa2drhodn = -4d0/3d0*ngrhodn**2/rhodn**(11d0/3d0)
        d2sa2drhodn2 = 44d0/9d0*ngrhodn**2/rhodn**(14d0/3d0)
        d2sa2drhodndngrhodn = -8d0/3d0*ngrhodn/rhodn**(11d0/3d0)
      else
        sdn2 = 0d0
        dsa2dngrhodn = 0d0
        d2sa2dngrhodn2 = 0d0
        dsa2drhodn = 0d0
        d2sa2drhodn2 = 0d0
        d2sa2drhodndngrhodn = 0d0
      endif

      sa2 = 0.5d0*(sup2 + sdn2)

      uc = gammac*sa2/(1d0 + gammac*sa2)

      ducdsa2 = gammac/(1d0 + gammac*sa2)**2      

      d2ucdsa22 = -2d0*gammac**2/(1d0 + gammac*sa2)**3

      gc = 0d0
      do i=0, 4
        gc = gc + c(i)*uc**i
      enddo

      dgcduc = 0d0
      do i=1, 4
        dgcduc = dgcduc + i*c(i)*uc**(i-1)
      enddo

      d2gcduc2 = 0d0
      do i=2, 4
        d2gcduc2 = d2gcduc2 + i*(i-1)*c(i)*uc**(i-2)
      enddo

      dgcdrhoup = dgcduc*ducdsa2*dsa2drhoup
      dgcdrhodn = dgcduc*ducdsa2*dsa2drhodn

      dgcdngrhoup = dgcduc*ducdsa2*dsa2dngrhoup
      dgcdngrhodn = dgcduc*ducdsa2*dsa2dngrhodn

      d2gcdngrhoup2 = d2gcduc2*ducdsa2**2*dsa2dngrhoup**2 + &
        dgcduc*d2ucdsa22*dsa2dngrhoup**2 + dgcduc*ducdsa2*d2sa2dngrhoup2
      d2gcdngrhodn2 = d2gcduc2*ducdsa2**2*dsa2dngrhodn**2 + &
        dgcduc*d2ucdsa22*dsa2dngrhodn**2 + dgcduc*ducdsa2*d2sa2dngrhodn2

      d2gcdngrhoupdrhoup = d2gcduc2*ducdsa2**2*dsa2dngrhoup*dsa2drhoup + &
        dgcduc*d2ucdsa22*dsa2dngrhoup*dsa2drhoup + &
        dgcduc*ducdsa2*d2sa2drhoupdngrhoup
      d2gcdngrhodndrhodn = d2gcduc2*ducdsa2**2*dsa2dngrhodn*dsa2drhodn + &
        dgcduc*d2ucdsa22*dsa2dngrhodn*dsa2drhodn + &
        dgcduc*ducdsa2*d2sa2drhodndngrhodn

      d2gcdngrhoupdngrhodn = d2gcduc2*ducdsa2**2*dsa2dngrhodn*dsa2dngrhoup + &
        dgcduc*d2ucdsa22*dsa2dngrhodn*dsa2dngrhoup
      d2gcdngrhodndngrhoup = d2gcduc2*ducdsa2**2*dsa2dngrhoup*dsa2dngrhodn + &
        dgcduc*d2ucdsa22*dsa2dngrhoup*dsa2dngrhodn

      d2gcdngrhoupdrhodn = d2gcduc2*ducdsa2**2*dsa2drhodn*dsa2dngrhoup + &
        dgcduc*d2ucdsa22*dsa2drhodn*dsa2dngrhoup
      d2gcdngrhodndrhoup = d2gcduc2*ducdsa2**2*dsa2drhoup*dsa2dngrhodn + &
        dgcduc*d2ucdsa22*dsa2drhoup*dsa2dngrhodn

      ecud = chcthc*ecunifud*gc

      if (ngrhoup .gt. 1d-18) then
        vcudup = chcthc*(vcunifudup*gc + ecunifud*dgcdrhoup - &
          dgcdngrhoup*(vcunifudup*ngrhoup + vcunifuddn*grhoupgrhodn/ngrhoup) - &
          ecunifud*(d2gcdngrhoupdrhoup*ngrhoup + d2gcdngrhoupdrhodn*grhoupgrhodn/ngrhoup + &
          d2gcdngrhoup2*grhoupgngrhoup/ngrhoup + d2gcdngrhoupdngrhodn*grhoupgngrhodn/ngrhoup - &
          dgcdngrhoup*grhoupgngrhoup/ngrhoup**2 + dgcdngrhoup*lrhoup/ngrhoup))
      else
        vcudup = 0d0
      endif

      if (ngrhodn .gt. 1d-18) then
        vcuddn = chcthc*(vcunifuddn*gc + ecunifud*dgcdrhodn - &
          dgcdngrhodn*(vcunifuddn*ngrhodn + vcunifudup*grhodngrhoup/ngrhodn) - &
          ecunifud*(d2gcdngrhodndrhodn*ngrhodn + d2gcdngrhodndrhoup*grhodngrhoup/ngrhodn + &
          d2gcdngrhodn2*grhodngngrhodn/ngrhodn + d2gcdngrhodndngrhoup*grhodngngrhoup/ngrhodn - &
          dgcdngrhodn*grhodngngrhodn/ngrhodn**2 + dgcdngrhodn*lrhodn/ngrhodn))
      else
        vcuddn = 0d0
      endif

      return
      end
