      subroutine hcthx(up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap, &
                       exup,exdn,vxup,vxdn)

!F. A. Hamprecht et al., J. Chem. Phys. 109, 6264 (1998).
!A. D. Boese et al., J. Chem. Phys. 112, 1670 (2000).
!A. D. Boese and N. C. Handy, J. Chem. Phys. 114, 5497 (2001).

      implicit none

      real*8, intent(in) :: up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap
      real*8, intent(out) :: exup,exdn,vxup,vxdn

      if((up.gt.1d-18) .and. (agrup.gt.1d-18))then
        call exchhcthx(up,agrup,delgrup,uplap,exup,vxup)
      else
        exup=0d0
        vxup=0d0
      endif
      
      if((dn.gt.1d-18) .and. (agrdn.gt.1d-18))then
        call exchhcthx(dn,agrdn,delgrdn,dnlap,exdn,vxdn)
      else
        exdn=0d0
        vxdn=0d0
      endif

      return
      end

!-----------------------------------------------------------------------

      subroutine exchhcthx(rho,ngrho,grhogngrho,lrho,ex,vx)

      use xcparam, only : EX_SWITCH, VX_SWITCH, xc1

      implicit none

      integer :: i
      real*8, intent(in) :: rho, ngrho, grhogngrho, lrho
      real*8, intent(out) :: ex, vx
      real*8 :: ax, gammax, c(0:4), chcthx, exunif, vxunif, s2, ds2dngrho, &
        d2s2dngrho2, ds2drho, d2s2drho2, d2s2drhodngrho, ux, duxds2, &
        d2uxds22, gx, dgxdux, d2gxdux2, dgxdrho, dgxdngrho, &
        d2gxdngrho2, d2gxdngrhodrho

      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(gammax=0.004d0)

!Same paramaters as in libxc (some values in the original publications are wrong).
      if ((EX_SWITCH .eq. 'EX_HCTH93') .or. (VX_SWITCH .eq. 'VX_HCTH93')) then
        c(0) =  1.09320d0
        c(1) = -0.744056d0
        c(2) =  5.59920d0
        c(3) = -6.78549d0
        c(4) =  4.49357d0
      elseif ((EX_SWITCH .eq. 'EX_HCTH120') .or. (VX_SWITCH .eq. 'VX_HCTH120')) then
        c(0) =  1.09163d0
        c(1) = -0.747215d0
        c(2) =  5.07833d0
        c(3) = -4.10746d0
        c(4) =  1.17173d0
      elseif ((EX_SWITCH .eq. 'EX_HCTH147') .or. (VX_SWITCH .eq. 'VX_HCTH147')) then
        c(0) =  1.09025d0
        c(1) = -0.799194d0
        c(2) =  5.57212d0
        c(3) = -5.86760d0
        c(4) =  3.04544d0
      elseif ((EX_SWITCH .eq. 'EX_HCTH407') .or. (VX_SWITCH .eq. 'VX_HCTH407')) then
        c(0) =  1.08184d0
        c(1) = -0.518339d0
        c(2) =  3.42562d0
        c(3) = -2.62901d0
        c(4) =  2.28855d0
      endif

      if (xc1 .lt. 0d0) then
        chcthx = 1d0
      else
        chcthx = xc1
      endif

      exunif = 0.5d0*ax*(2d0*rho)**(4d0/3d0)

      vxunif = (4d0/3d0)*ax*(2d0*rho)**(1d0/3d0)

      s2 = ngrho**2/rho**(8d0/3d0)

      ds2dngrho = 2d0*ngrho/rho**(8d0/3d0)

      d2s2dngrho2 = 2d0/rho**(8d0/3d0)

      ds2drho = -8d0/3d0*ngrho**2/rho**(11d0/3d0)

      d2s2drho2 = 88d0/9d0*ngrho**2/rho**(14d0/3d0)

      d2s2drhodngrho = -16d0/3d0*ngrho/rho**(11d0/3d0)

      ux = gammax*s2/(1d0 + gammax*s2)

      duxds2 = gammax/(1d0 + gammax*s2)**2      

      d2uxds22 = -2d0*gammax**2/(1d0 + gammax*s2)**3

      gx = 0d0
      do i=0, 4
        gx = gx + c(i)*ux**i
      enddo

      dgxdux = 0d0
      do i=1, 4
        dgxdux = dgxdux + i*c(i)*ux**(i-1)
      enddo

      d2gxdux2 = 0d0
      do i=2, 4
        d2gxdux2 = d2gxdux2 + i*(i-1)*c(i)*ux**(i-2)
      enddo

      dgxdrho = dgxdux*duxds2*ds2drho

      dgxdngrho = dgxdux*duxds2*ds2dngrho

      d2gxdngrho2 = d2gxdux2*duxds2**2*ds2dngrho**2 + &
        dgxdux*d2uxds22*ds2dngrho**2 + dgxdux*duxds2*d2s2dngrho2

      d2gxdngrhodrho = d2gxdux2*duxds2**2*ds2dngrho*ds2drho + &
        dgxdux*d2uxds22*ds2dngrho*ds2drho + &
        dgxdux*duxds2*d2s2drhodngrho

      ex = chcthx*exunif*gx/rho

      vx = chcthx*(vxunif*gx + exunif*dgxdrho - vxunif*dgxdngrho*ngrho - &
           exunif*(d2gxdngrhodrho*ngrho + d2gxdngrho2*grhogngrho/ngrho - &
           dgxdngrho*grhogngrho/ngrho**2 + dgxdngrho*lrho/ngrho))

      return
      end
