      subroutine htbs(up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap, &
        exup,exdn,vxup,vxdn)

      implicit real*8(a-h,o-z)
      parameter(thrd=1.d0/3.d0)
      parameter(pi32=29.608813203268075856503472999628d0)

      rho2=2.d0*up
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrup/(2.d0*fk*rho2)
        u=4.d0*delgrup/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*uplap/(rho2*(2.d0*fk)**2)
        call exchhtbs(rho2,s,u,v,exup,vxup)
      else
        exup=0.d0
        vxup=0.d0
      endif
      
      rho2=2.d0*dn
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrdn/(2.d0*fk*rho2)
        u=4.d0*delgrdn/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*dnlap/(rho2*(2.d0*fk)**2)
        call exchhtbs(rho2,s,u,v,exdn,vxdn)
      else
        exdn=0.d0
        vxdn=0.d0
      endif

      return
      end

!----------------------------------------------------------------------
      subroutine exchhtbs(rho,s,u,v,ex,vx)

      implicit real*8 (a-h,o-z)
      real*8, allocatable :: cm(:)

      parameter(thrd=1.d0/3.d0,thrd4=4.d0/3.d0)
      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(ckappa=0.804d0,cmu=0.21951d0,cc=0.0079325d0)
      parameter(sc1=0.6d0,sc2=2.6d0)

      exunif = ax*rho**thrd

      s2 = s*s

      xwc = 10d0/81d0*s2 + (cmu - 10d0/81d0)*s2*dexp(-s2) + &
        dlog(1d0 + cc*s2*s2)

      fxwc = 1d0 + ckappa - ckappa/(1d0 + xwc/ckappa)

      ywc = 20d0/81d0 + (2d0*cmu - 20d0/81d0)*(1d0 - s2)*dexp(-s2) + &
        4d0*cc*s2/(1d0 + cc*s2*s2)

      fswc = ywc/(1d0 + xwc/ckappa)**2d0

      dywc = (4d0*cmu - 40d0/81d0)*(s2*s - 2d0*s)*dexp(-s2) + &
        8d0*cc*s*(1d0 - cc*s2*s2)/(1d0 + cc*s2*s2)**2d0

      fsswc = dywc/(1d0 + xwc/ckappa)**2d0 - &
        2d0/ckappa*s*ywc**2d0/(1d0 + xwc/ckappa)**3d0

      fxrpbe = 1d0 + ckappa*(1d0 - dexp(-(cmu/ckappa)*s2))

      fsrpbe = 2d0*cmu*dexp(-(cmu/ckappa)*s2)

      fssrpbe = -4d0*(cmu*cmu/ckappa)*s*dexp(-(cmu/ckappa)*s2)

      if (s .le. sc1) then

        fx = fxwc

        fs = fswc

        fss = fsswc

      elseif ((s .gt. sc1) .and. (s .le. sc2)) then

        nm = 6
        allocate(cm(nm))

        cm(1) = -0.40608d0
        cm(2) =  2.28150d0
        cm(3) = -4.68000d0
        cm(4) =  4.17500d0
        cm(5) = -1.50000d0
        cm(6) =  0.18750d0

        gm = 0d0
        do im=1, nm
          gm = gm + cm(im)*s**(im-1)
        enddo

        dgm = 0d0
        do im=2, nm
          dgm = dgm + (im - 1d0)*cm(im)*s**(im-2)
        enddo

        d2gm = 0d0
        do im=3, nm
          d2gm = d2gm + (im - 1d0)*(im - 2d0)*cm(im)*s**(im-3)
        enddo

        fx = gm*fxrpbe + (1d0 - gm)*fxwc

        fs = dgm*fxrpbe/s + gm*fsrpbe + fswc - dgm*fxwc/s - gm*fswc

        d2fxwcs = fsswc + fswc/s

        d2fxrpbes = fssrpbe + fsrpbe/s

        d2fxs = d2gm*fxrpbe/s + 2d0*dgm*fsrpbe + gm*d2fxrpbes + &
          d2fxwcs - d2gm*fxwc/s - 2d0*dgm*fswc - gm*d2fxwcs

        fss = -fs/s + d2fxs

      elseif (s .gt. sc2) then

        fx = fxrpbe

        fs = fsrpbe

        fss = fssrpbe

      endif

      ex = exunif*fx

      vx = exunif*(thrd4*fx-(u-thrd4*s2*s)*fss-v*fs)

      return

      end
