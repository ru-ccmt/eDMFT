      subroutine scanx(rhoup,gmagup,tauup,rhodn,gmagdn,taudn,exup,exdn)

!J. Sun, A. Ruzsinszky, and J. P. Perdew, Phys. Rev. Lett. 115, 036402 (2015).

      implicit none

      real*8, intent(in) :: rhoup, gmagup, tauup, rhodn, gmagdn, taudn

      real*8, intent(out) :: exup, exdn

      if (rhoup .gt. 1d-18) then
         call exscanx(rhoup,gmagup,tauup,exup)
      else
         exup = 0d0
      endif

      if (rhodn .gt. 1d-18) then
         call exscanx(rhodn,gmagdn,taudn,exdn)
      else
         exdn = 0d0
      endif

      return

      end

!-----------------------------------------------------------------------

      subroutine exscanx(rho,gmag,tau,ex)

      implicit none

      real*8, intent(in) :: rho, gmag, tau

      real*8, intent(out) :: ex

      real*8 :: a1, alpha, ax, b1, b2, b3, b4, c1x, c2x, dx, exlda, &
         fxa, fxsa, gx, hx0, hx1, k1, muak, pi, s, tautf, tauw, x

      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(pi=3.1415926535897932384626433832795d0)
      parameter(k1=0.065d0)
      parameter(muak=10d0/81d0)
      parameter(a1=4.9479d0)
      parameter(b2=(5913d0/405000)**0.5d0)
      parameter(b1=(511d0/13500d0)/(2d0*b2))
      parameter(b3=0.5d0)
      parameter(b4=muak**2/k1-1606d0/18225d0-b1**2)
      parameter(c1x=0.667d0)
      parameter(c2x=0.8d0)
      parameter(dx=1.24d0)
      parameter(hx0=1.174d0)

      exlda = ax*(2d0*rho)**(1d0/3d0)

      s = gmag/((3d0*pi**2)**(1d0/3d0)*(2d0*rho)**(4d0/3d0))

      tautf = 0.6d0*(6d0*pi**2)**(2d0/3d0)*rho**(5d0/3d0)

      tauw = 0.25d0*gmag**2/rho

      alpha = (max(2d0*tau,tauw) - tauw)/tautf

      x = muak*s**2*(1d0 + b4*s**2/muak*exp(-abs(b4)*s**2/muak)) + &
         (b1*s**2 + b2*(1d0 - alpha)*exp(-b3*(1d0 - alpha)**2))**2

      if ((1d0-alpha) .gt. 1d-18) then
         fxa = exp(-c1x*alpha/(1d0-alpha))
      elseif ((alpha-1d0) .gt. 1d-18) then
         fxa = -dx*exp(c2x/(1d0-alpha))
      else
         fxa = 0d0
      endif

      if (s .gt. 1d-18) then
         gx = 1d0 - exp(-a1/s**(1d0/2d0))
      else
         gx = 1d0
      endif

      hx1 = 1d0 + k1 - k1/(1d0 + x/k1)

      fxsa = (hx1 + fxa*(hx0 - hx1))*gx

      ex = exlda*fxsa

      return

      end
