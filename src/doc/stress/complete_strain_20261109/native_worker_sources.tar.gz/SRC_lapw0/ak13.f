      subroutine ak13(up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap, &
                      exup,exdn,vxup,vxdn)

!R. Armiento and S. Kuemmel, Phys. Rev. Lett. 111, 036402 (2013).

      implicit none

      real*8, intent(in) :: up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap
      real*8, intent(out) :: exup,exdn,vxup,vxdn
      real*8 :: fk,pi32,rho2,s,thrd,u,v

      parameter(thrd=1.d0/3.d0)
      parameter(pi32=3d0*(4d0*atan(1d0))**2)

      rho2=2.d0*up
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrup/(2.d0*fk*rho2)
        u=4.d0*delgrup/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*uplap/(rho2*(2.d0*fk)**2)
        call exchak13(rho2,s,u,v,exup,vxup)
      else
        exup=0.d0
        vxup=0.d0
      endif
      
      rho2=2.d0*dn
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrdn/(2.d0*fk*rho2)
        u=4.d0*delgrdn/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*dnlap/(rho2*(2.d0*fk)**2)
        call exchak13(rho2,s,u,v,exdn,vxdn)
      else
        exdn=0.d0
        vxdn=0.d0
      endif

      return
      end

!-----------------------------------------------------------------------

      subroutine exchak13(rho,s,u,v,ex,vx)

      implicit none

      real*8, intent(in) :: rho,s,u,v
      real*8, intent(out) :: ex,vx
      real*8 :: ax,b1,b2,cmu,exunif,fs,fss,fx,log1s,pi,s2,thrd,thrd4

      parameter(thrd=1.d0/3.d0,thrd4=4.d0/3.d0)
      parameter(pi=4d0*atan(1d0))
      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(cmu=10d0/81d0,b1=3d0/5d0*cmu+8d0/15d0*pi,b2=cmu-b1)
      
! construct lda exchange energy density
      exunif = ax*rho**thrd

! construct AK13 enhancement factor
      s2 = s*s
      log1s = log(1d0+s)

      fx = 1d0 + b1*s*log1s + b2*s*log(1d0+log1s)

      ex = exunif*fx

!  energy done. now the potential:
!  find first and second derivatives of fx w.r.t s.
!  fs=(1/s)*d fx/ ds
!  fss=d fs/ds
      if (s .gt. 1d-18) then
        fs = b1*(log1s/s + 1d0/(1d0+s)) + &
             b2*(log(1d0+log1s)/s + 1d0/((1d0+s)*(1d0+log1s)))

        fss = b1*(-log1s/s2 + 1d0/(s*(1d0+s)) - 1d0/(1d0+s)**2) + &
              b2*(-log(1d0+log1s)/s2 + 1d0/(s*(1+s)*(1d0+log1s)) - &
              1d0/((1d0+s)**2*(1d0+log1s)) - 1d0/((1d0+s)**2*(1d0+log1s)**2))
      else
        fs = 0d0
        fss = 0d0
      endif

      vx = exunif*(thrd4*fx-(u-thrd4*s2*s)*fss-v*fs)

      return
      end
