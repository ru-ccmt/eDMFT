      subroutine mgga_ms(rhoup,gmagup,tauup,rhodn,gmagdn,taudn,gr,exup,exdn,ec)

!J. Sun, B. Xiao, and A. Ruzsinszky, J. Chem. Phys. 137, 051101 (2012).
!J. Sun et al., J. Chem. Phys. 138, 044113 (2013).

      implicit none

      real*8, intent(in) :: rhoup, gmagup, tauup, rhodn, gmagdn, &
         taudn, gr

      real*8, intent(out) :: exup, exdn, ec

      real*8 :: aa, alpha, bb, cc, ccc, ecc, fac, fer, gg, &
         hh, pi, rho, rs, sk, tt, twoksg, zeta

      parameter(aa = 0.9269d0, bb = 0.6225d0, cc = 2.1540d0)
      parameter(alpha = 1.91915829267751300662482032624669d0)
      parameter(fac = 3.09366772628013593097d0)
      parameter(pi = 3.1415926535897932384626433832795d0)

      if (rhoup .gt. 1.d-18) then
         call mgga_ms_x(rhoup,gmagup,2.d0*tauup,exup)
      else
         exup = 0.d0
      endif

      if (rhodn .gt. 1.d-18) then
         call mgga_ms_x(rhodn,gmagdn,2.d0*taudn,exdn)
      else
         exdn = 0.d0
      endif

      rho = rhoup + rhodn
      if (rho .gt. 1.d-18) then
         zeta = (rhoup - rhodn)/rho
         ccc = 0.59d0 + aa*zeta**2.d0 + bb*zeta**4.d0 + cc*zeta**6.d0
         gg = 0.5d0*((1.0d0+zeta)**(2.d0/3.d0) + (1.0d0-zeta)**(2.d0/3.d0))
         fer = fac*rho**(1.d0/3.d0)
         rs = alpha/fer
         sk = dsqrt(4.0d0*fer/pi)
         twoksg = 2.0d0*sk*gg
         tt = gr/(twoksg*rho)
         call corpbe_revtpss(rs,zeta,tt,ecc,hh,ec)
      endif

      return

      end

!-----------------------------------------------------------------------

      subroutine mgga_ms_x(rho,gmag,tau,ex)

!xc1 = kappa, xc2 = c, xc3 = b
!For MGGA_MS0: kappa = 0.29,  c = 0.28771, b = 1.0
!For MGGA_MS1: kappa = 0.404, c = 0.18150, b = 1.0
!For MGGA_MS2: kappa = 0.504, c = 0.14601, b = 4.0

      use xcparam, only : xc1, xc2, xc3

      implicit none

      real*8, intent(in) :: rho, gmag

      real*8, intent(out) :: ex

      real*8 :: tau

      real*8 :: alpha, ax, exlda, f, fx, fx0, fx1, mu, p, pi, tautf, tauw

      parameter(ax = -0.738558766382022405884230032680836d0)
      parameter(pi = 3.1415926535897932384626433832795d0)
      parameter(mu = 10.d0/81.d0)

      exlda = ax*(2.d0*rho)**(1.d0/3.d0)

      p = gmag**2/(4.d0*(6.d0*pi**2)**(2.d0/3.d0)*rho**(8.d0/3.d0))

      tautf = 0.6d0*(6.d0*pi**2)**(2.d0/3.d0)*rho**(5.d0/3.d0)

      tauw = 0.25d0*gmag**2/rho

      if (tau .lt. tauw) tau = tauw

      alpha = (tau - tauw)/tautf

      fx0 = 1.d0 + xc1 - xc1/(1.d0 + (mu*p + xc2)/xc1)

      fx1 = 1.d0 + xc1 - xc1/(1.d0 + mu*p/xc1)

      f = (1.d0 - alpha**2)**3/(1.d0 + alpha**3 + xc3*alpha**6)

      fx = fx1 + f*(fx0 - fx1)

      ex = exlda*fx

      return

      end
