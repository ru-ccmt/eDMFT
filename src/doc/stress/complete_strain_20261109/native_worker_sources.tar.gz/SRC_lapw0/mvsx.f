      subroutine mvsx(rhoup,gmagup,tauup,rhodn,gmagdn,taudn,exup,exdn)

!J. Sun, J. P. Perdew, and A. Ruzsinszky, Proc. Natl. Acad. Sci. U.S.A. 112, 685 (2015).

      implicit none

      real*8, intent(in) :: rhoup, gmagup, tauup, rhodn, gmagdn, taudn

      real*8, intent(out) :: exup, exdn

      if (rhoup .gt. 1d-18) then
         call exmvsx(rhoup,gmagup,tauup,exup)
      else
         exup = 0d0
      endif

      if (rhodn .gt. 1d-18) then
         call exmvsx(rhodn,gmagdn,taudn,exdn)
      else
         exdn = 0d0
      endif

      return

      end

!-----------------------------------------------------------------------

      subroutine exmvsx(rho,gmag,tau,ex)

      implicit none

      real*8, intent(in) :: rho, gmag, tau

      real*8, intent(out) :: ex

      real*8 :: alpha, ax, b, c1, e1, exlda, fxa, fxsa, hx0, hx1, k0, &
         pi, s, tautf, tauw

      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(pi=3.1415926535897932384626433832795d0)
      parameter(b=0.0233d0)
      parameter(k0=0.174d0)
      parameter(hx0=1d0+k0)
      parameter(hx1=1d0)
      parameter(c1=0.7438d0)
      parameter(e1=-1.6665d0)

      exlda = ax*(2d0*rho)**(1d0/3d0)

      s = gmag/((3d0*pi**2)**(1d0/3d0)*(2d0*rho)**(4d0/3d0))

      tautf = 0.6d0*(6d0*pi**2)**(2d0/3d0)*rho**(5d0/3d0)

      tauw = 0.25d0*gmag**2/rho

      alpha = (max(2d0*tau,tauw) - tauw)/tautf

      fxa = (1d0 - alpha)/((1d0 + e1*alpha**2)**2 + c1*alpha**4)**0.25d0

      fxsa = (hx1 + fxa*(hx0 - hx1))/(1d0 + b*s**4)**0.125d0

      ex = exlda*fxsa

      return

      end
