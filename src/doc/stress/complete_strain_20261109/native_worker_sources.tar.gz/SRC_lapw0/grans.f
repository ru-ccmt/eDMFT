! compute laplacian and cartesian derivatives from angular derivatives
! Cartesian axes are defined as e_x = e_r
!                               e_y = e_t
!                               e_z = e_p
      subroutine grans(r,qsin,qcos,dndr,dndt,dndp, &          ! input
                       d2ndr,d2ndt,d2ndp,dndrt,dndrp,dndtp, & ! input
                       gx,gy,gz,gmag,g2,ggx,ggy,ggz,gdgg,ir)  ! output              
!
!     implicit real*8 (a-h,o-z)
      implicit none

!     ARGUMENTS
      real*8, intent(in)   :: r, qsin, qcos, dndr, dndt, dndp, &
           d2ndr,d2ndt,d2ndp,dndrt,dndrp,dndtp
      integer,intent(in)   :: ir
      real*8, intent(out)  :: gx,gy,gz,gmag,g2,ggx,ggy,ggz,gdgg

!     LOCAL VARIABLES 
      real*8               :: r2, g2x, g2y,g2z, qsin2
      
      r2=r*r
      if(abs(qsin).lt.1D-10)then
        gx=dndr
        gy=dndt/r
        gz=0
        gmag=dsqrt(gx*gx+gy*gy)
        g2x=d2ndr+2.0D0*dndr/r
        g2y=d2ndt/r2
        g2z=0
        g2=g2x+g2y
        ggx=dndr*d2ndr+dndt*(dndrt-dndt/r)/r2
        ggy=(dndr*dndrt+ dndt*d2ndt/r2 )/r
        ggz=0
        goto 100
      endif

      qsin2=qsin*qsin
!
      gx=dndr
      gy=dndt/r
      gz=dndp/r/qsin
!
      gmag=dsqrt(gx*gx+gy*gy+gz*gz)
!
      g2x=d2ndr+2.d0*dndr/r
      g2y=(d2ndt+qcos/qsin*dndt)/r2
      g2z=d2ndp/r2/qsin2
      g2=g2x+g2y+g2z
!      if(ir.eq.4)write(6,'(8e15.5)') g2,g2x,g2y,g2z,d2ndr,2.d0*dndr/r
!     *, dndr,r
!
      ggx=dndr*d2ndr+ &
          dndt*(dndrt-dndt/r)/r2+ &
          dndp*(dndrp-dndp/r)/r2/qsin2
      ggy=(dndr*dndrt+ &
           dndt*d2ndt/r2+ &
           dndp*(dndtp-qcos/qsin*dndp)/r2/qsin2)/r
      ggz=(dndr*dndrp+ &
           dndt*dndtp/r2+ &
           dndp*d2ndp/r2/qsin2)/r/qsin

100   if(gmag .lt. 1D-20)then
        gmag=0
        ggx=0
        ggy=0
        ggz=0
      else
        ggx=ggx/gmag  
        ggy=ggy/gmag  
        ggz=ggz/gmag
      endif  
!
      gdgg=gx*ggx+gy*ggy+gz*ggz
!
      return
      end
