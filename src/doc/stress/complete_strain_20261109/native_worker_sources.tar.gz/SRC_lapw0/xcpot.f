      FUNCTION XCPOT(RHO,RHOSP,PI)                          
!                                                                       
      IMPLICIT REAL*8 (A-H,O-Z)
      REAL*8 XCPOT 
      REAL*8 NUCE,MUCP,MUCF                                             
!     IEX=1  SPINPOLARIZED JMW PARAMETERS                               
      parameter (CCut=1D-12)
      parameter (C1=-.045D0,C2=-.0225D0)                                      
      parameter (A1=21.0D0,A2=52.9167D0)
      parameter (ONETH=1.D0/3.D0, FOURTH=4.D0/3.D0)   
      parameter (T016PS=0.01899721D0,GAMMA=5.1297628D0,CMUXP=1.2217741D0)     

!
!     CHANGED HERE
!      if((RHO .lt. CCut).or.(RHOSP .lt. CCut))then
!        xcpot=0.0
!        return
!      endif
      RHO=max(rho,1d-12)
      RHOSP=max(rhosp,1D-12)
      BETA=1.0d0
      RHOH=2.0d0*RHOSP
      XCPOT=-BETA*2.D0*(3.D0/PI*RHOH)**(1.D0/3.D0)
!
!      RS=(0.75D0/PI/RHO)**(1.D0/3.D0)                                   
!      BETA=1.0d0                                            
!      RHOH=2.0d0*RHOSP
!      IF(IEX.EQ.1) GOTO 100                                             
!      RHOH=RHO
!      IF(IEX.EQ.2) THEN                                                 
!      BETA=1.d0+0.0316D0*RS*LOG(1.D0+24.3D0/RS)                           
!.....HEDIN-LUNDQIST APPROXIMATION IN LINE ABOVE                        
!     BETA=1.d0+(.9604D0*RS*(RS+5.85D0)/(RS+7.8D0)**2)                    
!.....WIGNER APPROXIMATION IN LINE ABOVE                                
!      ELSE IF(IEX.EQ.3) THEN                                            
!      BETA=1.d0+0.03683D0*RS*LOG(1.D0+21.0D0/RS)                          
!      ELSE IF(IEX.EQ.4) THEN                                            
!      BETA=1.d0+0.0545D0*RS*LOG(1.D0+11.4D0/RS)                           
!      ELSE IF((IEX.EQ.5) .OR. (IEX.EQ.6)) THEN
!      BETA=1.0d0                                            
!      RHOH=2.0d0*RHOSP
!      END IF                                                            
!      XCPOT=-BETA*2.D0*(3.D0/PI*RHOH)**(1.D0/3.D0)                       
!      RETURN                                                            
!  100 CONTINUE                                                          
!                                                                       
!.... SPINPOLARIZED POTENTIAL, JMW PARAMETERS                           
!                                                                       
!      XI=RHOSP/RHO                                                      
!      X=RS/A1                                                           
!      MUCP=C1*LOG(1.0d0+1.0D0/X)                                          
!      EFMEP=-C1*F(X)                                                    
!      X=RS/A2                                                           
!      MUCF=C2*LOG(1.0D0+1.0D0/X)                                        
!      EFMEP=EFMEP+C2*F(X)                                               
!      NUCE=GAMMA*EFMEP                                                  
!      TAUCE=MUCF-MUCP-FOURTH*EFMEP                                      
!      XCPOT=(-CMUXP/RS+NUCE)*((2.0D0*XI)**ONETH)-NUCE+MUCP               &
!        +TAUCE*FOFXI(XI)                                                
!      RETURN                                                            
      END                                                               
