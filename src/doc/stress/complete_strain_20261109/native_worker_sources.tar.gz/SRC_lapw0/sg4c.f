      subroutine sg4c(up,agrup,uplap,dn,agrdn,dnlap,agr,delgr, &
         ecpbe,vcuppbe,vcdnpbe)
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! SG4c is a driver for the SG4c subroutines, using simple inputs
! inputs: up=up density
!	: agrup=|grad up|
!	: uplap=grad^2 up=Laplacian of up
!	: dn,agrdn,dnlap=corresponding down quantities
!	: agr=|grad rho|
!	: delgr=(grad rho).(grad |grad rho|) 
! outputs: ecpbe,vcup(dn)pbe=SG4c quantities
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! needed constants:
! pi32=3*pi**2
! alpha=(9pi/4)**thrd
      implicit real*8(a-h,o-z)
      parameter(thrd=1.d0/3.d0,thrd2=2.d0*thrd)
      parameter(pi32=29.608813203268075856503472999628d0)
      parameter(pi=3.1415926535897932384626433832795d0)
      parameter(alpha=1.91915829267751300662482032624669d0)
! Now do correlation
! zet=(up-dn)/rho
! g=phi(zeta)
! rs=(3/(4pi*rho))^(1/3)=local Seitz radius=alpha/fk
! sk=Ks=Thomas-Fermi screening wavevector=sqrt(4fk/pi)
! twoksg=2*Ks*phi
! t=correlation dimensionless gradient=|grad rho|/(2*Ks*phi*rho)
! uu=delgrad/(rho^2*twoksg^3)
! rholap=Laplacian
! vv=Laplacian/(rho*twoksg^2)
! ww=(|grad up|^2-|grad dn|^2-zet*|grad rho|^2)/(rho*twoksg)^2
! ec=lsd correlation energy
! vcup=lsd up correlation potential
! vcdn=lsd down correlation potential
! h=gradient correction to correlation energy
! dvcup=gradient correction to up correlation potential
! dvcdn=gradient correction to down correlation potential
      rho=up+dn
      if(rho.lt.1.d-18)return
      zet=(up-dn)/rho
      g=((1.d0+zet)**thrd2+(1.d0-zet)**thrd2)/2.d0
      fk=(pi32*rho)**thrd
      rs=alpha/fk
      sk=sqrt(4.d0*fk/pi)
      twoksg=2.d0*sk*g
      t=agr/(twoksg*rho)
      uu=delgr/(rho*rho*twoksg**3)
      rholap=uplap+dnlap
      vv=rholap/(rho*twoksg**2)
      ww=(agrup**2-agrdn**2-zet*agr**2)/(rho*rho*twoksg**2)
      call CORSG4(RS,ZET,T,UU,VV,WW,1,1,ec,vcup,vcdn, &
                        H,DVCUP,DVCDN)
      ecpbe=ec+h
      vcuppbe=vcup+dvcup
      vcdnpbe=vcdn+dvcdn
      return
      end
!----------------------------------------------------------------------
!######################################################################
!----------------------------------------------------------------------
      SUBROUTINE CORSG4(RS,ZET,T,UU,VV,WW,lgga,lpot,ec,vcup,vcdn, &
                        H,DVCUP,DVCDN)
!----------------------------------------------------------------------
!  INPUT: RS=SEITZ RADIUS=(3/4pi rho)^(1/3)
!       : ZET=RELATIVE SPIN POLARIZATION = (rhoup-rhodn)/rho
!       : t=ABS(GRAD rho)/(rho*2.*KS*G)  -- only needed for SG4c
!       : UU=(GRAD rho)*GRAD(ABS(GRAD rho))/(rho**2 * (2*KS*G)**3)
!       : VV=(LAPLACIAN rho)/(rho * (2*KS*G)**2)
!       : WW=(GRAD rho)*(GRAD ZET)/(rho * (2*KS*G)**2
!       :  UU,VV,WW, only needed for SG4c potential
!       : lgga=flag to do gga (0=>LSD only)
!       : lpot=flag to do potential (0=>energy only)
!  output: ec=lsd correlation energy from [a]
!        : vcup=lsd up correlation potential
!        : vcdn=lsd dn correlation potential
!        : h=NONLOCAL PART OF CORRELATION ENERGY PER ELECTRON
!        : dvcup=nonlocal correction to vcup
!        : dvcdn=nonlocal correction to vcdn
!----------------------------------------------------------------------
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! thrd*=various multiples of 1/3
! numbers for use in LSD energy spin-interpolation formula, [c](9).
!      GAM= 2^(4/3)-2
!      FZZ=f''(0)= 8/(9*GAM)
! numbers for construction of SG4c
!      gamma=(1-log(2))/pi^2
!      eta=small number to stop d phi/ dzeta from blowing up at 
!          |zeta|=1.

      implicit none

      integer, intent(in) :: lgga, lpot

      real*8, intent(in) :: rs, t, uu, vv, ww, zet

      real*8, intent(out) :: dvcdn, dvcup, ec, h, vcdn, vcup

      real*8 :: alfc, alfm, alfrsm, alphasg, b, b2, bec, bet, bet0, &
        bg, comm, d2adbetadec, d2adzetadbeta, d2betadrsdt, d2fsgdt2, &
        d2fsgdzeta2, d2fsgdzetadt, d2hdbeta2, d2hdbetadec, d2hdt2, &
        d2hdtdbeta, d2hdtdec, d2hdzetadbeta, d2hdzetadt, d2hsgdrsdt, &
        d2hsgdt2, d2hsgdzetadt, d2m1dbeta2, d2m1dbetadec, d2m1dt2, &
        d2m1dtdbeta, d2m1dtdec, d2m1dzetadbeta, d2m1dzetadt, &
        d2m2dbetadec, d2m2dt2,d2m2dtdbeta, d2m2dtdec, d2m2dzetadbeta, &
        d2m2dzetadt, d2q4dbetadec, d2q4dt2, d2q4dtdbeta, d2q4dtdec, &
        d2q4dzetadbeta, d2q4dzetadt, d2q5dbeta2, d2q5dbetadec, d2q5dt2, &
        d2q5dtdbeta, d2q5dtdec, d2q5dzetadbeta, d2q5dzetadt, dadbeta, &
        dadec, dadzeta, dbetadrs, dbetadt, delt, dfsgdt, &
        dfsgdzeta, dhdbeta, dhdec, dhdt, dhdzeta, dhsgdbeta, dhsgdrs, &
        dhsgdt, dhsgdzeta, dm1dbeta, dm1dec, dm1dt, dm1dzeta, dm2dbeta, &
        d2m2dbeta2, dm2dec, dm2dt, dm2dzeta, dq4dbeta, dq4dec, dq4dt, &
        dq4dzeta, dq5dbeta, dq5dec, dq5dt, dq5dzeta, ecrs, eczet, ep, &
        eprs, eta, eu, eurs, f, fac, fact0, fact1, fact2, fact3, fact5, &
        fsg, fz, fzz, g, g2, g3, g4, gam, gamma, gz, gz2, hb, hbt, hrs, &
        hrst, hsg, hsgrs, hsgrst, hsgt, hsgtt, hsgz, hsgzt, ht, htt, &
        hz, hzt, m1, m2, pi, pon, pref, q4, q5, q8, q9, rs2, rs3, &
        rsthrd, sigma, sixthm, t2, t3, t4, t6, thrd, thrd2, thrd4, thrdm, z4

      parameter(pi=acos(-1d0))
      parameter(thrd=1.d0/3.d0,thrdm=-thrd,thrd2=2.d0*thrd)
      parameter(sixthm=thrdm/2.d0)
      parameter(thrd4=4.d0*thrd)
      parameter(GAM=0.5198420997897463295344212145565d0)
      parameter(fzz=8.d0/(9.d0*GAM))
      parameter(gamma=0.03109069086965489503494086371273d0)
      parameter(eta=1.d-12)
      parameter(alphasg=0.8d0)
      parameter(bet0=3d0*0.26d0/pi**2)
      parameter(sigma=0.07d0)
      bet = bet0 + sigma*t*(1d0 - exp(-rs**2))
      delt=bet/gamma
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! find LSD energy contributions, using [c](10) and Table I[c].
! EU=unpolarized LSD correlation energy
! EURS=dEU/drs
! EP=fully polarized LSD correlation energy
! EPRS=dEP/drs
! ALFM=-spin stiffness, [c](3).
! ALFRSM=-dalpha/drs
! F=spin-scaling factor from [c](9).
! construct ec, using [c](8)
      CALL gcor(0.0310907D0,0.21370D0,7.5957D0,3.5876D0,1.6382D0, &
          0.49294D0,1.0D0,RS,EU,EURS)
      CALL gcor(0.01554535D0,0.20548D0,14.1189D0,6.1977D0,3.3662D0, &
          0.62517D0,1.0D0,RS,EP,EPRS)
      CALL gcor(0.0168869D0,0.11125D0,10.357D0,3.6231D0,0.88026D0, &
          0.49671D0,1.0D0,RS,ALFM,ALFRSM)
      ALFC = -ALFM
      Z4 = ZET**4
      F=((1.D0+ZET)**THRD4+(1.D0-ZET)**THRD4-2.D0)/GAM
      EC = EU*(1.D0-F*Z4)+EP*F*Z4-ALFM*F*(1.D0-Z4)/FZZ
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! LSD potential from [c](A1)
! ECRS = dEc/drs [c](A2)
! ECZET=dEc/dzeta [c](A3)
! FZ = dF/dzeta [c](A4)
      ECRS = EURS*(1.D0-F*Z4)+EPRS*F*Z4-ALFRSM*F*(1.D0-Z4)/FZZ
      FZ = THRD4*((1.D0+ZET)**THRD-(1.D0-ZET)**THRD)/GAM
      ECZET = 4.D0*(ZET**3)*F*(EP-EU+ALFM/FZZ)+FZ*(Z4*EP-Z4*EU &
              -(1.D0-Z4)*ALFM/FZZ)
      COMM = EC -RS*ECRS/3.D0-ZET*ECZET
      VCUP = COMM + ECZET
      VCDN = COMM - ECZET
      if (t .lt. 1e-10) then
         h = 0d0
         dvcup = 0d0
         dvcdn = 0d0
         return
      endif
      if(lgga.eq.0)return
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! SG4c correlation energy
! G=phi(zeta), given after [a](3)
! DELT=bet/gamma
! B=A of [a](8)
      G=((1.d0+ZET)**thrd2+(1.d0-ZET)**thrd2)/2.d0
      G2 = G*G
      G3 = G2*G
      PON=-EC/(G3*gamma)
      B = DELT/(DEXP(PON)-1.D0)
      B2 = B*B
      T2 = T*T
      T3 = T2*T
      T4 = T2*T2
      RS2 = RS*RS
      RS3 = RS2*RS
      Q4 = 1.D0+B*T2
      Q5 = 1.D0+B*T2+B2*T4
      H = G3*(BET/DELT)*DLOG(1.D0+DELT*Q4*T2/Q5)
      fsg = g**(alphasg*t3)
      hsg = fsg*h
      if(lpot.eq.0)return
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! ENERGY DONE. NOW THE POTENTIAL, using appendix E of [b].
      G4 = G3*G
      T6 = T4*T2
      RSTHRD = RS/3.D0
      GZ=(((1.d0+zet)**2+eta)**sixthm- &
      ((1.d0-zet)**2+eta)**sixthm)/3.d0
      GZ2 = -(((1d0+zet)**2+eta)**(-2d0/3d0) + &
              ((1d0-zet)**2+eta)**(-2d0/3d0))/9d0
      FAC = DELT/B+1.D0
      BG = -3.D0*B2*EC*FAC/(BET*G4)
      BEC = B2*FAC/(BET*G3)
      Q8 = Q5*Q5+DELT*Q4*Q5*T2
      Q9 = 1.D0+2.D0*B*T2
      hB = -BET*G3*B*T6*(2.D0+B*T2)/Q8
      hRS = -RSTHRD*hB*BEC*ECRS
      FACT0 = 2.D0*DELT-6.D0*B
      FACT1 = Q5*Q9+Q4*Q9*Q9
      hBT = 2.D0*BET*G3*T4*((Q4*Q5*FACT0-DELT*FACT1)/Q8)/Q8
      hRST = RSTHRD*T2*hBT*BEC*ECRS
      hZ = 3.D0*GZ*h/G + hB*(BG*GZ+BEC*ECZET)
      hT = 2.d0*BET*G3*Q9/Q8
      hZT = 3.D0*GZ*hT/G+hBT*(BG*GZ+BEC*ECZET)
      FACT2 = Q4*Q5+B*T2*(Q4*Q9+Q5)
      FACT3 = 2.D0*B*Q5*Q9+DELT*FACT2
      hTT = 4.D0*BET*G3*T*(2.D0*B/Q8-(Q9*FACT3/Q8)/Q8)

      dfsgdzeta = alphasg*t3*fsg*gz/g
      dfsgdt = 3d0*alphasg*t2*log(g)*fsg

      d2fsgdzetadt = 3d0*alphasg*t2*(fsg*gz/g + log(g)*dfsgdzeta)
      d2fsgdzeta2 = alphasg*t3*((alphasg*t3-1d0)*g**(alphasg*t3-2d0)*gz**2 + &
         g**(alphasg*t3-1d0)*gz2)
      d2fsgdt2 = 3d0*alphasg*log(g)*(2d0*t*fsg + t2*dfsgdt)

      dbetadrs = 2d0*sigma*rs*t*exp(-rs2)
      dbetadt = sigma*(1d0-exp(-rs2))

      d2betadrsdt = 2d0*sigma*rs*exp(-rs2)

      dadzeta = bg*gz
      dadbeta = b/bet
      dadec = bec

      d2adzetadbeta = dadzeta/bet
      d2adbetadec = 1d0/(gamma**2*g3)*exp(pon)/(exp(pon) - 1d0)**2

      dq4dzeta = t2*dadzeta
      dq5dzeta = t2*dadzeta*q9
      dq4dt = 2d0*b*t
      dq5dt = 2d0*b*t*q9
      dq4dbeta = dadbeta*t2
      dq5dbeta = dadbeta*t2*q9
      dq4dec = dadec*t2
      dq5dec = dadec*t2*q9

      d2q4dzetadt = 2d0*t*bg*gz
      d2q5dzetadt = (2d0*t + 8d0*b*t3)*bg*gz
      d2q4dt2 = 2d0*b
      d2q5dt2 = 2d0*b + 12d0*b**2*t2
      d2q4dzetadbeta = t2*d2adzetadbeta
      d2q5dzetadbeta = d2adzetadbeta*t2*q9 + 2d0*t4*dadbeta*dadzeta
      d2q4dtdbeta = 2d0*t*dadbeta
      d2q5dtdbeta = dadbeta*(2d0*t + 8d0*b*t3)
      d2q4dtdec = 2d0*t*dadec
      d2q5dtdec = dadec*(2d0*t + 8d0*b*t3)
      d2q5dbeta2 = 2d0*t4*dadbeta**2
      d2q4dbetadec = t2*d2adbetadec
      d2q5dbetadec = d2adbetadec*t2*q9 + dadbeta*2d0*t4*dadec

      m2 = t2*q4/q5
      m1 = 1d0 + delt*m2

      dm2dzeta = t2*(dq4dzeta*q5 - q4*dq5dzeta)/q5**2
      dm1dzeta = delt*dm2dzeta
      dm2dt = 2d0*t*q4/q5 + t2*(dq4dt*q5 - q4*dq5dt)/q5**2
      dm1dt = delt*dm2dt
      dm2dbeta = t2*(dq4dbeta*q5 - q4*dq5dbeta)/q5**2
      dm1dbeta = m2/gamma + delt*dm2dbeta
      dm2dec = t2*(dq4dec*q5 - q4*dq5dec)/q5**2
      dm1dec = delt*dm2dec

      d2m2dzetadt = 2d0*t*(dq4dzeta*q5 - q4*dq5dzeta)/q5**2 + t2* &
         ((d2q4dzetadt*q5 + dq4dzeta*dq5dt - dq4dt*dq5dzeta - &
         q4*d2q5dzetadt)*q5**2 - &
         (dq4dzeta*q5 - q4*dq5dzeta)*2d0*q5*dq5dt)/q5**4
      d2m1dzetadt = delt*d2m2dzetadt
      d2m2dt2 = 2d0*q4/q5 + 4d0*t*(dq4dt*q5 - q4*dq5dt)/q5**2 + &
         t2*((d2q4dt2*q5 - q4*d2q5dt2)*q5**2 - &
         (dq4dt*q5 - q4*dq5dt)*2d0*q5*dq5dt)/q5**4
      d2m1dt2 = delt*d2m2dt2
      d2m2dzetadbeta = t2*((d2q4dzetadbeta*q5 + dq4dzeta*dq5dbeta - &
         dq4dbeta*dq5dzeta - q4*d2q5dzetadbeta)*q5**2 - &
         (dq4dzeta*q5 - q4*dq5dzeta)*2d0*q5*dq5dzeta)/q5**4
      d2m1dzetadbeta = dm2dzeta/gamma + delt*d2m2dzetadbeta
      d2m2dtdbeta = 2d0*t*(dq4dbeta*q5 - q4*dq5dbeta)/q5**2 + t2* &
         ((d2q4dtdbeta*q5 + dq4dbeta*dq5dt - dq4dt*dq5dbeta - &
         q4*d2q5dtdbeta)*q5**2 - &
         (dq4dbeta*q5 - q4*dq5dbeta)*2d0*q5*dq5dt)/q5**4
      d2m1dtdbeta = dm2dt/gamma + delt*d2m2dtdbeta
      d2m2dtdec = 2d0*t*(dq4dec*q5 - q4*dq5dec)/q5**2 + t2* &
         ((d2q4dtdec*q5 + dq4dt*dq5dec - dq4dec*dq5dt - &
         q4*d2q5dtdec)*q5**2 - &
         (dq4dt*q5 - q4*dq5dt)*2d0*q5*dq5dec)/q5**4
      d2m1dtdec = delt*d2m2dtdec
      d2m2dbeta2 = t2*(-q4*d2q5dbeta2*q5**2 - &
         (dq4dbeta*q5 - q4*dq5dbeta)*2d0*q5*dq5dbeta)/q5**4
      d2m1dbeta2 = 2d0*dm2dbeta/gamma + delt*d2m2dbeta2
      d2m2dbetadec = t2*((d2q4dbetadec*q5 + dq4dec*dq5dbeta - &
         dq4dbeta*dq5dec - q4*d2q5dbetadec)*q5**2 - &
         (dq4dec*q5 - q4*dq5dec)*2d0*q5*dq5dbeta)/q5**4
      d2m1dbetadec = (dm2dec + bet*d2m2dbetadec)/gamma

      dhdzeta = 3d0*g2*gz*gamma*log(m1) + g3*gamma*dm1dzeta/m1
      dhdt = g3*gamma*dm1dt/m1
      dhdbeta = g3*gamma*dm1dbeta/m1
      dhdec = g3*gamma*dm1dec/m1

      d2hdt2 = g3*gamma*(-dm1dt**2/m1**2 + d2m1dt2/m1)
      d2hdtdbeta = g3*gamma*(-dm1dt*dm1dbeta/m1**2 + d2m1dtdbeta/m1)
      d2hdtdec = g3*gamma*(-dm1dt*dm1dec/m1**2 + d2m1dtdec/m1)
      d2hdzetadt = 3d0*g2*gz*gamma*dm1dt/m1 + &
         g3*gamma*(-dm1dt*dm1dzeta/m1**2 + d2m1dzetadt/m1)
      d2hdzetadbeta = 3d0*g2*gz*gamma*dm1dbeta/m1 + &
         g3*gamma*(-dm1dbeta*dm1dzeta/m1**2 + d2m1dzetadbeta/m1)
      d2hdbeta2 = g3*gamma*(-dm1dbeta**2/m1**2 + d2m1dbeta2/m1)
      d2hdbetadec = g3*gamma*(-dm1dbeta*dm1dec/m1**2 + d2m1dbetadec/m1)

      dhsgdrs = fsg*(dhdbeta*dbetadrs + dhdec*ecrs)
      dhsgdzeta = dfsgdzeta*h + fsg*(dhdzeta + dhdec*eczet)
      dhsgdt = dfsgdt*h + fsg*(dhdt + dhdbeta*dbetadt)

      d2hsgdrsdt = dfsgdt*(dhdbeta*dbetadrs + dhdec*ecrs) + &
         f*((d2hdtdbeta + d2hdbeta2*dbetadt)*dbetadrs + &
         dhdbeta*d2betadrsdt + &
         (d2hdtdec + d2hdbetadec*dbetadt)*ecrs)
      d2hsgdzetadt = d2fsgdzetadt*h + &
         dfsgdzeta*(dhdt + dhdbeta*dbetadt) + &
         dfsgdt*(dhdzeta + dhdec*eczet) + &
         fsg*(d2hdzetadt + d2hdzetadbeta*dbetadt + &
         (d2hdtdec + d2hdbetadec*dbetadt)*eczet)
      d2hsgdt2 = d2fsgdt2*h + 2d0*dfsgdt*(dhdt + dhdbeta*dbetadt) + &
         fsg*(d2hdt2 + 2d0*d2hdtdbeta*dbetadt + d2hdbeta2*dbetadt**2)

      hsgrs = -rs/3d0*dhsgdrs
      hsgrst = rs*t/3d0*d2hsgdrsdt
      hsgt = dhsgdt/t
      hsgtt = -dhsgdt/t2 + d2hsgdt2/t
      hsgz = dhsgdzeta
      hsgzt = d2hsgdzetadt/t

      COMM = HSG+HSGRS+HSGRST+T2*HSGT/6.D0+7.D0*T2*T*HSGTT/6.D0
      PREF = HSGZ-GZ*T2*HSGT/G
      FACT5 = GZ*(2.D0*HSGT+T*HSGTT)/G
      COMM = COMM-PREF*ZET-UU*HSGTT-VV*HSGT-WW*(HSGZT-FACT5)
      DVCUP = COMM + PREF
      DVCDN = COMM - PREF
      RETURN
      END
