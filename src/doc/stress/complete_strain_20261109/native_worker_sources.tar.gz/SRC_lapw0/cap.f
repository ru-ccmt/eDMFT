      subroutine cap(up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap, &
                     exup,exdn,vxup,vxdn)

!J. Carmona-Espindola et al., J. Chem. Phys. 142, 054105 (2015).

      implicit none

      real*8, intent(in) :: up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap
      real*8, intent(out) :: exup,exdn,vxup,vxdn
      real*8 :: fk,pi32,rho2,s,thrd,u,v

      parameter(thrd=1.d0/3.d0)
      parameter(pi32=3d0*(4d0*atan(1d0))**2)

      rho2=2.d0*up
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrup/(2.d0*fk*rho2)
        u=4.d0*delgrup/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*uplap/(rho2*(2.d0*fk)**2)
        call exchcap(rho2,s,u,v,exup,vxup)
      else
        exup=0.d0
        vxup=0.d0
      endif
      
      rho2=2.d0*dn
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrdn/(2.d0*fk*rho2)
        u=4.d0*delgrdn/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*dnlap/(rho2*(2.d0*fk)**2)
        call exchcap(rho2,s,u,v,exdn,vxdn)
      else
        exdn=0.d0
        vxdn=0.d0
      endif

      return
      end

!-----------------------------------------------------------------------

      subroutine exchcap(rho,s,u,v,ex,vx)

      implicit none

      real*8, intent(in) :: rho,s,u,v
      real*8, intent(out) :: ex,vx
      real*8 :: alpha,ax,c,cmu,d2fxds2,dfxds,exunif,fs,fss,fx,log1s,pi,s2,thrd,thrd4

      parameter(thrd=1.d0/3.d0,thrd4=4.d0/3.d0)
      parameter(pi=4d0*atan(1d0))
      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(cmu=0.2195d0,alpha=-ax*cmu,c=alpha/(3d0*pi**2)**(1d0/3d0))
      
! construct lda exchange energy density
      exunif = ax*rho**thrd

! construct CAP enhancement factor
      s2 = s*s
      log1s = log(1d0+s)

      fx = 1d0 - alpha/ax*s*log1s/(1d0 + c*log1s)

      ex = exunif*fx
!  energy done. now the potential:
!  find first and second derivatives of fx w.r.t s.
!  fs=(1/s)*d fx/ ds
!  fss=d fs/ds
      if (s .gt. 1d-18) then
        dfxds = -alpha/ax*(s + (1d0+s)*log1s*(1d0+c*log1s))/ &
          ((1d0+s)*(1d0+c*log1s)**2)

        d2fxds2 = -alpha/ax*(2d0 + s - 2d0*c*s + c*(2d0+s)*log1s)/ &
          ((1d0+s)**2*(1d0+c*log1s)**3)

        fs = dfxds/s

        fss = -dfxds/s**2 + d2fxds2/s
      else
        fs = 0d0
        fss = 0d0
      endif

      vx = exunif*(thrd4*fx-(u-thrd4*s2*s)*fss-v*fs)

      return
      end
