      SUBROUTINE BRJ(RHO,GRHO,G2RHO,TAU,VXBRJ,ir)
!A. D. Becke and M. R. Roussel, Phys. Rev. A 39, 3761 (1989).
!A. D. Becke and E. R. Johnson, J. Chem. Phys. 124, 221101 (2006).

      USE xcparam 

      IMPLICIT REAL*8(A-H,O-Z)

      SAVE X,iint,isphere
      DATA X/0D0/,iint/0/,isphere/0/
      PI = 4D0*DATAN(1D0)

      IF (RHO .GT. 1D-18) THEN

         TOL = 1D-6
         F = 10D0*TOL
         NLOOP = 0
         X1 = 0D0
         X2 = 0D0
         NIF = 0
         DABSFOLD = -1D0

         tautf = (3d0/10d0)*(3d0*pi**2)**(2d0/3d0)*(2d0*rho)**(5d0/3d0)
         tauw = 0.125d0*grho*grho*2.d0/rho

         if(tau.lt.tauw) then
            tau_falsch=tau
            tau=tauw
         endif

! This bound is not valid
!         if(tau.gt.(tautf+tauw)) then
!            tau_falsch=tau
!            tau=tautf+tauw
!         endif

         if(tau.eq.tauw .and. rho.lt.10.d0.and.ir.lt.900.and.isphere.eq.0) then
            print*,'sphere:rho,tauw,grho,g2rho',rho,tau,grho,g2rho,'tauwrong=',tau_falsch
            isphere=1
         endif

!         if(tau.eq.(tautf+tauw) .and. rho.lt.10.d0.and.ir.lt.900.and.isphere.eq.0) then
!            print*,'sphere:rho,tauw+tautf,grho,g2rho',rho,tau,grho,g2rho,'tauwrong=',tau_falsch
!            isphere=1
!         endif

         if(tau.eq.tauw .and. ir.gt.900.and.iint.lt.10) then
            print*,'int:rho,tauw,grho,g2rho',rho,tau,grho,g2rho,'tauwrong=',tau_falsch
            iint=iint+1
         endif

!         if(tau.eq.(tautf+tauw) .and. ir.gt.900.and.iint.lt.10) then
!            print*,'int:rho,tauw+tautf,grho,g2rho',rho,tau,grho,g2rho,'tauwrong=',tau_falsch
!            iint=iint+1
!         endif

         D = TAU - 0.25D0*GRHO**2D0/RHO

         Q = (1D0/6D0)*(G2RHO - 2D0*XC1*D)

   10    DO WHILE (DABS(F) .GE. TOL)

            F = X*DEXP(-2D0*X/3D0)*Q - &
                (2D0/3D0)*PI**(2D0/3D0)*(X-2D0)*RHO**(5D0/3D0)

            DF = (1D0-(2D0/3D0)*X)*DEXP(-2D0*X/3D0)*Q - &
                 (2D0/3D0)*PI**(2D0/3D0)*RHO**(5D0/3D0)

            IF (DABS(DF) .GT. 1D-18) THEN

               X = X - F/DF

            ELSE

               X = X - F/SIGN(1D-18,DF)

            ENDIF

            IF ((NLOOP .GE. 500) .OR. (DABS(X) .GE. 1D100) .OR. (DABS(F) .GE. 1D100)) THEN

               IF (DABS(DABS(F)-DABSFOLD) .LT. 1D-8) THEN
                 NIF = NIF + 1
               ENDIF
               DABSFOLD = DABS(F)

               IF (NIF .EQ. 5) THEN
                 TOL = 5D0*TOL
                 NIF = 0
               ENDIF

               X = X1
               X1 = 10D0*X1
               F = 10D0*TOL
               NLOOP = 0
               GOTO 10

            ENDIF

            NLOOP = NLOOP + 1

         ENDDO

         if(dabs(df) .le. tol) then
            tol=tol/10.d0
            if(tol.gt.1.d-12) goto 10
         endif
    

         IF (X .LT. 0D0) THEN

            X = X2
            X2 = X2 + 1D0
            F = 10D0*TOL
            NLOOP = 0
            GOTO 10

         ENDIF

         B = (X**3D0*DEXP(-X)/(8D0*PI*RHO))**(1D0/3D0)

         IF (B .GT. 1D-18) THEN

            VXBRJ = -(1D0 - DEXP(-X) - 0.5D0*X*DEXP(-X))/B
!            vxbrj1=vxbrj
            IF (TAU .GE. 0D0) THEN

              VXBRJ = XCCONST*VXBRJ + (3D0*XCCONST-2D0)*DSQRT(5D0/12D0)/PI*DSQRT(TAU/RHO)

            ELSE

              VXBRJ = XCCONST*VXBRJ - (3D0*XCCONST-2D0)*DSQRT(5D0/12D0)/PI*DSQRT(ABS(TAU/RHO))

            ENDIF

         ELSE

            VXBRJ = 0D0

         ENDIF

      ELSE

         VXBRJ = 0D0

      ENDIF

!      if(ir.gt.900.and.iint.lt.100.and.abs(Vxbrj).gt.5.d0) print*,'brj:rho,tau,tauw,grho,g2rho',rho,tau,tauw,grho,g2rho,'VXBRJ',Vxbrj,d,q,b,x,DSQRT(TAU/RHO),vxbrj1,ir
      RETURN

      END
