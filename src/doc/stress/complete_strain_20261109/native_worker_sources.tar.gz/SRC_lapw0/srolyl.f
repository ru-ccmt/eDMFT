! multiply clmspu/d with spherical harmonic of one angular point -> fu/fd/ft
subroutine srolyl(clmspu,clmspd,yy,sqfpi, &
                        iatnr,llmm,fu,fd,ft,lm,lmmax,nospin)
      use parallel, only: abort_parallel
      use norm_kub, only: c_kub  
!
!     implicit real*8 (a-h,o-z)
      implicit none
!
      INCLUDE 'param.inc'
!
!     ARGUMENTS
      integer, intent(in)     ::  lm(2,ncom+3), iatnr, llmm, lmmax
      real*8,  intent(in)     ::  clmspu(ncom),clmspd(ncom),yy(ncom), sqfpi
      logical, intent(in)     ::  nospin
      real*8,  intent(out)    ::  fu, fd, ft

!     LOCAL VARIABLES
      real*8                  ::  c1, c2, c3
      integer                 ::  lm1, iyy, i
      
!
      if(nospin)then
        call srolylnsp(clmspu,yy,sqfpi, &
                        iatnr,llmm,fu,fd,ft,lm,lmmax)
        return
      endif

      fu=CLMSPU(1)*YY(1)*SQFPI                  
      fd=CLMSPD(1)*YY(1)*SQFPI                  
!-------------
      IF(IATNR.LT.0) THEN                                        
!$omp simd reduction(+:fu,fd)
      DO LM1=2,LLMM                                                
        fu=fu+CLMSPU(lm1)*YY(lm1)                  
        fd=fd+CLMSPD(lm1)*YY(lm1)                  
     END DO

     ELSE

      iyy=0
      i=1
      DO
         IF(i.gt.lmmax) EXIT
         IF(lm(1,i).EQ.0.AND.lm(2,i).EQ.0) THEN
            iyy=iyy+1
            i=i+1
         ELSEIF (lm(1,i).EQ.-3.AND.lm(2,i).EQ.2) THEN  
            iyy=iyy+1
            fu=fu+clmspu(i)*yy(iyy)
            fd=fd+clmspd(i)*yy(iyy)
            i=i+1
         ELSEIF (lm(1,i).EQ.4.OR.lm(1,i).EQ.6.OR. &
                 lm(1,i).EQ.-7.OR.lm(1,i).EQ.-9 ) THEN  
            c1=c_kub(abs(lm(1,i)),lm(2,i))
            c2=c_kub(abs(lm(1,i)),lm(2,i)+4)
            iyy=iyy+1
            fu=fu+(c1*CLMSPU(i)+c2*CLMSPU(i+1))*YY(iyy)
            fd=fd+(c1*CLMSPd(i)+c2*CLMSPd(i+1))*YY(iyy)
            i=i+2
         ELSEIF (lm(1,i).EQ.8.OR.lm(1,i).EQ.10) THEN 
            iyy=iyy+1
            c1=c_kub(abs(lm(1,i)),lm(2,i))
            c2=c_kub(abs(lm(1,i)),lm(2,i)+4)
            c3=c_kub(abs(lm(1,i)),lm(2,i)+8)
            fu=fu+(c1*CLMSPU(i)+c2*CLMSPU(i+1) +  &
                            c3*CLMSPU(i+2)  )*YY(iyy)
            fd=fd+(c1*CLMSPd(i)+c2*CLMSPd(i+1) +  &
                            c3*CLMSPd(i+2)  )*YY(iyy)
            i=i+3
         ELSE
            WRITE(6,*) 'UNCORRECT LM LIST FOR CUBIC STRUCTURE'
            WRITE(6,*) 'srolyl.f'
            call abort_parallel
            STOP
         ENDIF
      END DO
      IF(iyy.NE.llmm) THEN
         write(6,*) 'iyy=',iyy,' different from llmm=',llmm
         call abort_parallel
         STOP
      ENDIF
      ENDIF

      ft=fu+fd 
!
      return
      end subroutine srolyl

      subroutine srolylnsp(clmspu,yy,sqfpi, &
                        iatnr,llmm,fu,fd,ft,lm,lmmax)
        use parallel, only: abort_parallel
        use norm_kub, only: c_kub  
!
      implicit real*8 (a-h,o-z)
!
      INCLUDE 'param.inc'
!
      INTEGER     :: LM(2,NCOM+3)
      dimension clmspu(ncom),yy(ncom)
!
!      sqrt2=SQRT(2.d0)

      fu=CLMSPU(1)*YY(1)*SQFPI                  
!-------------
      IF(IATNR.LT.0) THEN                                        
!$omp simd reduction(+:fu)
      DO 8 LM1=2,LLMM                                                
        fu=fu+CLMSPU(lm1)*YY(lm1)                  
 8     continue

      ELSE

      iyy=0
      i=1
      DO
         IF(i.gt.lmmax) EXIT
         IF(lm(1,i).EQ.0.AND.lm(2,i).EQ.0) THEN
            iyy=iyy+1
            i=i+1
         ELSEIF (lm(1,i).EQ.-3.AND.lm(2,i).EQ.2) THEN  
            iyy=iyy+1
            fu=fu+clmspu(i)*yy(iyy)
            i=i+1
         ELSEIF (lm(1,i).EQ.4.OR.lm(1,i).EQ.6.OR. &
                 lm(1,i).EQ.-7.OR.lm(1,i).EQ.-9 ) THEN  
            c1=c_kub(abs(lm(1,i)),lm(2,i))
            c2=c_kub(abs(lm(1,i)),lm(2,i)+4)
            iyy=iyy+1
            fu=fu+(c1*CLMSPU(i)+c2*CLMSPU(i+1))*YY(iyy)
            i=i+2
         ELSEIF (lm(1,i).EQ.8.OR.lm(1,i).EQ.10) THEN 
            iyy=iyy+1
            c1=c_kub(abs(lm(1,i)),lm(2,i))
            c2=c_kub(abs(lm(1,i)),lm(2,i)+4)
            c3=c_kub(abs(lm(1,i)),lm(2,i)+8)
            fu=fu+(c1*CLMSPU(i)+c2*CLMSPU(i+1) +  &
                            c3*CLMSPU(i+2)  )*YY(iyy)
            i=i+3
         ELSE
            WRITE(6,*) 'UNCORRECT LM LIST FOR CUBIC STRUCTURE'
            WRITE(6,*) 'srolyl.f'
            call abort_parallel
            STOP
         ENDIF
      END DO
      IF(iyy.NE.llmm) THEN
         write(6,*) 'iyy=',iyy,' different from llmm=',llmm
         call abort_parallel
         STOP
      ENDIF
      ENDIF
      fd=fu
      ft=fu+fd 
!
      return
      end
