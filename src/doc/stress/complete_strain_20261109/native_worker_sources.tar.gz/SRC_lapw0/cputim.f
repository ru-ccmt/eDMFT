      SUBROUTINE CPUTIM(TIMEC)
      Real(8)    :: timec
!
      call CPU_TIME(timec)
!
      return
      END
!
      Subroutine WallTIM(TIMEW)
!     Note: this intrinsic is not that accurate
      Real(8) timew
      integer ( kind = 4 ) clock_max
      integer ( kind = 4 ) clock_rate
      integer ( kind = 4 ) clock_reading
!
      call system_clock ( clock_reading, clock_rate, clock_max )
!
      timew = dble(clock_reading)/dble(clock_rate)
      return
      end      
