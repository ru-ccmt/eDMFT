      subroutine dfundr(jatom,n,lmmax,func,dfdr,d2fdr2,spin,LM)
!
!     First and second derivative of function func(r)
!     Uses a simpler "straight" quadrature with a different boundary condition at r=0
!     The other end-point needs work              
!
      use densit, only: lmmaxx
      use struct, only: nat
      use work, only: r
      use parallel, only: nstart, nstop, myid
      
      implicit none
!
      INCLUDE 'param.inc'

      integer,   parameter :: npad = 20
      
!     ARGUMENTS
      integer, intent(in) ::  jatom, n, lmmax, LM(2,NCOM+3,NAT)
      real*8,  intent(in) ::  func(nrad,lmmaxx,nstart(myid):nstop(myid),2)
      real*8,  intent(out)::  dfdr(ncom,nrad,2),d2fdr2(ncom,nrad,2)
      
!
      logical :: spin

!     LOCAL VARIABLES
      logical :: even
      real*8  :: c(n),g(n), g2(n),r2(n), g0, dsi
      integer :: jspin, j, ispin, lval, lm1
      
      if(spin)then
        jspin=2
      else
        jspin=1
      endif
!
!     Setup array for r2
      do j=1,n
        r2(j)=1.D0/(r(j)*r(j))
      enddo
!
      do ispin=1,jspin
       do lm1=1,lmmax
        LVal = LM(1,LM1,jatom)
        even=.false.
        if(2*(LVal/2).eq.LVal)even=.true.
        c(1:n) = func(1:n,lm1,jatom,ispin)*r2(1:n)
        call dergl(n,r,c,g,even,g0)
        CALL INTERP(R(4),g(4),3, &
             R(3),g(3),DSI,.FALSE.)
        CALL INTERP(R(4),g(4),3, &
             R(2),g(2),DSI,.FALSE.)
        CALL INTERP(R(4),g(4),3, &
             R(1),g(1),DSI,.FALSE.)
        call dergl(n,r,g,g2,.not.even,g0)
        CALL INTERP(R(6),g2(6),2, &
             R(5),g2(5),DSI,.FALSE.)
        CALL INTERP(R(6),g2(6),2, &
             R(4),g2(4),DSI,.FALSE.)
        CALL INTERP(R(6),g2(6),2, &
             R(3),g2(3),DSI,.FALSE.)
        CALL INTERP(R(6),g2(6),2, &
             R(2),g2(2),DSI,.FALSE.)
        CALL INTERP(R(6),g2(6),2, &
             R(1),g2(1),DSI,.FALSE.)
!
!       Done, copy
        dfdr(lm1,1:n,ispin)=g(1:n)
        d2fdr2(lm1,1:n,ispin)=g2(1:n)
       enddo
      enddo
      return
      end


      SUBROUTINE INTERP(R,P,N,RS,PS,DPS,DERIV)                          
!                                                                       
!     ******************************************************************
!                                                                       
!     INTERPOLATE VIA LAGRANGE                                          
!                                                                       
!     ******************************************************************
!                                                                       
!     IMPLICIT REAL*8 (A-H,O-Z)
      IMPLICIT NONE
!     ARGUMENTS
      INTEGER N
      REAL*8 R(N),P(N)                                               
      REAL*8 RS,PS,DPS
      LOGICAL DERIV
!     LOCAL VARIABLES
      REAL*8  TERM, DENOM, DTERM, DTERM1
      INTEGER I, J, K
      LOGICAL NODRIV                                              
      NODRIV=.NOT.DERIV                                                 
      PS=0.E0                                                           
      DPS=0.E0                                                          
      DO 1 J=1,N                                                        
      TERM=1.E0                                                         
      DENOM=1.E0                                                        
      DTERM=0.E0                                                        
      DO 2 I=1,N                                                        
      IF(I.EQ.J) GO TO 2                                                
      DENOM=DENOM*(R(J)-R(I))                                           
      TERM=TERM*(RS-R(I))                                               
      IF(NODRIV) GO TO 2                                                
      DTERM1=1.E0                                                       
      DO 3 K=1,N                                                        
      IF(K.EQ.J.OR.K.EQ.I) GO TO 3                                      
      DTERM1=DTERM1*(RS-R(K))                                           
    3 CONTINUE                                                          
      DTERM=DTERM+DTERM1                                                
    2 CONTINUE                                                          
      IF(NODRIV) GO TO 1                                                
      DPS=DPS+DTERM*P(J)/DENOM                                          
    1 PS=PS+TERM *P(J)/DENOM                                            
      RETURN                                                            
      END                                                               

