      subroutine pbec(up,agrup,uplap,dn,agrdn,dnlap,agr,delgr, &
         ecpbe,vcuppbe,vcdnpbe,CutUp,CutDn)
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! EASYc is a driver for the PBEc subroutines, using simple inputs
! inputs: up=up density
!	: agrup=|grad up|
!	: uplap=grad^2 up=Laplacian of up
!	: dn,agrdn,dnlap=corresponding down quantities
!	: agr=|grad rho|
!	: delgr=(grad rho).(grad |grad rho|) 
! outputs: ecpbe,vcup(dn)pbe=PBEc quantities
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! needed constants:
! pi32=3*pi**2
! alpha=(9pi/4)**thrd
      implicit real*8(a-h,o-z)
      parameter(thrd=1.d0/3.d0,thrd2=2.d0*thrd)
      parameter(pi32=29.608813203268075856503472999628d0)
      parameter(pi=3.1415926535897932384626433832795d0)
      parameter(alpha=1.91915829267751300662482032624669d0)
      logical CutUp,CutDn
! Now do correlation
! zet=(up-dn)/rho
! g=phi(zeta)
! rs=(3/(4pi*rho))^(1/3)=local Seitz radius=alpha/fk
! sk=Ks=Thomas-Fermi screening wavevector=sqrt(4fk/pi)
! twoksg=2*Ks*phi
! t=correlation dimensionless gradient=|grad rho|/(2*Ks*phi*rho)
! uu=delgrad/(rho^2*twoksg^3)
! rholap=Laplacian
! vv=Laplacian/(rho*twoksg^2)
! ww=(|grad up|^2-|grad dn|^2-zet*|grad rho|^2)/(rho*twoksg)^2
! ec=lsd correlation energy
! vcup=lsd up correlation potential
! vcdn=lsd down correlation potential
! h=gradient correction to correlation energy
! dvcup=gradient correction to up correlation potential
! dvcdn=gradient correction to down correlation potential
      rho=up+dn
      if(rho.lt.1.d-18)return
      zet=(up-dn)/rho
!      if(Cut)then
!       RS=(0.75d0/(pi*rho))**thrd
!       call CORLSD(RS,ZET,ECPBE,VUPBE,VDPBE,ECRS,ECZET,ALFC)
!       return
!     endif
      g=((1.d0+zet)**thrd2+(1.d0-zet)**thrd2)/2.d0
      fk=(pi32*rho)**thrd
      rs=alpha/fk
      sk=sqrt(4.d0*fk/pi)
      twoksg=2.d0*sk*g
      t=agr/(twoksg*rho)
      uu=delgr/(rho*rho*twoksg**3)
      rholap=uplap+dnlap
      vv=rholap/(rho*twoksg**2)
      ww=(agrup**2-agrdn**2-zet*agr**2)/(rho*rho*twoksg**2)
      lgga = 1
      lpot = 1
      call CORPBE(RS,ZET,T,UU,VV,WW,lgga,lpot,ec,vcup,vcdn, &
                        H,DVCUP,DVCDN)
      ecpbe=ec+h
      vcuppbe=vcup+dvcup
      vcdnpbe=vcdn+dvcdn
      if(CutUp.and.CutDn)then
        ecpbe=ec
        vcuppbe=vcup
        vcdnpbe=vcdn
      else if(CutUp)then
        ecpbe=ec+h*0.5D0
        vcuppbe=vcup
      else if(CutDn)then
        ecpbe=ec+h*0.5D0
        vcdnpbe=vcdn
      
      endif
      if((up.lt.1.d-6.or.dn.lt.1.d-6).and.(abs(dvcup).gt.1.1d0*abs(vcup).or.abs(dvcdn).gt.1.1d0*abs(vcdn)   )) then
!          !   write(*,*) 'PBEC: up,dn,vcup,dvcup,vcdn,dvcdn',up,dn,vcup,dvcup,vcdn,dvcdn
             vcuppbe=0.d0 !vcup
             vcdnpbe=0.d0  !vcdn
      endif        
      return
      end
!----------------------------------------------------------------------
!######################################################################
!----------------------------------------------------------------------
      SUBROUTINE CORPBE(RS,ZET,T,UU,VV,WW,lgga,lpot,ec,vcup,vcdn, &
                        H,DVCUP,DVCDN)
!----------------------------------------------------------------------
!  INPUT: RS=SEITZ RADIUS=(3/4pi rho)^(1/3)
!       : ZET=RELATIVE SPIN POLARIZATION = (rhoup-rhodn)/rho
!       : t=ABS(GRAD rho)/(rho*2.*KS*G)  -- only needed for PBEc
!       : UU=(GRAD rho)*GRAD(ABS(GRAD rho))/(rho**2 * (2*KS*G)**3)
!       : VV=(LAPLACIAN rho)/(rho * (2*KS*G)**2)
!       : WW=(GRAD rho)*(GRAD ZET)/(rho * (2*KS*G)**2
!       :  UU,VV,WW, only needed for PBEc potential
!       : lgga=flag to do gga (0=>LSD only)
!       : lpot=flag to do potential (0=>energy only)
!  output: ec=lsd correlation energy from [a]
!        : vcup=lsd up correlation potential
!        : vcdn=lsd dn correlation potential
!        : h=NONLOCAL PART OF CORRELATION ENERGY PER ELECTRON
!        : dvcup=nonlocal correction to vcup
!        : dvcdn=nonlocal correction to vcdn
!----------------------------------------------------------------------
!----------------------------------------------------------------------
!----------------------------------------------------------------------
      USE xcparam, only : xc3
      IMPLICIT REAL*8 (A-H,O-Z)
! thrd*=various multiples of 1/3
! numbers for use in LSD energy spin-interpolation formula, [c](9).
!      GAM= 2^(4/3)-2
!      FZZ=f''(0)= 8/(9*GAM)
! numbers for construction of PBEc
!      gamma=(1-log(2))/pi^2
!      eta=small number to stop d phi/ dzeta from blowing up at 
!          |zeta|=1.
      parameter(thrd=1.d0/3.d0,thrdm=-thrd,thrd2=2.d0*thrd)
      parameter(sixthm=thrdm/2.d0)
      parameter(thrd4=4.d0*thrd)
      parameter(GAM=0.5198420997897463295344212145565d0)
      parameter(fzz=8.d0/(9.d0*GAM))
      parameter(gamma=0.03109069086965489503494086371273d0)
      parameter(eta=1.d-12)
      if (xc3 .lt. 0.0d0) then
        bet=0.06672455060314922d0
      else
        bet=xc3
      endif
      if (dabs(bet) .le. 1d-12) then
        lgga = 0
        H = 0d0
        DVCUP = 0d0
        DVCDN = 0d0
      endif
      delt=bet/gamma
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! find LSD energy contributions, using [c](10) and Table I[c].
! EU=unpolarized LSD correlation energy
! EURS=dEU/drs
! EP=fully polarized LSD correlation energy
! EPRS=dEP/drs
! ALFM=-spin stiffness, [c](3).
! ALFRSM=-dalpha/drs
! F=spin-scaling factor from [c](9).
! construct ec, using [c](8)
      CALL gcor(0.0310907D0,0.21370D0,7.5957D0,3.5876D0,1.6382D0, &
          0.49294D0,1.0D0,RS,EU,EURS)
      CALL gcor(0.01554535D0,0.20548D0,14.1189D0,6.1977D0,3.3662D0, &
          0.62517D0,1.0D0,RS,EP,EPRS)
      CALL gcor(0.0168869D0,0.11125D0,10.357D0,3.6231D0,0.88026D0, &
          0.49671D0,1.0D0,RS,ALFM,ALFRSM)
      ALFC = -ALFM
      Z4 = ZET**4
      F=((1.D0+ZET)**THRD4+(1.D0-ZET)**THRD4-2.D0)/GAM
      EC = EU*(1.D0-F*Z4)+EP*F*Z4-ALFM*F*(1.D0-Z4)/FZZ
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! LSD potential from [c](A1)
! ECRS = dEc/drs [c](A2)
! ECZET=dEc/dzeta [c](A3)
! FZ = dF/dzeta [c](A4)
      ECRS = EURS*(1.D0-F*Z4)+EPRS*F*Z4-ALFRSM*F*(1.D0-Z4)/FZZ
      FZ = THRD4*((1.D0+ZET)**THRD-(1.D0-ZET)**THRD)/GAM
      ECZET = 4.D0*(ZET**3)*F*(EP-EU+ALFM/FZZ)+FZ*(Z4*EP-Z4*EU &
              -(1.D0-Z4)*ALFM/FZZ)
      COMM = EC -RS*ECRS/3.D0-ZET*ECZET
      VCUP = COMM + ECZET
      VCDN = COMM - ECZET
      if(lgga.eq.0)return
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! PBEc correlation energy
! G=phi(zeta), given after [a](3)
! DELT=bet/gamma
! B=A of [a](8)
      G=((1.d0+ZET)**thrd2+(1.d0-ZET)**thrd2)/2.d0
      G3 = G**3
      PON=-EC/(G3*gamma)
      B = DELT/(DEXP(PON)-1.D0)
      B2 = B*B
      T2 = T*T
      T4 = T2*T2
      RS2 = RS*RS
      RS3 = RS2*RS
      Q4 = 1.D0+B*T2
      Q5 = 1.D0+B*T2+B2*T4
      H = G3*(BET/DELT)*DLOG(1.D0+DELT*Q4*T2/Q5)
      if(lpot.eq.0)return
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! ENERGY DONE. NOW THE POTENTIAL, using appendix E of [b].
      G4 = G3*G
      T6 = T4*T2
      RSTHRD = RS/3.D0
      GZ=(((1.d0+zet)**2+eta)**sixthm- &
      ((1.d0-zet)**2+eta)**sixthm)/3.d0
      FAC = DELT/B+1.D0
      BG = -3.D0*B2*EC*FAC/(BET*G4)
      BEC = B2*FAC/(BET*G3)
      Q8 = Q5*Q5+DELT*Q4*Q5*T2
      Q9 = 1.D0+2.D0*B*T2
      hB = -BET*G3*B*T6*(2.D0+B*T2)/Q8
      hRS = -RSTHRD*hB*BEC*ECRS
      FACT0 = 2.D0*DELT-6.D0*B
      FACT1 = Q5*Q9+Q4*Q9*Q9
      hBT = 2.D0*BET*G3*T4*((Q4*Q5*FACT0-DELT*FACT1)/Q8)/Q8
      hRST = RSTHRD*T2*hBT*BEC*ECRS
      hZ = 3.D0*GZ*h/G + hB*(BG*GZ+BEC*ECZET)
      hT = 2.d0*BET*G3*Q9/Q8
      hZT = 3.D0*GZ*hT/G+hBT*(BG*GZ+BEC*ECZET)
      FACT2 = Q4*Q5+B*T2*(Q4*Q9+Q5)
      FACT3 = 2.D0*B*Q5*Q9+DELT*FACT2
      hTT = 4.D0*BET*G3*T*(2.D0*B/Q8-(Q9*FACT3/Q8)/Q8)
      COMM = H+HRS+HRST+T2*HT/6.D0+7.D0*T2*T*HTT/6.D0
      PREF = HZ-GZ*T2*HT/G
      FACT5 = GZ*(2.D0*HT+T*HTT)/G
      COMM = COMM-PREF*ZET-UU*HTT-VV*HT-WW*(HZT-FACT5)
      DVCUP = COMM + PREF
      DVCDN = COMM - PREF
      RETURN
      END
