      subroutine vx_screened(rho,gx,gy,gz,gn,s,g2,ggx,ggy,ggz,f,h,dh,vx,ex)

      use xcparam, only : screening, slamb
      implicit none

      real*8, intent(in) :: rho, gx, gy, gz, gn, s, g2, ggx, ggy, ggz, &
        f, h, dh

      real*8, intent(out) :: vx, ex

      real*8 :: pi, cx, b, b2, b3, b4, b5, rho3, rho13, rho43, rho53, &
        rho83, rho103, f12, f32, a, a2, a3, ggg, s2, s3, s4, &
        j, dj, d2j, v1, v2, v3

      parameter(pi=3.141592653589793238462643383279502884197d0)

      if (f .lt. 1d-6) stop 'Enhancement factor Fx .lt. 1d-6'

      cx = 0.75d0*(3d0/pi)**(1d0/3d0)

      b = 2d0*(3d0*pi**2)**(1d0/3d0)
      b2 = b**2
      b3 = b**3
      b4 = b**4
      b5 = b**5

      rho3 = rho**3
      rho13 = rho**(1d0/3d0)
      rho43 = rho**(4d0/3d0)
      rho53 = rho**(5d0/3d0)
      rho83 = rho**(8d0/3d0)
      rho103 = rho**(10d0/3d0)

      f12 = f**0.5d0
      f32 = f**1.5d0

      a = slamb*f12/(b*rho13)
      a2 = a**2
      a3 = a**3

      ggg = gx*ggx + gy*ggy + gz*ggz

      s2 = s**2
      s3 = s**3
      s4 = s**4

      if ((screening .eqv. .true.) .and. (slamb .gt. 1d-10)) then

        j = 1d0 - 2d0/3d0*a2 - 8d0/3d0*a*datan(1d0/a) + &
          2d0/3d0*a2*(a2 + 3d0)*dlog(1d0 + 1d0/a2)

        dj = -8d0/3d0*a - 8d0/3d0*datan(1d0/a) + &
          (8d0/3d0*a3 + 4d0*a)*dlog(1d0 + 1d0/a2)

        d2j = -8d0 + (8d0*a2 + 4d0)*dlog(1d0 + 1d0/a2)

        v1 = 4d0/3d0*rho13*f - &
          1d0/b2*g2/rho43*h - &
          1d0/b3*ggg/rho83*dh + &
          4d0/3d0*rho13*s3*dh

        v2 = -1d0/3d0*slamb/b*f32 + &
          2d0/3d0*slamb/b*s3*f12*dh + &
          0.5d0*slamb/b*s2*f12*h - &
          0.5d0*slamb/b3*g2/rho53*f12*h - &
          0.5d0*slamb/b4*ggg/rho3*f12*dh + &
          slamb/b*s4/f12*h**2 - &
          0.75d0*slamb/b4*ggg/rho3*s/f12*h**2

        v3 = 1d0/6d0*slamb**2/b2*s2/rho13*f*h - &
          0.25d0*slamb**2/b5*ggg/rho103*s*h**2 + &
          1d0/3d0*slamb**2/b2*s4/rho13*h**2

      else

        j = 1d0
        dj = 0d0
        d2j = 0d0

        v1 = 4d0/3d0*rho13*f - &
          1d0/b2*g2/rho43*h - &
          1d0/b3*ggg/rho83*dh + &
          4d0/3d0*rho13*s3*dh

        v2 = 0d0
        v3 = 0d0

      endif

      vx = -cx*(v1*j + v2*dj + v3*d2j)

      ex = -cx*rho43*f*j

      return

      end
