      subroutine pbex(up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap, &
         exuppbe,exdnpbe,vxuppbe,vxdnpbe,ChargeCut,CutUp,CutDn)
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! EASYx is a driver for the PBEx subroutines, using simple inputs
! inputs: up=up density
!	: agrup=|grad up|
!	: delgrup=(grad up).(grad |grad up|) 
!	: uplap=grad^2 up=Laplacian of up
!	: dn,agrdn,delgrdn,dnlap=corresponding down quantities
! outputs: exup(dn)pbe,vxup(dn)pbe=PBEx quantities
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! needed constants:
! pi32=3*pi**2
      implicit real*8(a-h,o-z)
      parameter(thrd=1.d0/3.d0)
      parameter(pi32=29.608813203268075856503472999628d0)
      logical CutUp,CutDn
      CutUp=.false. ; CutDn=.false.
      pi=acos(-1.d0)
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! PBEx exchange
! use  Ex[up,dn]=0.5*(Ex[2*up]+Ex[2*dn]) (i.e., exact spin-scaling)
! do up exchange
! fk=local Fermi wavevector for 2*up=(3 pi^2 (2up))^(1/3) 
! s=dimensionless density gradient=|grad rho|/ (2*fk*rho)_(rho=2*up)
! u=delgrad/(rho^2*(2*fk)**3)_(rho=2*up)
! v=Laplacian/(rho*(2*fk)**2)_(rho=2*up)
      rho2=2.d0*up
      ft=up+dn
      if(up.gt.ChargeCut)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrup/(2.d0*fk*rho2)
        u=4.d0*delgrup/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*uplap/(rho2*(2.d0*fk)**2)
        call exchpbe(rho2,s,u,v,exuppbe,vxuppbe)
        vxuplda=xcpot(ft,up,pi)
        if(abs(vxuppbe-vxuplda)/abs(vxuplda).gt.0.4d0 .and.  rho2.lt.1.d-6) then
          write(6,*)'vxuppbe.gt.0.4',abs(vxuppbe-vxuplda)/abs(vxuplda),vxuppbe,xcpot(ft,up,pi),rho2,s,u,v
          exuppbe=xcener(ft,up,pi)
          vxuppbe=xcpot(ft,up,pi)
          CutUp = .true.
        endif
      else
        exuppbe=xcener(ft,up,pi)
        vxuppbe=xcpot(ft,up,pi)
        CutUp = .true.
      endif
! repeat for down
      rho2=2.d0*dn
      if(dn.gt.ChargeCut)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrdn/(2.d0*fk*rho2)
        u=4.d0*delgrdn/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*dnlap/(rho2*(2.d0*fk)**2)
        call exchpbe(rho2,s,u,v,exdnpbe,vxdnpbe)
        vxdnlda=xcpot(ft,dn,pi)
        if(abs(vxdnpbe-vxdnlda)/abs(vxdnlda).gt.0.4d0 .and.  rho2.lt.1.d-6) then
!         write(6,*)'vxuppbe.gt.0.4',abs(vxuppbe-vxuplda)/abs(vxuplda),vxuppbe,xcpot(ft,up,pi),rho2,s,u,v
          exdnpbe=xcener(ft,dn,pi)
          vxdnpbe=xcpot(ft,dn,pi)
          CutDn = .true.
        endif
      else
	exdnpbe=xcener(ft,dn,pi)
	vxdnpbe=xcpot(ft,dn,pi)
        CutDn = .true.
      endif

      return
      end
!----------------------------------------------------------------------
!######################################################################
!----------------------------------------------------------------------
      SUBROUTINE EXCHPBE(rho,S,U,V,EX,VX)
!----------------------------------------------------------------------
!  PBEx EXCHANGE FOR A SPIN-UNPOLARIZED ELECTRONIC SYSTEM
!----------------------------------------------------------------------
!----------------------------------------------------------------------
!  INPUT rho : DENSITY
!  INPUT S:  ABS(GRAD rho)/(2*KF*rho), where kf=(3 pi^2 rho)^(1/3)
!  INPUT U:  (GRAD rho)*GRAD(ABS(GRAD rho))/(rho**2 * (2*KF)**3)
!  INPUT V: (LAPLACIAN rho)/(rho*(2*KF)**2)
!   (for U,V, see PW86(24))
!  OUTPUT:  EXCHANGE ENERGY PER ELECTRON (EX) AND POTENTIAL (VX)
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! Formulas:
!   	e_x[unif]=ax*rho^(4/3)  [LDA]
! ax = -0.75*(3/pi)^(1/3)
!	e_x[PBEx]=e_x[unif]*FxPBE(s)
!	FxPBE(s)=1+uk-uk/(1+ul*s*s)                 [a](13)
! uk, ul defined after [a](13) 
!----------------------------------------------------------------------
!----------------------------------------------------------------------
      USE xcparam, only : xc1, xc2, icount
      IMPLICIT REAL*8 (A-H,O-Z)
      parameter(thrd=1.d0/3.d0,thrd4=4.d0/3.d0)
      parameter(ax=-0.738558766382022405884230032680836d0)
!!      data icount /0/
!!      save icount
      if ((xc1 .lt. 0.0d0) .or. (xc2 .lt. 0.0d0)) then
        um=0.2195149727645171d0
        uk=0.8040d0
      else
        um=xc1
        uk=xc2
      endif
      lgga = 1
      if (dabs(uk) .le. 1d-12) lgga = 0
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! construct LDA exchange energy density
      exunif = AX*rho**THRD
      if(lgga.eq.0)then
	ex=exunif
        vx=ex*thrd4
	return
      endif
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! construct PBEx enhancement factor
      ul=um/uk
      S2 = S*S
      P0=1.d0+ul*S2
      FxPBE = 1d0+uk-uk/P0
      EX = exunif*FxPBE
!----------------------------------------------------------------------
!----------------------------------------------------------------------
!  ENERGY DONE. NOW THE POTENTIAL:
!  find first and second derivatives of Fx w.r.t s.
!  Fs=(1/s)*d FxPBE/ ds
!  Fss=d Fs/ds
      Fs=2.d0*uk*ul/(P0*P0)
      Fss=-4.d0*ul*S*Fs/P0
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! calculate potential from [b](24) 
      VX = exunif*(THRD4*FxPBE-(U-THRD4*S2*s)*FSS-V*FS)
      if(vx.gt.1.d0) then
         if(icount.lt.10) then
!$omp atomic update
                 icount=icount+1
                 if(icount.lt.2) print*, ':INFO: VX.gt.+1.0',vx,' rho',rho
                 write(6,*)'vxpos:rho, vx, exunif, THRD4*FxPBE, (U-THRD4*S2*s)*FSS, V*FS, um, uk, s, u, v'
                 write(6,*)rho,vx,exunif,THRD4*FxPBE,(U-THRD4*S2*s)*FSS,V*FS,um,uk,s,u,v
         endif        
!                      vx=exunif*thrd4a ! LDA
      endif
      RETURN
      END
