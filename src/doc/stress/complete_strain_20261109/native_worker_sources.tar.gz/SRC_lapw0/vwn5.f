      subroutine vwn5(rhoup,rhodn,ec,vcup,vcdn)

!S. H. Vosko, L. Wilk, and M. Nusair, Can. J. Phys. 58, 1200 (1980).

      implicit none

      real*8, intent(in) :: rhoup, rhodn

      real*8, intent(out) :: ec, vcup, vcdn

      real*8 :: acp, cap(4), cef(4), cep(4), dacp, decfp, decp, detol, &
        dgvwn, ecfp, ecp, fspin, fspol, fspol1, fspol2, fthrd2, gvwn, &
        pi, pi43, rho, rs, rx, third, vcfp, vcp, zeta, zetba1

      cap(1) = -0.0337737d0
      cap(2) = 1.13107d0
      cap(3) = 13.0045d0
      cap(4) = -0.0047584d0
      cep(1) = 0.0621814d0
      cep(2) = 3.72744d0
      cep(3) = 12.9352d0
      cep(4) = -0.1049800d0
      cef(1) = 0.0310907d0
      cef(2) = 7.06042d0
      cef(3) = 18.0578d0
      cef(4) = -0.3250000d0
      detol = 1d-20
      third = 1d0/3d0
      fthrd2 = 5.1297633d0
      pi = 3.141592653589793238462643383279502884197d0
      pi43 = (4d0/3d0)*pi
      zetba1 = 0.999999d0

      rho = rhoup + rhodn

      if (rho .gt. detol) then
        rs = 1d0/(pi43*rho)**third
      else
        rs = 1d0/(pi43*detol)**third
      endif

      rx = dsqrt(rs)

      zeta = (rhoup - rhodn)/rho
      if (zeta .gt.  zetba1) zeta =  zetba1
      if (zeta .lt. -zetba1) zeta = -zetba1

      ecp = gvwn(rx,cep(1),cep(2),cep(3),cep(4))/2d0

      decp = dgvwn(rx,cep(1),cep(2),cep(3),cep(4))/2d0

      vcp = ecp - decp*rx/6d0

      ec = ecp
      vcup = vcp
      vcdn = vcp

      ecfp = (gvwn(rx,cef(1),cef(2),cef(3),cef(4))/2d0) - ecp

      decfp = (dgvwn(rx,cef(1),cef(2),cef(3),cef(4))/2d0) - decp

      acp = (gvwn(rx,cap(1),cap(2),cap(3),cap(4))/2d0)*3d0/fthrd2

      dacp = (dgvwn(rx,cap(1),cap(2),cap(3),cap(4))/2d0)*3d0/fthrd2

      vcfp = fspol2(zeta)*(ecfp*(zeta**4) + acp*(1d0-(zeta**4)) - &
        (rx/6d0)*(decfp*(zeta**4) + dacp*(1d0-(zeta**4))))

      ec = ec + fspol2(zeta)*(ecfp*(zeta**4) + acp*(1d0-zeta**4))

      vcup = vcp + vcfp + (1d0-zeta)*(fspol1(zeta)*(ecfp*(zeta**4) + &
        acp*(1d0-(zeta**4))) + 4d0*fspol2(zeta)*(ecfp*(zeta**3) - &
        acp*(zeta**3)))

      vcdn = vcp + vcfp - (1d0+zeta)*(fspol1(zeta)*(ecfp*(zeta**4) + &
        acp*(1d0-(zeta**4))) + 4d0*fspol2(zeta)*(ecfp*(zeta**3) - &
        acp*(zeta**3)))

      return

      end

      function fspin(z)
        implicit none
        real*8 :: fspin, z
        fspin = (1d0+z)**(4d0/3d0)+(1d0-z)**(4d0/3d0)
        return
      end function

      function fspol(z)
        implicit none
        real*8 :: fspol, z
        fspol = (1d0+z)**(1d0/3d0)
        return
      end function

      function fspol1(z)
        implicit none
        real*8 :: fspol1, z, fspol, fthrd2
        fthrd2 = 5.1297633d0
        fspol1 = (fspol(z)-fspol(-z))*fthrd2/2d0
        return
      end function

      function fspol2(z)
        implicit none
        real*8 :: fspol2, z, fspin, fdenom
        fdenom = 0.51984204d0
        fspol2 = (fspin(z)-2d0)/fdenom
        return
      end function

      function gvwn(x,a,b,c,x0)
        implicit none
        real*8 :: gvwn, x, a, b, c, x0
        gvwn = a*dlog(x*x/(x-x0)**2) - a/(x0*x0+b*x0+c)* &
          ((x0*x0+c)*dlog((x*x+b*x+c)/(x-x0)**2) + &
          (x0*x0-c)*datan(dsqrt(4d0*c-b*b)/(2d0*x+b))*2d0*b/dsqrt(4d0*c-b*b))
        return
      end function

      function dgvwn(x,a,b,c,x0)
        implicit none
        real*8 :: dgvwn, x, a, b, c, x0
        dgvwn = 2d0*a*(1d0/x-(1d0+b/(x-x0))*x/(x*x+b*x+c))
        return
      end function
