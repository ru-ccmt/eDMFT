      subroutine mbeefx(rhoup,gmagup,tauup,rhodn,gmagdn,taudn,exup,exdn)

!J. Wellendorff et al., J. Chem. Phys. 140, 144107 (2014)
!It seems that the sign "-" in "talpha = -" is missing in Eq. (3) of the article.

      implicit none

      real*8, intent(in) :: rhoup, gmagup, tauup, rhodn, gmagdn, taudn

      real*8, intent(out) :: exup, exdn

      if (rhoup .gt. 1d-18) then
         call exmbeefx(rhoup,gmagup,tauup,exup)
      else
         exup = 0d0
      endif

      if (rhodn .gt. 1d-18) then
         call exmbeefx(rhodn,gmagdn,taudn,exdn)
      else
         exdn = 0d0
      endif

      return

      end

!-----------------------------------------------------------------------

      subroutine exmbeefx(rho,gmag,tau,ex)

      implicit none

      integer :: i, m, n

      real*8, intent(in) :: rho, gmag, tau

      real*8, intent(out) :: ex

      real*8 :: alpha, amn(64), ax, bm(0:7), bn(0:7), exlda, fx, pi, &
         q, s, talpha, tautf, tauw, ts

      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(pi=3.1415926535897932384626433832795d0)
      parameter(q=6.5124d0)

      amn = (/ &
         1.18029330e+00,   8.53027860e-03,  -1.02312143e-01, &
         6.85757490e-02,  -6.61294786e-03,  -2.84176163e-02, &
         5.54283363e-03,   3.95434277e-03,  -1.98479086e-03, &
         1.00339208e-01,  -4.34643460e-02,  -1.82177954e-02, &
         1.62638575e-02,  -8.84148272e-03,  -9.57417512e-03, &
         9.40675747e-03,   6.37590839e-03,  -8.79090772e-03, &
        -1.50103636e-02,   2.80678872e-02,  -1.82911291e-02, &
        -1.88495102e-02,   1.69805915e-07,  -2.76524680e-07, &
         1.44642135e-03,  -3.03347141e-03,   2.93253041e-03, &
        -8.45508103e-03,   6.31891628e-03,  -8.96771404e-03, &
        -2.65114646e-08,   5.05920757e-08,   6.65511484e-04, &
         1.19130546e-03,   1.82906057e-03,   3.39308972e-03, &
        -7.90811707e-08,   1.62238741e-07,  -4.16393106e-08, &
         5.54588743e-08,  -1.16063796e-04,   8.22139896e-04, &
        -3.51041030e-04,   8.96739466e-04,   2.09603871e-08, &
        -3.76702959e-08,   2.36391411e-08,  -3.38128188e-08, &
        -5.54173599e-06,  -5.14204676e-05,   6.68980219e-09, &
        -2.16860568e-08,   9.12223751e-09,  -1.38472194e-08, &
         6.94482484e-09,  -7.74224962e-09,   7.36062570e-07, &
        -9.40351563e-06,  -2.23014657e-09,   6.74910119e-09, &
        -4.93824365e-09,   8.50272392e-09,  -6.91592964e-09, &
         8.88525527e-09 /)

      exlda = ax*(2d0*rho)**(1d0/3d0)

      s = gmag/((3d0*pi**2)**(1d0/3d0)*(2d0*rho)**(4d0/3d0))

      tautf = 0.6d0*(6d0*pi**2)**(2d0/3d0)*rho**(5d0/3d0)

      tauw = 0.25d0*gmag**2/rho

      alpha = (max(2d0*tau,tauw) - tauw)/tautf

      ts = 2d0*s**2/(q + s**2) - 1d0
      talpha = -(1d0 - alpha**2)**3/(1d0 + alpha**3 + alpha**6)

      bm(0) = 1d0
      bn(0) = 1d0
      bm(1) = ts
      bn(1) = talpha

      do i=2, 7
         bm(i) = (2d0*i-1d0)/i*ts*bm(i-1) - (i-1d0)/i*bm(i-2)
         bn(i) = (2d0*i-1d0)/i*talpha*bn(i-1) - (i-1d0)/i*bn(i-2)
      enddo

      fx = 0d0
      i = 1
      do m=0, 7
         do n=0, 7
            fx = fx + amn(i)*bm(n)*bn(m)
            i = i + 1
         enddo
      enddo

      ex = exlda*fx

      return

      end
