      subroutine rge2(up,agrup,delgrup,uplap,dn,agrdn,delgrdn,dnlap, &
                      exuprge2,exdnrge2,vxuprge2,vxdnrge2)

!A. Ruzsinszky, G. I. Csonka, and G. E. Scuseria, J. Chem. Theory Comput. 5, 763 (2009)

      implicit real*8(a-h,o-z)
      parameter(thrd=1.d0/3.d0,thrd2=2.d0*thrd)
      parameter(pi32=29.608813203268075856503472999628d0)

      rho2=2.d0*up
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrup/(2.d0*fk*rho2)
        u=4.d0*delgrup/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*uplap/(rho2*(2.d0*fk)**2)
        call exchrge2(rho2,s,u,v,exuprge2,vxuprge2)
      else
	exuprge2=0.d0
	vxuprge2=0.d0
      endif

      rho2=2.d0*dn
      if(rho2.gt.1d-18)then
        fk=(pi32*rho2)**thrd
        s=2.d0*agrdn/(2.d0*fk*rho2)
        u=4.d0*delgrdn/(rho2*rho2*(2.d0*fk)**3)
        v=2.d0*dnlap/(rho2*(2.d0*fk)**2)
        call exchrge2(rho2,s,u,v,exdnrge2,vxdnrge2)
      else
	exdnrge2=0.d0
	vxdnrge2=0.d0
      endif

      return
      end

!----------------------------------------------------------------------

      SUBROUTINE EXCHRGE2(rho,S,U,V,EX,VX)

      IMPLICIT REAL*8 (A-H,O-Z)
      parameter(thrd=1.d0/3.d0,thrd4=4.d0/3.d0)
      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(uk=0.8040d0,um=10.0d0/81.0d0)

! construct LDA exchange energy density
      exunif = AX*rho**THRD

! construct RGE2 enhancement factor
      s2 = s*s

      FxRGE2 = 1.0d0 + uk - uk/(1.0d0 + um/uk*s2 + (um/uk)**2*s2*s2)

      EX = exunif*FxRGE2

!  ENERGY DONE. NOW THE POTENTIAL:
!  find first and second derivatives of Fx w.r.t s.
!  Fs=(1/s)*d FxRGE2/ ds
!  Fss=d Fs/ds

      Fs = uk*(2.0d0*um/uk + 4.0d0*(um/uk)**2*s2)/ &
         (1.0d0 + um/uk*s2 + (um/uk)**2*s2*s2)**2

      Fss = -24.0d0*uk*((um/uk)**3*s2*s + (um/uk)**4*s2*s2*s)/ &
         (1.0d0 + um/uk*s2 + (um/uk)**2*s2*s2)**3

      VX = exunif*(THRD4*FxRGE2-(U-THRD4*S2*s)*FSS-V*FS)

      RETURN
      END
