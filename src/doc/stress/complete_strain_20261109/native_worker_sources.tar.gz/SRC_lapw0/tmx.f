      subroutine tmx(rhoup,gmagup,tauup,rhodn,gmagdn,taudn,exup,exdn)

!J. Tao and Y. Mo, Phys. Rev. Lett. 117, 073001 (2016).

      implicit none

      real*8, intent(in) :: rhoup, gmagup, tauup, rhodn, gmagdn, taudn

      real*8, intent(out) :: exup, exdn

      if (rhoup .gt. 1d-18) then
         call extmx(rhoup,gmagup,2d0*tauup,exup)
      else
         exup = 0d0
      endif

      if (rhodn .gt. 1d-18) then
         call extmx(rhodn,gmagdn,2d0*taudn,exdn)
      else
         exdn = 0d0
      endif

      return

      end

!-----------------------------------------------------------------------

      subroutine extmx(rho,gmag,tautmp,ex)

      implicit none

      real*8, intent(in) :: rho, gmag, tautmp

      real*8, intent(out) :: ex

      real*8 :: alpha, ax, beta, exlda, f, fxdme, fxsc, fxtm, lambda, &
         p, pi, qt, r, s, tau, tautf, tauw, w, y

      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(pi=3.1415926535897932384626433832795d0)
      parameter(lambda=0.6866d0)
      parameter(beta=79.873d0)

      exlda = ax*(2d0*rho)**(1d0/3d0)

      s = gmag/((3d0*pi**2)**(1d0/3d0)*(2d0*rho)**(4d0/3d0))

      p = s*s

      tautf = 0.3d0*(3d0*pi**2)**(2d0/3d0)*(2d0*rho)**(5d0/3d0)

      tauw = 0.25d0*gmag**2/rho

      tau = max(tautmp,tauw)

      if (abs(tau) .lt. 1.0d-18) tau = 1.0d-18

      alpha = (tau - tauw)/tautf

      y = p*(2d0*lambda - 1d0)**2

      f = (1d0 + 10d0*(70d0*y/27d0) + beta*y**2)**0.1d0

      r = 1d0 + 595d0*(2d0*lambda - 1d0)**2*p/54d0 - &
         (tau - 3d0*(lambda**2 - lambda + 0.5d0)*(tau - tautf - tauw/9d0))/tautf

      fxdme = 1d0/f**2 + 7d0*r/(9d0*f**4)

      qt = 9d0/20d0*(alpha - 1d0) + 2d0*p/3d0

      fxsc = (1d0 + 10d0*((10d0/81d0 + 50d0*p/729d0)*p + 146d0*qt**2/2025d0 - &
         (73d0*qt/405d0)*(3d0*tauw/(5d0*tau))*(1d0-tauw/tau)))**0.1d0

      w = ((tauw/tau)**2 + 3d0*(tauw/tau)**3)/(1d0 + (tauw/tau)**3)**2

      fxtm = w*fxdme + (1d0 - w)*fxsc

      ex = exlda*fxtm

      return

      end
