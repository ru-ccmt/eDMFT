        Subroutine CoulInt(R,DX,N,F)
!        use, intrinsic :: iso_c_binding
!
        implicit real(8) (a-h,o-z)
!
!       Create relevant Euler-Maclaurin terms for Coulomb integrals
        Dimension F(N), R(N), RX(N)
        Dimension G(N), H(N), C(N)  ! Gradiant, Hess, Cube terms
   !     real(C_LONG_DOUBLE) Sum
        real(8) Sum
!
!       Scale F, and create RT
        DO J=1,N
           RX(J) = dble(J)*DX
           F(J)  = F(J) * R(J)
        ENDDO
!
!       Spline Fit to get derivative corrections
        call Spline(N, RX, F, G, H, C)
!
!       Sum terms (use higher precision)
!       Put terms into RX
        RX(1) = 0.D0
        RX(2) = 0.5D0*F(1) + F(2)
!
        Sum = RX(2)
        DO J=3,N
           Sum   = Sum + F(J)
           RX(J) = Sum
        enddo
!
!       Pass through, copying to F for output, applying
!
        F(1) = 0.D0
        DO J=2,N
           F(J) = RX(J) - 0.5D0*F(J) &                   ! Extended Trapezoid
                - (DX/12.D0)*( G(J) - G(1)) &            ! First Correction
                + (DX*DX*DX)/(120.D0)*( C(J) - C(1)) ! Higher-order Correction
        ENDDO
!
!       Multiply by step DX
        call dscal(N,DX,F,1)
        return
        end
