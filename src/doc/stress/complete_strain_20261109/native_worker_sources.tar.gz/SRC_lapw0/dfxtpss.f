      SUBROUTINE DFXTPSS(fu,gmagu,tauup,fd,gmagd,taudn,gr,exu,exd)
      IMPLICIT REAL*8(A-H,O-Z)      
      PARAMETER(CON13=1.D0/3.D0)
      PARAMETER(PI=3.14159265358979323846264338327950D0)
!      PARAMETER(CON=0.6203504908994000166680068120477D0)
!      PARAMETER(ALPHA=1.919158292677513006624820326246D0)
!----------------------------------------------------------------------
!----------------------------------------------------------------------
! RHO=DENSITY
! ZETA=RELATIVE SPIN POLARIZATION
!      PI=4.*ATAN(1.)
      PI32=3.D0*PI**2
      CON=(3.D0/(4.D0*PI))**CON13
      ALPHA=(9.D0*PI/4.D0)**CON13
! spin unpolarized
!      rho=fu+fd
!      tau=tauup+taudn
!      IF(RHO.GT.1.D-18)THEN
!        CALL FX_tpss(RHO,gr,TAU,EX)
!        exu=ex
!        exd=ex
!      ELSE
!       EXU=0.D0
!       EXD=0.D0
!      ENDIF
!!      return
! UP DENSITY
      RHO2=2.d0*fu
      IF(RHO2.GT.1.D-18)THEN
!        FK=(PI32*RHO2)**CON13
!        S=2.d0*Gmagu/(2.D0*FK*RHO2)
!!        CALL FX_tpss(RHO2,S,2.d0*TAUup,EXU)
        tauup2=2.d0*TAUup
        CALL FX_tpss(RHO2,2.d0*gmagu,TAUup2,EXU)
        tauup=tauup2/2.d0
      ELSE
       EXU=0.D0
      ENDIF
!! REPEAT FOR DOWN
      RHO2=2.d0*fd
      IF(RHO2.GT.1D-18)THEN
!        FK=(PI32*RHO2)**CON13
!        S=2.d0*Gmagd/(2.D0*FK*RHO2)
        taudn2=2.d0*TAUdn
        CALL FX_tpss(RHO2,2.d0*gmagd,TAUdn2,EXD)
        taudn=taudn2/2.d0
      ELSE
       EXD=0.D0
      ENDIF
      RETURN
      END
