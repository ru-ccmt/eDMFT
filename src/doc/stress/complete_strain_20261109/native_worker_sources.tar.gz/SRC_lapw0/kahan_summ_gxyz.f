subroutine kahan_summ_gxyz1(gxyzu1,gxyzd1,gxyzud1,npt1,LLMM,weight, &
                     YY,sum0,spin,iatj,nat,lm,LMMAX,jatom,ir,debug,sigma_str)
!    use gga_str_kb, only: sigma_str
    use parallel, only :nstart,nstop,myid
    use densit, only: lmmaxx
    implicit none    
    include 'param.inc'
    
    REAL*8, INTENT(in)  :: gxyzu1(nspd),gxyzd1(nspd),gxyzud1(nspd)
    REAL*8, INTENT(in)  :: weight(nspd),   &
                           YY(NCOM,nspd), SUM0
    INTEGER, INTENT(in) :: npt1,LLMM,iatj,nat,ir,jatom
    INTEGER, INTENT(in) :: LM(2,NCOM+3,nat),LMMAX(nat)
    LOGICAL             :: spin,debug
    INTEGER             :: k,lm1    
    REAL*8              :: Y,T,CU,sumU,CD,sumD,CUD,sumUD,tmp, sigma_up,      &
                           sigma_dn,sigma_updn,tmpu,tmpd,tmp_ud,BBU(ncom),BBD(ncom), &
                           BB_UD(ncom),KBU(ncom),KBD(ncom),KB_UD(ncom)
    REAL*8              :: sigma_out(1:nrad,ncom+3,2)                       
    real*8              :: sigma_str(1:nrad,1:lmmaxx,nstart(myid):nstop(myid),1:3)

    CU=0.d0;CD=0.d0;CUD=0.d0;sumU=0.d0;sumD=0.d0;sumUD=0.d0    
    BBU=0.d0;BBD=0.d0;   BB_UD=0.d0     ! this was the error !
    
    DO K = 1, npt1
          tmp = YY(1,K)*weight(K)              
          Y    = tmp*gxyzu1(K) - CU
          T    = sumU + Y
          CU   = (T-sumU) - Y
          sumU = T 
          
          Y    = tmp*gxyzd1(K) - CD
          T    = sumD + Y
          CD   = (T-sumD) - Y
          sumD = T                        
          
          Y     = tmp*gxyzud1(K) - CUD
          T     = sumUD + Y
          CUD   = (T-sumUD) - Y
          sumUD = T
    ENDDO    
    sumU  = sumU  - CU*0.5D0
    sumD  = sumD  - CD*0.5D0            
    sumUD = sumUD - CUD*0.5D0
    
    DO k = 1,npt1
       sigma_up   = gxyzu1(k) - sumU
       sigma_dn   = gxyzd1(k) - sumD              
       sigma_updn = gxyzud1(k)- sumUD
       
       tmpu     = sigma_up*weight(k)                    
       IF(spin) then
         tmpd     = sigma_dn*weight(k)
         tmp_ud   = sigma_updn*weight(k)
         DO lm1 = 1,llmm
            Y = YY(lm1,k)*tmpu-CU
            T = BBU(lm1)+Y
            KBU(lm1) = (T-BBU(lm1))-Y
            BBU(lm1) = T
            
            Y = YY(lm1,k)*tmpd-CD
            T = BBD(lm1)+Y
            KBD(lm1) = (T-BBD(lm1))-Y
            BBD(lm1) = T              
            
            Y = YY(lm1,k)*tmp_ud-CUD
            T = BB_UD(lm1)+Y
            KB_UD(lm1) = (T-BB_UD(lm1))-Y
            BB_UD(lm1) = T            
         ENDDO
       ELSE
         DO lm1 = 1, llmm
            Y = YY(lm1,k)*tmpu-CU
            T = BBU(lm1)+Y
            KBU(lm1) = (T-BBU(lm1))-Y
            BBU(lm1) = T   
            
            BB_UD(lm1) = 0.d0
         ENDDO         
       ENDIF              
    ENDDO
    
    BBU(1)   = BBU(1)  +sumU*sum0
    BBD(1)   = BBD(1)  +sumD*sum0
    BB_UD(1) = BB_UD(1)+sumUD*sum0   
        
    DO lm1 = 1,llmm
       BBU(lm1)   = BBU(lm1)   - KBU(lm1)*0.5d0
       BBD(lm1)   = BBD(lm1)   - KBD(lm1)*0.5d0              
       BB_UD(lm1) = BB_UD(lm1) - KB_UD(lm1)*0.5d0
    ENDDO
    
    IF(debug) THEN
      IF(.not.spin) then
         BBD   = BBU 
         BB_UD = 0.d0
      endif
    ENDIF    
    
    IF(iatj .lt. 0) THEN
      DO lm1 = 1, llmm
         sigma_str(ir,lm1,jatom,1) = BBU(lm1)         
      ENDDO
    ELSE
      call cub_xc_back(sigma_str(1,1,jatom,1),ir,llmm,&
                  lm(1,1,jatom),BBU,lmmax(jatom))                              
    ENDIF
    IF(spin) THEN
      IF(iatj .lt. 0) THEN
        DO lm1 = 1, llmm
           sigma_str(ir,lm1,jatom,2) = BBD(lm1) 
           sigma_str(ir,lm1,jatom,3) = BB_UD(lm1)
        ENDDO
      ELSE
        call cub_xc_back(sigma_str(1,1,jatom,2),ir,llmm,&
                  lm(1,1,jatom),BBD,lmmax(jatom))        
        call cub_xc_back(sigma_str(1,1,jatom,3),ir,llmm,&
                  lm(1,1,jatom),BB_UD,lmmax(jatom))                          
      ENDIF
    ENDIF
    
    IF(.not.spin) THEN
      sigma_str(ir,1:lmmax(jatom),jatom,2) = sigma_str(ir,1:lmmax(jatom),jatom,1)      
      sigma_str(ir,1:lmmax(jatom),jatom,3) = 0.d0
    ENDIF                
    
RETURN
END
