      subroutine lyp(rhoup,rhodn,agrup,agrdn,agr,g2up,g2dn, &
        gdggu,gdggd,gdggt,ec,vcup,vcdn)

!C. Lee, W. Yang, and R. G. Parr, Phys. Rev. B 37, 785 (1988).

      implicit none

      real*8, intent(in) :: rhoup, rhodn, agrup, agrdn, agr, g2up, g2dn, &
       gdggu, gdggd, gdggt

      real*8, intent(out) :: ec, vcup, vcdn

      real*8 :: pi, a, b, c, d, cf, &
        rho, rhom1, rhom2, rhom5, rhom13, rhom43, rhom53, rhom73, &
        rhom113, rhom143, grhogrho, grhoupgrhoup, grhodngrhodn, &
        grhoupgrhodn, grhogrhoup, grhogrhodn, fdr, fec, &
        f1, df1drho, df1drhoup, df1drhodn, f2, df2drho, &
        f3, df3drhoup, df3drhodn, f4, df4drhoup, df4drhodn, &
        f5, df5drho, f6, df6drho, f7, df7drho, &
        f8up, df8updrho, df8updrhoup, f8dn, df8dndrho, df8dndrhodn, &
        f9, df9drho, f10up, df10updrho, df10updrhoup, f10dn, &
        df10dndrho, df10dndrhodn, fff1, fff2, dedrhoup, dedrhodn, &
        dedgrup2, dedgrdn2, dedgr2, drdeup, drdedn, drde

      parameter(pi=3.141592653589793238462643383279502884197d0, &
        a=0.04918d0, b=0.132d0, c=0.2533d0, d=0.349d0, &
        cf=0.3d0*(3d0*pi**2)**(2d0/3d0))

      rho = rhoup + rhodn

      if (rho .gt. 1d-12) then

        rhom1 = rho**(-1d0)
        rhom2 = rho**(-2d0)
        rhom5 = rho**(-5d0)
        rhom13 = rho**(-1d0/3d0)
        rhom43 = rho**(-4d0/3d0)
        rhom53 = rho**(-5d0/3d0)
        rhom73 = rho**(-7d0/3d0)
        rhom113 = rho**(-11d0/3d0)
        rhom143 = rho**(-14d0/3d0)

        grhogrho = agr**2
        grhoupgrhoup = agrup**2
        grhodngrhodn = agrdn**2
        grhoupgrhodn = 0.5d0*(grhogrho - grhoupgrhoup - grhodngrhodn)
        grhogrhoup = grhoupgrhoup + grhoupgrhodn
        grhogrhodn = grhodngrhodn + grhoupgrhodn

        fdr = 1d0/(1d0 + d*rhom13)

        fec = exp(-c*rhom13)

        f1 = -4d0*a*fdr*rhoup*rhodn*rhom1

        df1drho = -(4d0/3d0)*a*d*fdr**2*rhoup*rhodn*rhom73 + &
          4d0*a*fdr*rhoup*rhodn*rhom2

        df1drhoup = -4d0*a*fdr*rhodn*rhom1

        df1drhodn = -4d0*a*fdr*rhoup*rhom1

        f2 = -a*b*fec*fdr*rhom113

        df2drho = -(1d0/3d0)*a*b*c*fec*fdr*rhom5 - &
          (1d0/3d0)*a*b*d*fec*rhom5*fdr**2 + &
          (11d0/3d0)*a*b*fec*fdr*rhom143

        f3 = rhoup*rhodn

        df3drhoup = rhodn

        df3drhodn = rhoup

        f4 = 2d0**(11d0/3d0)*cf*(rhoup**(8d0/3d0) + rhodn**(8d0/3d0))

        df4drhoup = (8d0/3d0)*2d0**(11d0/3d0)*cf*rhoup**(5d0/3d0)

        df4drhodn = (8d0/3d0)*2d0**(11d0/3d0)*cf*rhodn**(5d0/3d0)

        f5 = 47d0/18d0 - (7d0/18d0)*(c*rhom13 + d*rhom13*fdr)

        df5drho=(7d0/54d0)*(c*rhom43+d*rhom43*fdr-d**2*rhom53*fdr**2)

        f6 = -2.5d0 + (1d0/18d0)*(c*rhom13 + d*rhom13*fdr)

        df6drho=-(1d0/54d0)*(c*rhom43+d*rhom43*fdr-d**2*rhom53*fdr**2)

        f7 = 11d0/9d0 - (1d0/9d0)*(c*rhom13 + d*rhom13*fdr)

        df7drho=(1d0/27d0)*(c*rhom43+d*rhom43*fdr-d**2*rhom53*fdr**2)

        f8up = rhoup*rhom1

        df8updrho = -rhoup*rhom2

        df8updrhoup = rhom1

        f8dn = rhodn*rhom1

        df8dndrho = -rhodn*rhom2

        df8dndrhodn = rhom1

        f9 = -(2d0/3d0)*rho**2

        df9drho = -(4d0/3d0)*rho

        f10up = (2d0/3d0)*rho**2 - rhoup**2

        df10updrho = (4d0/3d0)*rho

        df10updrhoup = -2d0*rhoup

        f10dn = (2d0/3d0)*rho**2 - rhodn**2

        df10dndrho = (4d0/3d0)*rho

        df10dndrhodn = -2d0*rhodn

        fff1 = f4 + f5*agr**2 + f6*(agrup**2 + agrdn**2) + &
          f7*(f8up*agrup**2 + f8dn*agrdn**2)

        fff2 = f3*fff1 + f9*agr**2 + f10up*agrdn**2 + f10dn*agrup**2

        ec = (f1 + f2*fff2)*rhom1

        dedrhoup = df1drhoup + df1drho + df2drho*fff2 + f2*( &
          df3drhoup*fff1 + f3*(df4drhoup + df5drho*agr**2 + &
          df6drho*(agrup**2 + agrdn**2) + &
          df7drho*(f8up*agrup**2 + f8dn*agrdn**2) + &
          f7*((df8updrhoup+df8updrho)*agrup**2+df8dndrho*agrdn**2)) + &
          df9drho*agr**2 + (df10updrhoup + df10updrho)*agrdn**2 + &
          df10dndrho*agrup**2)

        dedrhodn = df1drhodn + df1drho + df2drho*fff2 + f2*( &
          df3drhodn*fff1 + f3*(df4drhodn + df5drho*agr**2 + &
          df6drho*(agrdn**2 + agrup**2) + &
          df7drho*(f8dn*agrdn**2 + f8up*agrup**2) + &
          f7*((df8dndrhodn+df8dndrho)*agrdn**2+df8updrho*agrup**2)) + &
          df9drho*agr**2 + (df10dndrhodn + df10dndrho)*agrup**2 + &
          df10updrho*agrdn**2)

        dedgrup2 = f2*(f3*(f6 + f7*f8up) + f10dn)

        dedgrdn2 = f2*(f3*(f6 + f7*f8dn) + f10up)

        dedgr2 = f2*(f3*f5 + f9)

        drdeup = (f3*(f6 + f7*f8up) + f10dn)*df2drho*grhogrhoup + &
          f2*((f6 + f7*f8up)* &
          (df3drhoup*grhoupgrhoup + df3drhodn*grhoupgrhodn) + &
          f3*(df6drho*grhogrhoup + f8up*df7drho*grhogrhoup + &
          f7*(df8updrho*grhogrhoup + df8updrhoup*grhoupgrhoup)) + &
          df10dndrho*grhogrhoup + df10dndrhodn*grhoupgrhodn)

        drdedn = (f3*(f6 + f7*f8dn) + f10up)*df2drho*grhogrhodn + &
          f2*((f6 + f7*f8dn)* &
          (df3drhodn*grhodngrhodn + df3drhoup*grhoupgrhodn) + &
          f3*(df6drho*grhogrhodn + f8dn*df7drho*grhogrhodn + &
          f7*(df8dndrho*grhogrhodn + df8dndrhodn*grhodngrhodn)) + &
          df10updrho*grhogrhodn + df10updrhoup*grhoupgrhodn)

        drde = (f3*f5 + f9)*df2drho*grhogrho + &
          f2*(f5*(df3drhoup*grhogrhoup + df3drhodn*grhogrhodn) + &
          f3*df5drho*grhogrho + df9drho*grhogrho)

        vcup = dedrhoup - 2d0*drdeup - 2d0*dedgrup2*g2up - 2d0*drde - &
          2d0*dedgr2*(g2up + g2dn)

        vcdn = dedrhodn - 2d0*drdedn - 2d0*dedgrdn2*g2dn - 2d0*drde - &
          2d0*dedgr2*(g2up + g2dn)

      else

        ec = 0d0
        vcup = 0d0
        vcdn = 0d0

      endif

      return

      end
