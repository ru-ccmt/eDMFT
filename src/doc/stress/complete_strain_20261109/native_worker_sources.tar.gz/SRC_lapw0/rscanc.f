      subroutine rscanc(rhoup,rhodn,gmag,tauup,taudn,ec)

!A. P. Bartok and J. R. Yates, J. Chem. Phys. 150, 161101 (2019).

      implicit none

      real*8, intent(in) :: rhoup, rhodn, gmag, tauup, taudn

      real*8, intent(out) :: ec

      real*8 :: a, alfc, alpha, b1c, b2c, b3c, beta, c1c, c2c, &
         chiinfzeta0, dc, ds, dx, ec0, ec1, eclda0, eclsda1, ecrs, &
         eczeta, fca, g, gamma, gc, ginfzeta0, h0, h1, phi, pi, rho, &
         rs, s, t, tau, tautf, tauw, vclsdadn, vclsdaup, w0, w1, zeta, &
         c0, c1, c2, c3, c4, c5, c6, c7

      parameter(pi=3.1415926535897932384626433832795d0)
      parameter(b1c=0.0285764d0)
      parameter(b2c=0.0889d0)
      parameter(b3c=0.125541d0)
      parameter(c1c=0.64d0)
      parameter(c2c=1.5d0)
      parameter(dc=0.7d0)
      parameter(gamma=0.031091d0)
      parameter(c0=1d0,c1=-0.64d0,c2=-0.4352d0,c3=-1.535685604549d0, &
         c4=3.061560252175d0,c5=-1.915710236206d0,c6=0.516884468372d0, &
         c7=-0.051848879792d0)

      rho = rhoup + rhodn

      rs = (0.75d0/(pi*rho))**(1d0/3d0)

      s = gmag/(2d0*(3d0*pi**2)**(1d0/3d0)*rho**(4d0/3d0))

      zeta = (rhoup - rhodn)/rho

      ds = 0.5d0*((1d0 + zeta)**(5d0/3d0) + (1d0 - zeta)**(5d0/3d0))

      tautf = (0.3d0*(3d0*pi**2)**(2d0/3d0)*rho**(5d0/3d0) + 1d-4)*ds

      tauw = 0.125d0*gmag**2/rho

      tau = tauup + taudn

      alpha = (max(tau,tauw) - tauw)/tautf
      alpha = alpha**3/(alpha**2 + 1d-3)


      beta = 0.066725d0*(1d0 + 0.1d0*rs)/(1d0 + 0.1778d0*rs)

      phi = 0.5d0*((1d0 + zeta)**(2d0/3d0) + (1d0 - zeta)**(2d0/3d0))

      t = (3d0*pi**2/16d0)**(1d0/3d0)*s/(phi*rs**0.5d0)

      call corlsd(rs,zeta,eclsda1,vclsdaup,vclsdadn,ecrs,eczeta,alfc)

      w1 = exp(-eclsda1/(gamma*phi**3)) - 1d0

      a = beta/(gamma*w1)

      g = 1d0/(1d0 + 4d0*a*t**2)**0.25d0

      h1 = gamma*phi**3*log(1d0 + w1*(1d0 - g))

      ec1 = eclsda1 + h1


      eclda0 = -b1c/(1d0 + b2c*rs**0.5d0 + b3c*rs)

      w0 = exp(-eclda0/b1c) - 1d0

      dx = 0.5d0*((1d0 + zeta)**(4d0/3d0) + (1d0 - zeta)**(4d0/3d0))

      chiinfzeta0 = 0.128026d0

      ginfzeta0 = 1d0/(1d0 + 4d0*chiinfzeta0*s**2)**0.25d0

      h0 = b1c*log(1d0 + w0*(1d0 - ginfzeta0))

      gc = (1d0 - 2.3631d0*(dx - 1d0))*(1d0 - zeta**12)

      ec0 = (eclda0 + h0)*gc


      if (alpha .lt. 2.5d0) then
         fca = c0 + c1*alpha + c2*alpha**2 + c3*alpha**3 + c4*alpha**4 + &
            c5*alpha**5 + c6*alpha**6 + c7*alpha**7
      elseif (alpha .ge. 2.5d0) then
         fca = -dc*exp(c2c/(1d0-alpha))
      endif

      ec = ec1 + fca*(ec0 - ec1)

      return

      end
