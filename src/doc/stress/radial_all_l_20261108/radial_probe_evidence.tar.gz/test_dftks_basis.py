"""Native dftKS response worker against the corrected WIEN reference."""
from pathlib import Path
import os,json,subprocess,shutil,sys,time,hashlib
import numpy as np
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'src/python'))
from check_oneparticle_stress_fd import read_basis_matrix
from test_wien_matrices import vectors
ENV=os.environ.copy()
for k in list(ENV):
 if k.startswith(('DFTKS_','EDMFT_','WIEN_LAPW1_','WIEN_STRESS_')):del ENV[k]
ENV.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
def aligned(a,b):
 assert a.nbasis==b.nbasis and a.nlo==b.nlo
 n=a.nbasis-a.nlo;assert np.array_equal(a.labels[:,n:],b.labels[:,n:]),'LO label mismatch'
 lookup={tuple(g):i for i,g in enumerate(b.labels[:,:n].T)}
 perm=[lookup[tuple(g)] for g in a.labels[:,:n].T]+list(range(n,a.nbasis))
 return b.matrix[np.ix_(perm,perm)]
results={}
for case,nat,cplx in [('SrVO3',4,True),('FeSe',2,False)]:
 d=r/'tests'/(case+'_dftks_basis');d.mkdir(exist_ok=True)
 source=r/'tests'/(case+'_all_l_restored')/'plus_1e-05'
 for p in source.iterdir():
  if p.is_file() and (p.suffix in {'.struct','.in1','.in1c','.klist','.vsp','.vns'} or p.name=='lapw1.def'):shutil.copy2(p,d/p.name)
 p=d/(case+'.klist');p.write_text('\n'.join(p.read_text().splitlines()[:3])+'\nEND\n')
 label_lines=[]
 for k in range(1,4):
  a=read_basis_matrix(source/f'native.k{k:08d}.bin',b'EDMFTOV1')
  for slot,g in enumerate(a.labels[:,-a.nlo:].T,1):label_lines.append(' '.join(map(str,[k,slot,*g])))
 (d/'lo_labels.dat').write_text('\n'.join(label_lines)+'\n')
 exe=r/'src/dftKS'/('lapw1c' if cplx else 'lapw1');vals={} 
 for label,nt,only in [('normal',1,False),('worker1',1,True),('worker4',4,True)]:
  before={s:hashlib.sha256((d/(case+'.'+s)).read_bytes()).hexdigest() for s in ['vector','energy','nsh'] if (d/(case+'.'+s)).exists()}
  env=ENV|{'DFTKS_FIXED_LO_LABELS':str(d/'lo_labels.dat'),'DFTKS_BASIS_VSP':str(d/'basis.vsp'),'DFTKS_OVERLAP_DUMP':str(d/label)}
  if only:env['DFTKS_MATRICES_ONLY']='1'
  t=time.monotonic()
  with (d/(label+'.log')).open('w') as out:p=subprocess.run(['/opt/homebrew/bin/mpirun','-n',str(nt),str(exe),'lapw1.def'],cwd=d,env=env,stdout=out,stderr=subprocess.STDOUT)
  if p.returncode or any(p.read_text().strip() for p in d.glob('lapw1.error*')):raise RuntimeError((d/(label+'.log')).read_text()[-2200:])
  vals[label]={'seconds':time.monotonic()-t}
  if only:
   assert before=={s:hashlib.sha256((d/(case+'.'+s)).read_bytes()).hexdigest() for s in before}
   vals[label]['protected_outputs_unchanged']=True
  differences=[]
  for k in range(1,4):
   c={}
   for kind,magic in [('k',b'EDMFTOV1'),('ham.k',b'EDMFTHV1')]:
    a=read_basis_matrix(source/f'native.{kind}{k:08d}.bin',magic);b=read_basis_matrix(d/f'{label}.{kind}{k:08d}.bin',magic)
    c[kind]=float(np.max(abs(a.matrix-aligned(a,b))))
    if only:
     orig=read_basis_matrix(d/f'normal.{kind}{k:08d}.bin',magic)
     assert np.array_equal(orig.matrix,b.matrix)
   differences.append(c)
  vals[label]['max_WIEN_matrix_differences']=differences
 identities=[]
 for k,(e,c,labels) in enumerate(vectors(d/(case+'.vector'),nat,cplx),1):
  h=read_basis_matrix(d/f'normal.ham.k{k:08d}.bin',b'EDMFTHV1');o=read_basis_matrix(d/f'normal.k{k:08d}.bin',b'EDMFTOV1')
  identities.append({'O':float(np.max(abs(c.conj().T@o.matrix@c-np.eye(len(e))))),'H':float(np.max(abs(c.conj().T@h.matrix@c-np.diag(e))))})
 vals['identities']=identities;results[case]=vals;print(case,json.dumps(vals,indent=2),flush=True)
 (r/'dftks_basis_results.json').write_text(json.dumps(results,indent=2)+'\n')
