from pathlib import Path
r=Path(__file__).resolve().parent
s=(r/'test_dftks_basis.py').read_text().replace("(case+'_dftks_basis')","(case+'_order5_control')").replace("r/'tests'/(case+'_all_l_restored')/'plus_1e-05'","r/'tests'/(case+'_fixed_energies')").replace("r/'src/dftKS'","r/'dftks_order5_control'").replace('dftks_basis_results.json','order5_results.json')
exec(compile(s,'order5_worker_test','exec'))
