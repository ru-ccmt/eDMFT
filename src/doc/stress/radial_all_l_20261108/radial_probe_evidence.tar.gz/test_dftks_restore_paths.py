"""Independent operator-restoration tests within dftKS's own radial solver."""
from pathlib import Path
import os,sys,subprocess,shutil,json
import numpy as np
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'src/python'))
from check_oneparticle_stress_fd import read_basis_matrix
ENV=os.environ.copy()
for k in list(ENV):
 if k.startswith(('DFTKS_','EDMFT_','WIEN_LAPW1_','WIEN_STRESS_')):del ENV[k]
ENV.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
results={}
for case,cplx in [('SrVO3',True),('FeSe',False)]:
 dirs=[]
 for nsl in [4,10]:
  src=r/'tests'/(case+'_restore_check')/str(nsl);d=r/'tests'/(case+'_dftks_restore')/str(nsl);d.mkdir(parents=True,exist_ok=True);dirs.append(d)
  for p in src.iterdir():
   if p.is_file() and (p.suffix in {'.struct','.in1','.in1c','.vsp','.vns','.klist'} or p.name=='lapw1.def'):shutil.copy2(p,d/p.name)
  exe=r/'src/dftKS'/('lapw1c' if cplx else 'lapw1')
  for label,basis in [('native','basis.vsp'),('zero',case+'.vsp'),('ordinary',None)]:
   env=ENV|{'DFTKS_MATRICES_ONLY':'1','DFTKS_OVERLAP_DUMP':str(d/label)}
   if basis:env['DFTKS_BASIS_VSP']=str(d/basis)
   with (d/(label+'.log')).open('w') as log:p=subprocess.run(['/opt/homebrew/bin/mpirun','-n','4',str(exe),'lapw1.def'],cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT)
   assert p.returncode==0,(d/(label+'.log')).read_text()
   assert not any(p.read_text().strip() for p in d.glob('lapw1.error*'))
 checks=[]
 for k in range(1,4):
  row={}
  for kind,magic in [('k',b'EDMFTOV1'),('ham.k',b'EDMFTHV1')]:
   a,b=[read_basis_matrix(d/f'native.{kind}{k:08d}.bin',magic) for d in dirs]
   assert np.array_equal(a.labels,b.labels)
   err=float(np.max(abs(a.matrix-b.matrix)));assert err<2e-11,err
   row[kind]=err
   for d in dirs:
    a,b=[read_basis_matrix(d/f'{prefix}.{kind}{k:08d}.bin',magic) for prefix in ['zero','ordinary']]
    assert np.array_equal(a.matrix,b.matrix)
  checks.append(row)
 results[case]={'independent_paths':checks,'zero_probe_bitwise_identical':True};print(case,results[case],flush=True)
(r/'dftks_restore_paths.json').write_text(json.dumps(results,indent=2)+'\n')
