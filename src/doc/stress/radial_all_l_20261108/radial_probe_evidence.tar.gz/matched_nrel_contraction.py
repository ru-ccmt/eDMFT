"""Compare old radial contraction on the new symmetric all-l basis path."""
from pathlib import Path
import os,shutil,subprocess,sys,json,re
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/private/tmp/radial_stress_response_20261108')
from run_tests import clone,derivative
ENV=os.environ.copy()
for k in list(ENV):
 if k.startswith(('DFTKS_','EDMFT_','WIEN_LAPW1_','WIEN_STRESS_')):del ENV[k]
ENV.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',WIENROOT='/Users/haule/wien2k_24')
def execute(d,label,args,extra={}):
 with (d/(label+'.log')).open('w') as log:r=subprocess.run(args,cwd=d,env=ENV|extra,stdout=log,stderr=subprocess.STDOUT)
 txt=(d/(label+'.log')).read_text()
 if r.returncode or any(x in txt for x in ['ERROR STOP','Fortran runtime error']):raise RuntimeError(txt[-2000:])
 print(d,label,flush=True)

def run(case):
 old=ROOT/'tests'/(case+'_NREL_control')/'center'
 parent=ROOT/'tests'/(case+'_NREL_control');in2=case+('.in2c' if case=='SrVO3' else '.in2')
 for sign in ['minus','plus']:
  src=parent/(sign+'_5e-06');d=parent/(sign+'_radial_tables');clone(old,d,case)
  for suffix in ['vector','energy','nsh']:shutil.copy2(src/(case+'.'+suffix),d/(case+'.'+suffix))
  shutil.copy2(src/'basis.vsp',d/(case+'.vsp'))
  p=d/in2;a=p.read_text().splitlines();a[0]='TOT '+a[0][4:];p.write_text('\n'.join(a)+'\n')
  execute(d,'lapw2',['/Users/haule/wien2k_24/'+('lapw2c' if case=='SrVO3' else 'lapw2'),'lapw2.def'],{'WIEN_STRESS_RADIAL_DUMP':str(d/'radial.dump')})
 response=parent/'matched_radial_response.dat'
 derivative(parent/'minus_radial_tables/radial.dump',parent/'plus_radial_tables/radial.dump',5e-6,response)
 d=parent/'matched_contraction';clone(old,d,case)
 p=d/in2;a=p.read_text().splitlines();a[0]='STR '+a[0][4:];p.write_text('\n'.join(a)+'\n')
 for suffix in ['vector','energy','nsh','weight']:shutil.copy2(old/(case+'.'+suffix),d/(case+'.'+suffix))
 execute(d,'dmft2',['/opt/homebrew/bin/mpirun','-n','4','/Users/haule/dbin/dmft2_response','dmft2.def'],{'EDMFT_STRESS_RADIAL_RESPONSE':str(response)})
 text=(d/(case+'.outputdmf2')).read_text();out='\n'.join(line for line in text.splitlines() if 'RADIAL_FD_' in line and ('GPA' in line or 'RY' in line));print(out,flush=True)
 (parent/'matched_contraction.txt').write_text(out+'\n')
if __name__=='__main__':run(sys.argv[1])
