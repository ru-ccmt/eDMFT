"""Compare independent spherical Legendre and full HNS/Gaunt assembly paths."""
from pathlib import Path
import re,os,json,shutil,subprocess,sys,hashlib
import numpy as np
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'src/python'))
from check_oneparticle_stress_fd import read_basis_matrix
from test_wien_matrices import vectors
ENV=os.environ.copy()
for k in list(ENV):
 if k.startswith(('DFTKS_','EDMFT_','WIEN_LAPW1_','WIEN_STRESS_')):del ENV[k]
ENV.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
results={}
for case,nat,cplx in [('SrVO3',4,True),('FeSe',2,False)]:
 root=r/'tests'/(case+'_restore_check');root.mkdir(exist_ok=True)
 old=Path('/private/tmp/radial_stress_response_20261108')/(case+'_DFT')
 for nsl in [4,10]:
  d=root/str(nsl);d.mkdir(exist_ok=True)
  for p in (old/'center').iterdir():
   if p.is_file() and (p.suffix in {'.struct','.in1','.in1c','.vsp','.vns','.klist'} or p.name=='lapw1.def'):shutil.copy2(p,d/p.name)
  p=d/(case+'.klist');p.write_text('\n'.join(p.read_text().splitlines()[:3])+'\nEND\n')
  # Disable only nonspherical MT harmonics; preserve interstitial coefficients.
  p=d/(case+'.vns');s=p.read_text();pos=s.index('NUMBER OF PW');prefix=s[:pos];suffix=s[pos:]
  prefix=re.sub(r'[-+]?\d+\.\d+[EeDd][-+]\d+',lambda m:f'{0.0:{len(m.group())}.12E}',prefix)
  p.write_text(prefix+suffix)
  p=d/(case+('.in1c' if cplx else '.in1'));lines=p.read_text().splitlines();a=lines[1].split();a[2]=str(nsl);lines[1]=' '.join(a);p.write_text('\n'.join(lines)+'\n')
  shutil.copy2(old/'plus/basis.vsp',d/'basis.vsp')
  exe=r/'wien/SRC_lapw1'/('lapw1c' if cplx else 'lapw1')
  env=ENV|{'WIEN_LAPW1_BASIS_VSP':str(d/'basis.vsp'),'WIEN_LAPW1_MATRIX_DUMP':str(d/'native')}
  with (d/'run.log').open('w') as log:p=subprocess.run([str(exe),'lapw1.def'],cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT)
  if p.returncode or any(p.read_text().strip() for p in d.glob('lapw1.error*')):raise RuntimeError((d/'run.log').read_text()[-2000:])
 checks=[]
 for k in range(1,4):
  vals={}
  for kind,magic in [('k',b'EDMFTOV1'),('ham.k',b'EDMFTHV1')]:
   a=read_basis_matrix(root/'4'/f'native.{kind}{k:08d}.bin',magic);b=read_basis_matrix(root/'10'/f'native.{kind}{k:08d}.bin',magic)
   assert np.array_equal(a.labels,b.labels)
   vals[kind]=float(np.max(abs(a.matrix-b.matrix)))
   assert vals[kind]<1e-11,vals
  checks.append(vals)
 results[case]=checks;print(case,checks,flush=True)
(r/'restore_path_equivalence.json').write_text(json.dumps(results,indent=2)+'\n')
