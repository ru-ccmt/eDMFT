"""Install only the verified opt-in probes; preserve preexisting working edits."""
from pathlib import Path
import hashlib,json,shutil,difflib,subprocess
r=Path(__file__).resolve().parent
repo=Path('/Users/haule/projects/eDMFT_new');wien=Path('/Users/haule/wien2k_24')
doc=repo/'src/doc/stress/radial_all_l_20261108'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
# Verify the exact dirty-file baselines before any mutation.
groups=[(repo,r/'src/dftKS',r/'before_dftks','src/dftKS',['modules.FPP','read_and_initialize.FPP','atpar.f90','hamilt.FPP']),
        (wien,r/'wien/SRC_lapw1',r/'before','SRC_lapw1',['modules.F','atpar.F','hamilt.F'])]
for root,new,old,prefix,names in groups:
 for name in names:
  p=root/prefix/name
  if p.read_bytes()!=(old/name).read_bytes():raise RuntimeError(f'Baseline changed: {p}')
for f in ['ordinary_regression.json','matrix_worker_regression.json','restore_path_equivalence.json','dftks_restore_paths.json','dftks_basis_results.json']:
 assert (r/f).is_file(),f
assert not doc.exists(),doc
doc.mkdir(parents=True);(doc/'before_installation').mkdir()
manifest={'authorization':'user: yes, you can','sources':[],'executables':[],'production_radial_correction_enabled':False}
for idx,(root,new,old,prefix,names) in enumerate(groups,1):
 patch=[]
 for name in names:
  dest=root/prefix/name;original=old/name;modified=new/name
  backup=doc/'before_installation'/prefix/name;backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,backup)
  patch+=list(difflib.unified_diff(original.read_text().splitlines(True),modified.read_text().splitlines(True),fromfile='a/'+prefix+'/'+name,tofile='b/'+prefix+'/'+name))
  manifest['sources'].append({'path':str(dest),'before_sha256':sha(dest),'after_sha256':sha(modified)})
 p=doc/(f'000{idx}-'+('dftks-alternate-basis.patch' if idx==1 else 'wien-all-angular-restoration.patch'));p.write_text(''.join(patch))
 subprocess.run(['git','apply','--check',str(p)],cwd=root,check=True)
for root,new,old,prefix,names in groups:
 for name in names:shutil.copy2(new/name,root/prefix/name)
for srcroot,dstroot,label in [(r/'src/dftKS',Path('/Users/haule/dbin'),'dbin'),(r/'wien/SRC_lapw1',wien,'wien')]:
 for name in ['lapw1','lapw1c']:
  dst=dstroot/name;src=srcroot/name
  assert not dst.is_symlink()
  shutil.copy2(dst,doc/'before_installation'/(label+'_'+name))
  record={'path':str(dst),'before_sha256':sha(dst),'after_sha256':sha(src)}
  tmp=dst.with_name('.'+name+'.response-install');shutil.copy2(src,tmp);tmp.replace(dst)
  assert sha(dst)==record['after_sha256'];manifest['executables'].append(record)
(doc/'INSTALLATION.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(doc)
