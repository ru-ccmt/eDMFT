from pathlib import Path
import shutil,json,hashlib,tarfile,difflib,subprocess,tempfile
r=Path(__file__).resolve().parent;repo=Path('/Users/haule/projects/eDMFT_new');doc=repo/'src/doc/stress/radial_all_l_20261108';old=repo/'src/doc/stress/response_engine_plan_20261108'
shutil.copy2(r/'REPORT.txt',doc/'REPORT.txt')
# Keep the earlier report as a historical checkpoint, but make installation status unambiguous.
p=old/'REPORT.txt';s=p.read_text();prefix='UPDATE AFTER USER APPROVAL: these patches were installed. See INSTALLATION.json\nand ../radial_all_l_20261108/REPORT.txt for the subsequent all-angular repair\nand new NREL/RELA tests. The text below is the pre-approval checkpoint.\n\n'
if not s.startswith('UPDATE AFTER USER APPROVAL:'):p.write_text(prefix+s)
for p in r.glob('*.json'):shutil.copy2(p,doc/p.name)
# Preserve the independently verified deployment manifest, which is not in scratch.
with tarfile.open(doc/'radial_probe_evidence.tar.gz','w:gz') as tar:
 for dirname in ['before','before_dftks']:
  tar.add(r/dirname,arcname=dirname)
 for p in r.iterdir():
  if p.is_file() and p.suffix in ['.py','.json','.log','.txt']:tar.add(p,arcname=p.name)
 for folder,files in [('src/dftKS',['modules.FPP','read_and_initialize.FPP','atpar.f90','hamilt.FPP']),('wien/SRC_lapw1',['modules.F','atpar.F','hamilt.F'])]:
  for name in files:tar.add(r/folder/name,arcname='sources/'+folder+'/'+name)
 for p in (r/'tests').rglob('*'):
  if not p.is_file():continue
  if p.suffix in {'.json','.npz','.log','.txt','.struct','.in1','.in1c','.in2','.in2c','.vsp','.def','.weight','.klist'} or p.name in ['radial.dump','matched_radial_response.dat']:
   tar.add(p,arcname=str(p.relative_to(r)))
# A single incremental WIEN supplement with exact accepted source fingerprints.
sup=repo/'wien2k_patches/wien2k24_stress_20261102/supplements/response_probes_20261108';sup.mkdir()
pairs=[('atpar.F',Path('/private/tmp/edmft_stress_development_20261108/before/atpar_wien.F')),('calkpt.F',Path('/private/tmp/edmft_stress_development_20261108/before/calkpt.F')),('modules.F',r/'before/modules.F'),('hamilt.F',r/'before/hamilt.F')]
patch=[];manifest={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,before in pairs:
 after=Path('/Users/haule/wien2k_24/SRC_lapw1')/name;rel='SRC_lapw1/'+name
 patch+=list(difflib.unified_diff(before.read_text().splitlines(True),after.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 manifest[rel]={'before_sha256':sha(before),'after_sha256':sha(after)}
(sup/'response-probes.patch').write_text(''.join(patch));(sup/'source_changes.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Validate the combined supplement against its exact baseline in a disposable copy.
with tempfile.TemporaryDirectory() as tmp:
 for name,before in pairs:
  dest=Path(tmp)/'SRC_lapw1'/name;dest.parent.mkdir(exist_ok=True);shutil.copy2(before,dest)
 subprocess.run(['git','apply',str(sup/'response-probes.patch')],cwd=tmp,check=True)
 for path,item in manifest.items():assert sha(Path(tmp)/path)==item['after_sha256']
(sup/'README.txt').write_text('''Optional response probes, 8 November 2026

Adds native LAPW1 H/O dumps, low-l controls, and all-angular restoration for
an alternate radial basis. Ordinary execution is unchanged with flags absent.
See src/doc/stress/radial_all_l_20261108/REPORT.txt in the eDMFT repository for
results, conventions, limitations, and the unresolved RELA radial comparison.

This is an INCREMENTAL supplement to the exact development sources recorded
in source_changes.json. It is not a replacement for the cumulative stress
patch. The baseline includes earlier fixed-band/debug changes; verify hashes
before applying, and do not force a patch onto an unknown source version.
No compiler settings or Makefiles are changed. Build real and complex LAPW1
with the destination site's normal toolchain after applying it. The native
matrix dump currently requires a serial WIEN LAPW1 build.

The combined patch was applied to a disposable exact-baseline tree and all
resulting hashes verified. No remote deployment was performed in this pass.
''')
checks={p.name:sha(p) for p in sup.iterdir() if p.is_file()};(sup/'SHA256.json').write_text(json.dumps(checks,indent=2)+'\n')
checks={p.name:sha(p) for p in doc.iterdir() if p.is_file()};(doc/'SHA256.json').write_text(json.dumps(checks,indent=2)+'\n')
print(doc)
print('Evidence archive MiB:',(doc/'radial_probe_evidence.tar.gz').stat().st_size/2**20)
print('WIEN supplement:',sup)
