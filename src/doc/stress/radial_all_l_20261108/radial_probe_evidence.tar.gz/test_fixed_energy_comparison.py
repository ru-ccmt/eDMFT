"""Compare native assemblies after eliminating different SELECT tolerances."""
from pathlib import Path
import shutil,os,subprocess
from scipy.io import FortranFile
r=Path(__file__).resolve().parent
ENV=os.environ.copy()
for k in list(ENV):
 if k.startswith(('DFTKS_','EDMFT_','WIEN_LAPW1_','WIEN_STRESS_')):del ENV[k]
ENV.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
for case,nat,cplx in [('SrVO3',4,True),('FeSe',2,False)]:
 src=r/'tests'/(case+'_all_l_restored')/'plus_1e-05';d=r/'tests'/(case+'_fixed_energies');d.mkdir(exist_ok=True)
 for p in src.iterdir():
  if p.is_file() and (p.suffix in {'.struct','.in1','.in1c','.vsp','.vns','.klist'} or p.name=='lapw1.def'):shutil.copy2(p,d/p.name)
 p=d/(case+'.klist');p.write_text('\n'.join(p.read_text().splitlines()[:3])+'\nEND\n')
 p=d/(case+('.in1c' if cplx else '.in1'));lines=p.read_text().splitlines();pos=2
 with FortranFile(src/(case+'.vector')) as f:
  for ia in range(nat):
   e=f.read_record('f8');elo=f.read_record('f8').reshape(4,-1,order='F');apw=e>150;e[apw]-=200
   head=lines[pos].split();nr=int(head[1]);lines[pos]=f'{e[-1]:.10f} {nr} {head[2]}';pos+=1;counts={}
   for j in range(nr):
    a=lines[pos].split();l=int(a[0]);n=counts.get(l,0);counts[l]=n+1
    val=e[l] if n==0 else elo[l,n-1+int(apw[l])]
    assert abs(val)<100
    lines[pos]=f' {l:1d}{val:10.5f}{0.:10.5f}{a[3]:4s}{int(a[4]):2d}';pos+=1
 p.write_text('\n'.join(lines)+'\n')
 env=ENV|{'WIEN_LAPW1_BASIS_VSP':str(d/'basis.vsp'),'WIEN_LAPW1_MATRIX_DUMP':str(d/'native')}
 exe=r/'wien/SRC_lapw1'/('lapw1c' if cplx else 'lapw1')
 with (d/'run.log').open('w') as out:rr=subprocess.run([str(exe),'lapw1.def'],cwd=d,env=env,stdout=out,stderr=subprocess.STDOUT)
 assert rr.returncode==0,(d/'run.log').read_text()
s=(r/'test_dftks_basis.py').read_text().replace("(case+'_dftks_basis')","(case+'_fixed_energy_dftks')").replace("r/'tests'/(case+'_all_l_restored')/'plus_1e-05'","r/'tests'/(case+'_fixed_energies')").replace('dftks_basis_results.json','fixed_energy_results.json')
exec(compile(s,'fixed_energy_worker_test','exec'))
