from pathlib import Path
import shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/haule/projects/eDMFT_new');dst=r/'src/dftKS'
shutil.copytree(repo/'src/dftKS',dst)
shutil.copy2(repo/'src/Makefile.in',r/'src/Makefile.in')
(r/'before_dftks').mkdir()
for f in ['modules.FPP','read_and_initialize.FPP','atpar.f90','hamilt.FPP']:shutil.copy2(dst/f,r/'before_dftks'/f)
p=dst/'modules.FPP';s=p.read_text();needle='module potnlc\n'
s=s.replace(needle,needle+'''  ! Optional alternate radial basis at a fixed physical KS operator.
  ! VR remains the potential used by the radial solver.  BASIS_DELTA_VR is
  ! r*(Vphysical-Vbasis) in Hartree.  Low-l/LO restoration uses the existing
  ! Gaunt path; high-l augmentation uses three spherical radial integrals.
  logical :: basis_potential_enabled=.false.
  integer :: basis_restore_lmin=0
  real*8, allocatable :: basis_delta_vr(:,:),basis_restore_spherical(:,:,:)
''',1);p.write_text(s)
p=dst/'read_and_initialize.FPP';s=p.read_text()
s=s.replace('  use potnlc, only  : VR','  use potnlc, only  : VR,basis_potential_enabled,basis_delta_vr, &\n       basis_restore_spherical,basis_restore_lmin',1)
s=s.replace('  use readPotential, ONLY: init_V_vsp, read_V_vsp,','  use readPotential, ONLY: close_V_vsp,init_V_vsp, read_V_vsp,',1)
s=s.replace('vector_para, myrank, master','vector_para, myrank, master,stop_MPI',1)
s=s.replace('  CHARACTER*67   :: ERRMSG','''  CHARACTER*67   :: ERRMSG
  character(len=180) :: basis_vsp_file
  integer :: basis_vsp_status
  logical :: basis_file_exists''',1)
needle='  call mpi_bcast_V_vsp(Vr, NRAD,NAT)'
s=s.replace(needle,needle+'''

  ! A response probe can change trial functions without changing the
  ! physical potential.  Keeping these separate is necessary for the
  ! stationary radial Pulay derivative.  Use with MATRICES_ONLY to avoid
  ! solving a second eigenproblem.  Ordinary runs take no extra radial work.
  basis_vsp_file=''
  call get_environment_variable('DFTKS_BASIS_VSP',basis_vsp_file,status=basis_vsp_status)
  if (basis_vsp_status.eq.-1) then
     if (Qprint) write(6,*) 'DFTKS_BASIS_VSP exceeds 180 characters'
     call stop_MPI()
     stop 1
  endif
  basis_potential_enabled=(basis_vsp_status.eq.0.and.len_trim(basis_vsp_file).gt.0)
  if (basis_potential_enabled) then
     inquire(file=trim(basis_vsp_file),exist=basis_file_exists)
     if (.not.basis_file_exists.or.NOHNS) then
        if (Qprint) write(6,*) 'Alternate radial basis requires a readable VSP and HNS enabled'
        call stop_MPI()
        stop 1
     endif
     allocate(basis_delta_vr(NRAD,NAT),basis_restore_spherical(3,NT,NAT))
     basis_delta_vr=VR
     basis_restore_spherical=0.d0
     basis_restore_lmin=LNSMAX+1
     if (myrank.eq.master) then
        call close_V_vsp()
        call init_V_vsp(basis_vsp_file,18,ISCF)
        VR=0.d0
        do jatom=1,nat
           call read_V_vsp(VR(:jri(jatom),jatom),jatom,jri(jatom))
        enddo
        VR=VR/2.d0
        call close_V_vsp()
        write(6,'(A,1X,A)') ':DFTKS_BASIS_VSP:',trim(basis_vsp_file)
        write(6,'(A)') ':DFTKS_BASIS_OPERATOR: restoring physical potential in all angular channels'
     endif
     call mpi_bcast_V_vsp(VR,NRAD,NAT)
     basis_delta_vr=basis_delta_vr-VR
  endif
''',1)
needle='  ! Compute how many localized orbitals appear before each atom nlov(jatom)'
s=s.replace(needle,'''  if (basis_potential_enabled) then
     do jatom=1,nat
        do l=LNSMAX+1,LOMAX
           if (ilo(l,jatom).gt.0) then
              if (Qprint) write(6,*) 'Alternate-basis probe needs LNSMAX to include every LO'
              call stop_MPI()
              stop 1
           endif
        enddo
     enddo
  endif

'''+needle,1);p.write_text(s)
p=dst/'atpar.f90';s=p.read_text().replace('  use potnlc, only: VR','  use potnlc, only: VR,basis_potential_enabled,basis_delta_vr,basis_restore_spherical',1)
needle='        ! stores radial functions into A1, B1, AE1, BE1'
s=s.replace(needle,'''        if (basis_potential_enabled.and.l.gt.LNSMAX) then
           ! All-l restoration: never truncate a spherical operator at the
           ! nonspherical orbital cutoff.  This uses precisely the radial
           ! normalization and RELA metric used in the low-l Gaunt path.
           ! The factor 2 converts Hartree to Ry; the potential file stores r*V.
           AW(1:JRI_)=A(1:JRI_)*2.d0*basis_delta_vr(1:JRI_,jatom)/RNET(1:JRI_)
           BW(1:JRI_)=B(1:JRI_)*2.d0*basis_delta_vr(1:JRI_,jatom)/RNET(1:JRI_)
           AEW(1:JRI_)=AE(1:JRI_)*2.d0*basis_delta_vr(1:JRI_,jatom)/RNET(1:JRI_)
           BEW(1:JRI_)=BE(1:JRI_)*2.d0*basis_delta_vr(1:JRI_,jatom)/RNET(1:JRI_)
           basis_restore_spherical(1,l+1,jatom)=RINT13(REL,AW,BW,A,B,NRAD,DX_,JRI_,R0_)
           basis_restore_spherical(2,l+1,jatom)=RINT13(REL,AEW,BEW,AE,BE,NRAD,DX_,JRI_,R0_)
           basis_restore_spherical(3,l+1,jatom)=RINT13(REL,AW,BW,AE,BE,NRAD,DX_,JRI_,R0_)
        endif
'''+needle,1)
needle='     !        calculate possible nonspherical contributions to H'
s=s.replace(needle,'''     if (basis_potential_enabled) then
        ! Reuse the fully coupled low-l and local-orbital machinery for L=0.
        ! DeltaV_00=sqrt(4*pi)*(Vphysical-Vbasis); HNS supplies the Gaunt
        ! coefficient.  The high-l Legendre path does NOT use this Y00 factor.
        if (lm_stored.ge.lmmx) then
           if (Qprint) write(6,*) 'No free potential harmonic for alternate-basis restoration'
           call stop_MPI()
           stop 1
        endif
        lm_stored=lm_stored+1
        lmmax(jatom)=max(lmmax(jatom),lm_stored)
        LM(:,lm_stored,jatom)=0
        VLM(:,lm_stored)=0.d0
        VLM(1:JRI_,lm_stored)=2.d0*sqrt(4.d0*acos(-1.d0))*basis_delta_vr(1:JRI_,jatom)/RNET(1:JRI_)
     endif
'''+needle,1);p.write_text(s)
p=dst/'hamilt.FPP';s=p.read_text().replace('  use mpi, ONLY: Qprint','''  use mpi, ONLY: Qprint
  use potnlc, only: basis_potential_enabled,basis_restore_spherical,basis_restore_lmin''',1)
needle='''              endif
           enddo
\t   !\t   !$OMP PARALLEL DO PRIVATE(phs)'''
assert needle in s
s=s.replace(needle,'''              endif
              if (basis_potential_enabled.and.l.ge.basis_restore_lmin) then
                 ! Spherical DeltaV is diagonal in (l,m).  The angular sum
                 ! gives (2*l+1)*P_l.  VIFPR4 and the atom phases are applied
                 ! below exactly as for the ordinary spherical Hamiltonian.
                 ! Both u-udot orientations are needed for a Hermitian form.
                 do j=1,i_g
                    tmp3=(2*l+1)*Pl(j,l,ihelp)
                    tmp1(j)=tmp1(j)+tmp3*( &
                         basis_restore_spherical(1,l+1,jatom)*Al_c(ihelp,l)*Al_r(j,l) &
                        +basis_restore_spherical(2,l+1,jatom)*Bl_c(ihelp,l)*Bl_r(j,l) &
                        +basis_restore_spherical(3,l+1,jatom)*( &
                             Al_c(ihelp,l)*Bl_r(j,l)+Bl_c(ihelp,l)*Al_r(j,l)))
                 enddo
              endif
           enddo
\t   !\t   !$OMP PARALLEL DO PRIVATE(phs)''',1);p.write_text(s)
print('Prepared dftKS alternate-basis worker')
