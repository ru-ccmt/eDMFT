from pathlib import Path
import json,hashlib,zipfile
r=Path(__file__).parent
f=json.loads((r/'FeSe/results.json').read_text());m=json.loads((r/'MnO/results.json').read_text())
a=json.loads((r/'SrVO3_affine/results.json').read_text());c=json.loads((r/'SrVO3_rigid_core/results.json').read_text())
report=r'''CROSS-MATERIAL POTENTIAL-OPERATOR TEST AND ONE-LAPW0 DENSITY ESTIMATES
7 November 2026

Scope and authorization
=======================
No production source or executable was changed. All new runs are isolated
under /private/tmp/projector_cross_material_20261107. Original material
inputs and calculation outputs were not rewritten. Tests use existing
converged endpoint potentials; there was no new impurity or charge SCF run.
The user explicitly asked to test FeSe/MnO and whether one LAPW0 evaluation
on a simple strained density can estimate the missing potential derivative.

Measured cross-material comparison
==================================
All numbers below are mean tensile-sign stress in GPa, trace(sigma)/3.
They are already divided by three. Compressive pressure has opposite sign.
The new term is postprocessed, not installed.

Material   Analytic     Added term   Postprocessed   Numerical    New error
SrVO3       5.676884     -2.986759       2.690125       2.933836    -0.243711
FeSe       -0.116492     -1.002215      -1.118707      -1.049151    -0.069556
MnO       -15.517872     +1.059566     -14.458306     -72.346468*  +57.888161*

SrVO3 is the previous half-step result. FeSe and MnO use fresh installed
dmft2 runs with central WIEN LAPW1 eigenvectors and the existing density/core
stress outputs. Their numerical derivatives use the actual lattice step:
FeSe 0.000999955013768, MnO 0.00100001333510. At nominal step 0.001 the
numerical means are -1.04910410 and -72.34743230 GPa, respectively.
FeSe's central standalone original scf2 is partial after the interrupted
cycle. It was not used as a functional reference; the complete endpoint
functional values were loaded directly and a fresh isolated central pass
supplies the analytic tensor.

The earlier dftKS-based FeSe central replay was -0.11317019 GPa; the present
same-state WIEN replay differs by -0.00332148 GPa. Applying the measured
term to that earlier baseline instead would give -1.11538566 GPa. This
small replay dependence does not change the conclusion.

* MnO IS NOT a controlled confirmation or refutation of this correction.
Its [6,16] window cuts an exact degeneracy. Both response branches skip
nine singular inside/outside pairs, across eight k points. A selected
spectral subspace is not uniquely specified by these indices there.
Endpoint valence charges also differ (20.992718 and 21.008041) with fixed
chemical potential; the ensemble/reference bookkeeping needs to remain
explicit. Fixed mu itself is not forbidden and was not changed. The new
term does not explain the large reported MnO discrepancy.
A fresh dftKS control gives analytic -15.51710837 GPa, within 0.000764 GPa
of the current WIEN result. The change from the old -16.15658 GPa row is
therefore not primarily the choice of LAPW1 executable. Do not compare old
and new central implementations as if they were the same run.

Potential contribution decomposition
===================================
These include both the fixed-normalization window response R and the
normalization response R^N. No extra k/spin factors are applied to dumps.

Contribution                         SrVO3       FeSe          MnO*
MT potential change at fixed r      +0.618041   +0.135504    -0.267367
MT coordinate term r*dV/dr          -3.516179   -1.228627    +1.172813
MT subtotal                         -2.898138   -1.093123    +0.905446
Interstitial material derivative    -0.088621   +0.090907    +0.154119
TOTAL                               -2.986759   -1.002215    +1.059566

MT-only is an approximation: the omitted interstitial term is about 0.09 GPa
in both clean examples. An MT-supported local orbital does not eliminate
whole-cell potential matrix elements driving the spectral window response.
Nor may interstitial CHARGE be discarded when computing the MT potential:
its Coulomb field penetrates the spheres. Spherical-only MT potential is
another approximation, not established by these tests; all stored MT
harmonics were retained.

Additional evidence and limits
==============================
FeSe: RELA, RKMAX8, 140 irreducible k points, 66 stored bands, W=[21,44].
Minimum window/complement separation 0.004882997604 Ry, no skipped pairs.
Central dual-basis metric error <9.4e-13; central projected Hamiltonian
error <5.4e-12 Ry; radial-energy headers identical in all fixed-basis probes.
Independent spectral-projector endpoint derivatives in the extracted
potential direction give -0.108113430957 Ry at h=1e-5 and
-0.108113419491 Ry at h=5e-6, compared with direct response contraction
-0.108113415698 Ry. This is a projector chain-rule check with central
functional gradients, not a new fully relaxed Klein finite difference.

MnO: RELA, RKMAX7, 72 irreducible k points, 23 stored bands, W=[6,16].
Central metric error <2.1e-13; central H reconstruction <1.3e-12 Ry.
The zero window gap is retained as a failure of the smooth-window criterion.

Independent Fourier reconstruction reproduces central warped VNS coefficients
within 3.2e-14 Ry in FeSe and 4.2e-14 Ry in MnO. The nonsymmorphic FeSe
symmetry requires the correct transpose and translation phases; omitting
that transpose gives a large 0.1705 Ry reconstruction error and is rejected.
FCC MnO requires the primitive-cell volume while using the conventional
integer reciprocal labels, as in LAPW0's REAN0/SETFFT routines.

The same frozen-radial representation and stored-band complement limitation
as the preceding SrVO3 test apply. The complete central eigensystem is used
only to reconstruct an exact dual basis for potential matrix extraction;
it does not enlarge the DMFT response complement beyond the saved bands.
Only isotropic stress has been tested, not the full anisotropic tensor.

One additional LAPW0: what it can compute
=========================================
Yes: given a trial strained density, ONE extra LAPW0 call computes its new
ionic, Hartree, and XC potential. The central potential already exists.
No LAPW1, dmft2, mixer, impurity solve, or charge convergence is logically
needed just to produce that trial potential. Our extra LAPW1 runs are
measurement tools for central band matrix elements, not a requirement of
the proposed production algorithm once direct potential integrals exist.

For F=(1+eta)I=lambda I, J=det(F)=lambda^3, an affine-density ansatz is

 n_eta(F r) = n_0(r)/J,
 n_eta^a(r) = lambda^-3 n_0^a(r/lambda) in atom-centered physical radius,
 (partial_eta n_eta^a)_r = -3 n_0^a-r partial_r n_0^a.

This is a model for the response, not a consequence of stationarity or a
solution of the screened electronic response equation.

Inside WIEN's CLMSUM file the radial channel stores c_lm proportional to
r^2 n_lm, with the extra constant normalization for l=m=0. Therefore

 c_lm,eta(r) = lambda^-1 c_lm,0(r/lambda).

The factor is lambda^-1, NOT lambda^-3, for that stored radial quantity.
Cubic interpolation in log(r) was used. The interstitial density Fourier
star coefficients are scaled by lambda^-3; the integer G labels are held
fixed as the reciprocal cell changes. All lattice lengths and atomic
centers are strained; physical RMT values remain fixed. The total density,
not only its spherical MT part, is passed to LAPW0.

A more physical first guess keeps tightly bound core charge atom-centered:

 n_eta^a(r) = n_core,0^a(r)
              +lambda^-3 n_val,0^a(r/lambda).

CORE and CLMSUM spherical radial channels use compatible 4*pi*r^2 density
normalization in these files, so the core can be subtracted and restored
before/after transport. A general implementation should handle any core
leakage into the interstitial consistently; its boundary density is small
here, and the resulting total-charge check is explicitly retained below.

After running LAPW0 on the guessed density in the strained structure,

 (partial_eta V_MT)_r ~= [V_MT,eta(r)-V_MT,0(r)]/eta,
 Vop_MT ~= (partial_eta V_MT)_r + r partial_r V_MT,0,
 Vop_I  ~= [V_eta(F r)-V_0(r)]/eta in the central interstitial.

For the last expression use the unwarped potential output (R2V), or remove
the moving interstitial-step contribution from VNS. Do not add a second
coordinate derivative if the potential has already been pulled back to
material coordinates. Form its off-diagonal matrix elements on the central
KS states and contract with R+R^N.

Measured accuracy of these cheap guesses in SrVO3
================================================
Central numerical benchmark: 2.93383641 GPa. Current analytic: 5.67688415.
At positive eta=0.000249988706:

Density used for LAPW0           Correction    Analytic+correction   Error
Actual relaxed endpoint slope   -2.986759          2.690125        -0.243711
Affine total charge             -1.731936          3.944948        +1.011111
Rigid core + affine valence      -1.775550          3.901334        +0.967498

These guesses improve the starting result but are inadequate for the
sub-0.1 GPa target. Their limiting error is the assumed density response,
not the finite-difference step or a missing volume normalization.

Affine total-charge corrections at positive eta approximately
0.001, 0.0005, 0.00025: -1.73111044, -1.73165935, -1.73193647 GPa.
Forward-step extrapolation indicates about -1.73221 GPa. Rigid-core values
at 0.0005 and 0.00025: -1.77544365 and -1.77554986 GPa, extrapolating to
about -1.77566 GPa. Neither extrapolation approaches -2.98676 GPa.

Independent integrated density check, 85 electrons total:
  central                        84.9999997381
  affine eta~0.001               84.9999982673
  affine eta~0.0005              84.9999993267
  affine eta~0.00025             84.9999996131
  rigid-core eta~0.0005          84.9999996950
  rigid-core eta~0.00025         84.9999997969

This check integrates MT radial charge and analytic interstitial sphere
form factors, with the Fourier star-size convention included. Small finite
representation/interface errors decrease with the step. The affine guess
is exactly charge-conserving in the continuum; the stored LAPW expansion
requires the checks above rather than assuming exact conservation.

Each trial LAPW0 call took roughly 0.75-0.78 seconds on this machine.
Additional fixed-basis LAPW1 probes used to measure matrix elements took
about 15 seconds. Central dmft2 response runs took 224 seconds in FeSe
and 26 seconds in MnO with MPI4; the response is reused in postprocessing.

How to improve the approximation without an impurity solve
=========================================================
LAPW0 faithfully evaluates V_KS[n_trial], but cannot infer how the electrons
relax. For a more accurate derivative one needs a better density direction:
  - frozen-Sigma charge linear response using central Green functions and
    the same moving window/normalization;
  - or a small number of frozen-Sigma charge updates on the trial structure,
    checking convergence of the contracted correction rather than assuming
    that one update is sufficient.
The familiar equation schematically reads

 delta n = b_eta + chi_frozenSigma delta V_Hxc,
 delta V_Hxc = f_Hxc delta n,
 (1-chi_frozenSigma f_Hxc) delta n = b_eta.

The geometric ionic/Coulomb/Jacobian source must be included consistently.
There is no general reason the affine density should solve this equation.
A full new impurity solution is not required for the agreed frozen-Sigma
tangent-functional validation, but a fully self-consistent DMFT response
problem is a different calculation.

Implementation conclusion
=========================
SrVO3 and FeSe support the missing potential-operator contraction derived
from the normalized finite-window projector. MnO does not validate it yet
and its large apparent discrepancy is unexplained. The formula should be
judged from the chain rule and controlled tests, not fitted to a pressure.
A default-off production diagnostic is a reasonable next implementation
step, with source-change permission requested first. Replacing its physical
potential response by a uniform-density guess is not accurate enough based
on the SrVO3 measurements above. No approximation or correction was enabled
by default during these tests.
'''
(r/'REPORT.txt').write_text(report)
with zipfile.ZipFile(r/'diagnostics_and_inputs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in r.glob('*.py'):z.write(p,'scripts/'+p.name)
 for case in ['FeSe','MnO']:
  for name in ['center','minus','plus','r2v_center','r2v_minus','r2v_plus']:
   for p in (r/case/name).iterdir():
    if p.is_file() and (p.suffix in ['.struct','.in0','.in1','.in2','.indmfl','.indmf2','.vsp','.vns','.vtotal','.klist'] or p.name=='EF.dat'):z.write(p,str(p.relative_to(r)))
 for name in ['SrVO3_affine','SrVO3_rigid_core']:
  for d in (r/name).iterdir():
   if not d.is_dir() or d.name.endswith('_basis'):continue
   for p in d.iterdir():
    if p.suffix in ['.struct','.clmsum','.in0','.vsp','.vns','.vtotal','.json']:z.write(p,str(p.relative_to(r)))
print(r/'REPORT.txt')
