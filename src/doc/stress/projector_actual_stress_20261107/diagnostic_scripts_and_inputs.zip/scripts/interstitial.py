import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import sys,json
sys.dont_write_bytecode=True
sys.path.insert(0,'/Users/haule/projects/eDMFT_new/src/python')
from pathlib import Path
import numpy as np
from scipy.special import spherical_jn
from check_projector_sternheimer_fd import read_dump
from check_interstitial_overlap_stress import read_atoms
from wstruct import Struct
root=Path(__file__).parent;c=Path('/private/tmp/projector_stationarity_probe_20261107/SrVO3')
s=Struct();s.ReadStruct(str(c/'SrVO3.struct'))
assert np.max(abs(s.tau))==0
atoms=read_atoms(c/'SrVO3.struct');a=7.260328;vol=a**3
N=60
xyz=np.array(np.meshgrid(*[np.fft.fftfreq(N)*N]*3,indexing='ij'))
qnorm=np.sqrt(np.sum(xyz**2,axis=0))*2*np.pi/a

def read_stars(path):
 a=path.read_text().splitlines();i=next(i for i,x in enumerate(a) if 'TOTAL POTENTIAL IN INTERSTITIAL' in x)
 i+=2;n=int(a[i].split()[0]);out=np.zeros((N,N,N),complex);mask=np.zeros(out.shape,bool)
 for line in a[i+1:i+1+n]:
  g=np.array([int(line[j:j+5]) for j in [3,8,13]])
  z=float(line[18:37])+1j*float(line[37:56])
  star={tuple((rot@g)%N) for rot in s.timat}
  if path.suffix=='.vtotal':z/=len(star)
  for gg in star:out[gg]=z;mask[gg]=True
 return out,mask

def theta(h):
 t=np.zeros((N,N,N),complex)
 for atom in atoms:
  v=4*np.pi*atom.rmt**3/3/(vol*(1+h)**3)
  x=qnorm*atom.rmt/(1+h)
  radial=np.ones_like(x);np.divide(3*spherical_jn(1,x),x,out=radial,where=x!=0)
  for pos in atom.positions:t-=v*radial*np.exp(-2j*np.pi*np.einsum('a,aijk->ijk',pos,xyz))
 t[0,0,0]+=1
 return t

def product(a,b):return np.fft.fftn(np.fft.ifftn(a).real*np.fft.ifftn(b).real)*N**3
v,mask=read_stars(root/'r2v_center'/'SrVO3.vtotal');warped,_=read_stars(root/'r2v_center'/'SrVO3.vns')
th=theta(0)
checks={}
for cv in [False,True]:
 for ct in [False,True]:
  z=product(v.conj() if cv else v,th.conj() if ct else th)
  err=float(np.max(abs((z-warped)[mask])))
  checks[str((cv,ct))]=err
print('RECONSTRUCT',checks,flush=True)
# Stored vector and VNS convention: minus sign in theta, conjugate of VTOTAL.
pred=product(v,th)
print('samples',v[0,0,0],warped[0,0,0],pred[0,0,0],flush=True)
dth=(theta(1e-5)-theta(-1e-5))/(2e-5)
boundary=product(v,dth);boundary[~mask]=0
operators={'boundary':boundary}
for prefix,h in [('',.001),('half_',.00049997741149)]:
 vp,_=read_stars(root/('r2v_'+prefix+'plus')/'SrVO3.vtotal');vm,_=read_stars(root/('r2v_'+prefix+'minus')/'SrVO3.vtotal')
 wp,_=read_stars(root/(prefix+'plus')/'SrVO3.vns');wm,_=read_stars(root/(prefix+'minus')/'SrVO3.vns')
 true=product((vp-vm)/(2*h),th);true[~mask]=0
 operators[prefix+'true']=true;operators[prefix+'raw']=((wp-wm)/(2*h)).conj()
evidence=np.load(c.parent/'band_matrix_evidence.npz')
outputs={name:[] for name in operators}
for k in range(1,76):
 d=read_dump(c/f'dmft_sternheimer.k{k:08d}.bin');npw=d.nbasis-d.nlo
 labels=d.labels[:,:npw];diff=(labels[:,:,None]-labels[:,None,:])%N
 A=d.coefficients[:npw,:,0]
 for name,operator in operators.items():
  mat=operator[tuple(diff)];assert np.max(abs(mat-mat.conj().T))<1e-8
  outputs[name].append(A.conj().T@mat@A)
results={}
for name,value in outputs.items():
 value=np.array(value);np.save(root/('interstitial_'+name+'.npy'),value)
 results[name]={key:float(np.einsum('kij,kji->',evidence[key],value).real) for key in ['response','norm_response']}
 results[name]['total_GPa']=sum(results[name].values())*14710.507641078/(3*382.70904)
print(json.dumps(results,indent=2),flush=True)
(root/'interstitial_results.json').write_text(json.dumps({'reconstruction':checks,'contractions':results},indent=2))
