from pathlib import Path
r=Path(__file__).parent
ns={'__file__':str(r/'analyze.py')};exec((r/'analyze.py').read_text().split("names=['center'")[0],ns)
np=ns['np'];read_dump=ns['read_dump'];vectors=ns['vectors']
from scipy.linalg import solve
import sys,json
from check_projector_sternheimer_fd import read_normalization,read_response_matrix
full=vectors(r/'complete_center'/'SrVO3.vector_x');gauges=np.load(r/'dftks_wien_gauge.npy');potential=np.load(r/'half_material_potential_derivative.npy')
c=r/'wien_response';totals={'fixed_X':0.,'normalization':0.};max_metric=0.;delta_R=0.
old=np.load('/private/tmp/projector_stationarity_probe_20261107/band_matrix_evidence.npz')
for k in range(1,76):
 d=read_dump(c/f'dmft_sternheimer.k{k:08d}.bin');n=read_normalization(c/f'dmft_sternheimer_norm.k{k:08d}.bin')
 rr=read_response_matrix(c/f'stress_response.k{k:08d}.bin').density
 rn=np.zeros_like(rr);W=np.arange(11,31);outside=np.r_[0:11,31:43]
 for j,iw in enumerate(W):
  val=np.einsum('aij,ij->a',n.projector[outside],n.gradient[j])/(d.energies[iw]-d.energies[outside])
  rn[outside,iw]=val;rn[iw,outside]=val.conj()
 e,v,l,rad=next(full);assert np.array_equal(l,d.labels)
 t=solve(v,d.coefficients[:,:,0],check_finite=False)[:43]
 max_metric=max(max_metric,float(np.max(abs(t.conj().T@t-np.eye(43)))))
 q=gauges[k-1]@t;V=q.conj().T@potential[k-1]@q
 totals['fixed_X']+=float(np.trace(rr@V).real);totals['normalization']+=float(np.trace(rn@V).real)
 delta_R=max(delta_R,float(np.max(abs(q@(rr+rn)@q.conj().T-old['response'][k-1]-old['norm_response'][k-1]))))
totals['total_Ry']=totals['fixed_X']+totals['normalization'];totals['total_GPa']=totals['total_Ry']*14710.507641078/(3*382.70904)
result={'contraction':totals,'central_subspace_metric_error':max_metric,'max_response_difference':delta_R}
print(json.dumps(result,indent=2));(r/'wien_control.json').write_text(json.dumps(result,indent=2))
