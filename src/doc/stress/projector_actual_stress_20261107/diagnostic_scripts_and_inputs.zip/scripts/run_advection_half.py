from pathlib import Path
import re,os,shutil,subprocess,time,concurrent.futures,json
import numpy as np
from scipy.interpolate import CubicSpline
r=Path(__file__).parent;c=Path('/private/tmp/projector_stationarity_probe_20261107/SrVO3')
struct=(c/'SrVO3.struct').read_text().splitlines();rad=[]
for s in struct:
 m=re.search(r'NPT=\s*(\d+)\s+R0=\s*([\d.]+)\s+RMT=\s*([\d.]+)',s)
 if m:rad.append(np.linspace(np.log(float(m[2])),np.log(float(m[3])),int(m[1])))
pat=re.compile(r'[-+]?\d+\.\d+E[-+]\d+')
def change(text,h,spherical):
 a=text.splitlines();atom=-1;i=0
 while i<len(a):
  if 'ATOMNUMBER' in a[i]:atom=int(a[i].split('=')[1])-1
  if 'VLM(R) FOR L' not in a[i]:i+=1;continue
  i+=1
  while not a[i].strip():i+=1
  start=i;values=[]
  while len(values)<len(rad[atom]):
   values.extend(map(float,pat.findall(a[i])));i+=1
  assert len(values)==len(rad[atom]);v=np.array(values)
  derivative=CubicSpline(rad[atom],v)(rad[atom],1)
  if spherical:derivative-=v
  out=v+h*derivative
  lines=['   '+''.join(f'{x:19.12E}' for x in out[j:j+4]) for j in range(0,len(out),4)]
  assert len(lines)==i-start
  a[start:i]=lines
 return '\n'.join(a)+'\n'
env=os.environ|{'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','WIEN_LAPW1_BASIS_VSP':str(c/'SrVO3.vsp')}
def run(sign):
 name='advection_half_'+('plus' if sign==1 else 'minus');d=r/name;d.mkdir(exist_ok=True)
 for f in ['SrVO3.struct','SrVO3.in1c','SrVO3.klist','SrVO3.kgen','SrVO3.rotlm','SrVO3.vsp','SrVO3.vns','lapw1.def']:shutil.copy2(c/f,d/f)
 for suf,spherical in [('vsp',True),('vns',False)]:
  p=d/('SrVO3.'+suf);p.write_text(change(p.read_text(),sign*1.5e-5,spherical))
 t=time.monotonic()
 with (d/'run.log').open('w') as f:res=subprocess.run(['/Users/haule/wien2k_24/lapw1c','lapw1.def'],cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,res.returncode,time.monotonic()-t,flush=True);assert res.returncode==0
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(run,[-1,1]))
