from pathlib import Path
import os,shutil,subprocess,time,json,concurrent.futures
root=Path(__file__).parent
central=Path('/private/tmp/projector_stationarity_probe_20261107/SrVO3')
endpoint=Path('/private/tmp/numeric_stress_audit_20261107')
env=os.environ|{'WIENROOT':'/Users/haule/wien2k_24','WIEN_DMFT_ROOT':'/Users/haule/dbin','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
for k in list(env):
 if k.startswith(('EDMFT_','WIEN_STRESS_','DFTKS_','WIEN_LAPW1_')):del env[k]
files=['SrVO3.'+x for x in ['struct','in1c','klist','kgen','rotlm','vsp','vns']]+['lapw1.def']
for name in ['dftks','center','minus','plus','half_minus','half_plus']:
 d=root/name;d.mkdir(exist_ok=True)
 for f in files:shutil.copy2(central/f,d/f)
 if name not in ['dftks','center']:
  for suf in ['vsp','vns']:shutil.copy2(endpoint/name/('SrVO3.'+suf),d/('SrVO3.'+suf))

def run(name):
 d=root/name;e=env.copy()
 if name=='dftks':
  cmd=['/opt/homebrew/bin/mpirun','-n','4','/Users/haule/dbin/lapw1c','lapw1.def'];e['DFTKS_OVERLAP_DUMP']=str(d/'lapw_overlap')
 else:
  e['WIEN_LAPW1_BASIS_VSP']=str(central/'SrVO3.vsp')
  cmd=['/Users/haule/wien2k_24/lapw1c','lapw1.def']
 t=time.monotonic();print('START',name,flush=True)
 with (d/'run.log').open('w') as f:r=subprocess.run(cmd,cwd=d,env=e,stdout=f,stderr=subprocess.STDOUT)
 a={'rc':r.returncode,'seconds':time.monotonic()-t};print('END',name,a,flush=True)
 assert r.returncode==0,(name,a)
 return name,a
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:results=dict(p.map(run,['dftks','center','minus','plus','half_minus','half_plus']))
(root/'run_results.json').write_text(json.dumps(results,indent=2))
