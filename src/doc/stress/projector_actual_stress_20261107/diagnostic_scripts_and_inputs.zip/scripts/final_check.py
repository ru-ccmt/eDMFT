import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
from pathlib import Path
import numpy as np,json,time
r=Path(__file__).parent
old=Path('/private/tmp/projector_full_functional_probe_20261107/full_functional.py')
ns={'__file__':str(old)};exec(old.read_text().split("if (root/'central_density.npy').exists():")[0],ns)
evidence=ns['d'];res={};R=evidence['response']+evidence['norm_response'];fac=14710.507641078/(3*382.70904)
for prefix in ['', 'half_']:
 raw=np.load(r/(prefix+'potential_derivative.npy'))
 adv=np.load(r/'advection_half_potential_derivative.npy')
 iraw=np.load(r/('interstitial_'+prefix+'raw.npy'))
 itrue=np.load(r/('interstitial_'+prefix+'true.npy'))
 dv=raw+adv-iraw+itrue
 vals={key:float(np.einsum('kij,kji->',evidence[key],dv).real) for key in ['response','norm_response']}
 vals['total_Ry']=vals['response']+vals['norm_response'];vals['GPa']=vals['total_Ry']*fac;vals['analytic_plus_correction_GPa']=5.67688415+vals['GPa']
 vals['numerical_GPa']=2.933836407 if prefix else 2.933285422
 vals['remaining_analytic_minus_numerical_GPa']=vals['analytic_plus_correction_GPa']-vals['numerical_GPa']
 res[prefix or 'full']=vals
 np.save(r/(prefix+'material_potential_derivative.npy'),dv)
print('CORRECTION',json.dumps(res,indent=2),flush=True)
fsp=ns['fsp'];embedding=ns['embedding'];fd=[]
for h in [1e-5,5e-6]:
 start=time.monotonic();slope={}
 for mode in ['fixed','moving']:
  vp=fsp(*embedding(h,mode,operator=dv)).sum();vm=fsp(*embedding(-h,mode,operator=dv)).sum()
  slope[mode]=float((vp-vm)/(2*h))
 extra=slope['moving']-slope['fixed'];row={'h':h,'slopes_Ry':slope,'extra_Ry':extra,'extra_GPa':extra*fac,'analytic_Ry':res['half_']['total_Ry'],'difference_Ry':extra-res['half_']['total_Ry'],'seconds':time.monotonic()-start}
 fd.append(row);print('FUNCTIONAL',row,flush=True)
(r/'final_results.json').write_text(json.dumps({'stress':res,'functional_checks':fd},indent=2))
