import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import sys,json,struct,time
sys.dont_write_bytecode=True
sys.path.insert(0,'/Users/haule/projects/eDMFT_new/src/python')
from pathlib import Path
import numpy as np
from scipy.io import FortranFile,FortranEOFError
from check_sigma_overlap_fd import read_overlap
from check_projector_sternheimer_fd import read_dump
root=Path(__file__).parent
central=Path('/private/tmp/projector_stationarity_probe_20261107/SrVO3')
evidence=np.load(central.parent/'band_matrix_evidence.npz')

def vectors(path):
 f=FortranFile(path)
 radial=[f.read_record('f8') for j in range(8)]
 while True:
  try:b=f.read_record('u1').tobytes()
  except FortranEOFError:break
  kx,ky,kz,name,n,nb,w=struct.unpack('<ddd10siid',b)
  labels=f.read_record('i4').reshape(3,n,order='F')
  e=[];v=[]
  for j in range(nb):
   index,ej=struct.unpack('<id',f.read_record('u1').tobytes());e.append(ej);v.append(f.read_record('c16'))
  yield np.array(e),np.array(v).T,labels,radial

def perm(reference,labels,npw):
 lookup={tuple(labels[:,i]):i for i in range(npw)}
 assert len(lookup)==npw
 return np.array([lookup[tuple(reference[:,i])] for i in range(npw)]+list(range(npw,labels.shape[1])))

names=['center','minus','plus','half_minus','half_plus']
iters={n:vectors(root/n/'SrVO3.vector_x') for n in names}
checks={key:0. for key in ['central_orthonormality','wien_orthonormality','central_energy_difference','central_projected_H_difference','radial_header_difference']}
projected={n:[] for n in names};totals={}
for k in range(1,76):
 d=read_dump(central/f'dmft_sternheimer.k{k:08d}.bin')
 o=read_overlap(root/'dftks'/f'lapw_overlap.k{k:08d}.bin')
 ids=perm(d.labels,o.labels,d.nbasis-d.nlo);O=o.overlap[np.ix_(ids,ids)]
 C=d.coefficients[:,:,0]
 checks['central_orthonormality']=max(checks['central_orthonormality'],float(np.max(np.abs(C.conj().T@O@C-np.eye(43)))))
 for name in names:
  e,v,l,rad=next(iters[name]);ids=perm(d.labels,l,d.nbasis-d.nlo);v=v[ids]
  checks['wien_orthonormality']=max(checks['wien_orthonormality'],float(np.max(np.abs(v.conj().T@O@v-np.eye(43)))))
  t=C.conj().T@O@v
  H=(t*e)@t.conj().T
  projected[name].append(H)
  if name=='center':
   rad0=rad
   checks['central_energy_difference']=max(checks['central_energy_difference'],float(np.max(np.abs(e-d.energies))))
   checks['central_projected_H_difference']=max(checks['central_projected_H_difference'],float(np.max(np.abs(H-np.diag(d.energies)))))
  else:checks['radial_header_difference']=max(checks['radial_header_difference'],max(float(np.max(np.abs(x-y))) for x,y in zip(rad,rad0)))
 if k%15==0:print('k',k,checks,flush=True)
for name in names:projected[name]=np.array(projected[name])
for prefix,h in [('',.001),('half_',.00049997741149)]:
 dv=(projected[prefix+'plus']-projected[prefix+'minus'])/(2*h)
 vals={name:float(np.einsum('kij,kji->',evidence[key],dv).real) for name,key in [('fixed_X','response'),('normalization','norm_response')]}
 vals['total']=vals['fixed_X']+vals['normalization']
 vals['GPa']=vals['total']*14710.507641078/(3*382.70904)
 totals[prefix or 'full']=vals
 print(prefix,vals,flush=True)
 np.save(root/(prefix+'potential_derivative.npy'),dv)
(root/'results.json').write_text(json.dumps({'checks':checks,'totals':totals},indent=2))
np.savez_compressed(root/'projected_hamiltonians.npz',**projected)
