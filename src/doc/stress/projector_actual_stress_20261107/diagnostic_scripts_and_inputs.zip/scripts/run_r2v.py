from pathlib import Path
import shutil,subprocess,os,time,concurrent.futures,json
r=Path(__file__).parent;src=Path('/private/tmp/numeric_stress_audit_20261107');c=Path('/private/tmp/projector_stationarity_probe_20261107/SrVO3')
env=os.environ|{'WIENROOT':'/Users/haule/wien2k_24','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1'}
def run(name):
 s=c if name=='center' else src/name;d=r/('r2v_'+name);d.mkdir(exist_ok=True)
 for suf in ['struct','clmsum','clmcor','in0','inm','inc']:
  p=s/('SrVO3.'+suf)
  if p.exists():shutil.copy2(p,d/p.name)
 p=d/'SrVO3.in0';a=p.read_text().splitlines();a[0]='TOT '+a[0][4:];a[1]=a[1].replace('NR2V','R2V ');p.write_text('\n'.join(a)+'\n')
 start=time.monotonic()
 with (d/'run.log').open('w') as f:rr=subprocess.run(['/Users/haule/wien2k_24/x','lapw0','-f','SrVO3'],cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,rr.returncode,time.monotonic()-start,flush=True);assert rr.returncode==0
 return name,time.monotonic()-start
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:out=dict(p.map(run,['center','minus','plus','half_minus','half_plus']))
(r/'r2v_timing.json').write_text(json.dumps(out,indent=2))
