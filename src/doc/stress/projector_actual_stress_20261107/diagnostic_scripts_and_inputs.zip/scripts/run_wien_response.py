from pathlib import Path
import os,shutil,subprocess,time,json
r=Path(__file__).parent;c=Path('/private/tmp/projector_stationarity_probe_20261107/SrVO3');d=r/'wien_response';d.mkdir(exist_ok=True)
for p in c.iterdir():
 if p.is_file() and (p.name.startswith('SrVO3.') or p.name in ['dmft2.def','sig.inp1','sig.inp','projectorw.dat','SOlapm.dat','EF.dat','Eorb_imp.dat']):
  if any(x in p.name for x in ['vector','energy','output','clmval','cdos','bnds','scf','nsh']):continue
  shutil.copy2(p,d/p.name)
for suf in ['vector','energy','nsh']:
 p=r/'center'/('SrVO3.'+suf+('_x' if suf!='nsh' else ''));shutil.copy2(p,d/('SrVO3.'+suf))
p=d/'dmft2.def';p.write_text(p.read_text().replace('_x',''))
env=os.environ|{'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','EDMFT_STRESS_STERNHEIMER_DUMP':'1','EDMFT_STRESS_RESPONSE_DUMP':'1','EDMFT_ONEPARTICLE_DUMP':'1'}
t=time.monotonic()
with (d/'run.log').open('w') as f:res=subprocess.run(['/opt/homebrew/bin/mpirun','-n','4','/Users/haule/dbin/dmft2','dmft2.def'],cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT)
print('WIEN central response',res.returncode,time.monotonic()-t,flush=True)
(d/'timing.json').write_text(json.dumps({'rc':res.returncode,'seconds':time.monotonic()-t}))
