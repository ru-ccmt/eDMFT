import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import sys,json,struct,time
sys.dont_write_bytecode=True
sys.path.insert(0,'/Users/haule/projects/eDMFT_new/src/python')
from pathlib import Path
import numpy as np
from scipy.io import FortranFile,FortranEOFError
from check_sigma_overlap_fd import read_overlap
from check_projector_sternheimer_fd import read_dump
root=Path(__file__).parent
central=Path('/private/tmp/projector_stationarity_probe_20261107/SrVO3')
evidence=np.load(central.parent/'band_matrix_evidence.npz')

def vectors(path):
 f=FortranFile(path)
 radial=[f.read_record('f8') for j in range(8)]
 while True:
  try:b=f.read_record('u1').tobytes()
  except FortranEOFError:break
  kx,ky,kz,name,n,nb,w=struct.unpack('<ddd10siid',b)
  labels=f.read_record('i4').reshape(3,n,order='F')
  e=[];v=[]
  for j in range(nb):
   index,ej=struct.unpack('<id',f.read_record('u1').tobytes());e.append(ej);v.append(f.read_record('c16'))
  yield np.array(e),np.array(v).T,labels,radial

def perm(reference,labels,npw):
 lookup={tuple(labels[:,i]):i for i in range(npw)}
 assert len(lookup)==npw
 return np.array([lookup[tuple(reference[:,i])] for i in range(npw)]+list(range(npw,labels.shape[1])))

from scipy.linalg import solve, polar
names=['center','advection_minus','advection_plus']
iters={n:vectors(root/n/'SrVO3.vector_x') for n in names}
full=vectors(root/'complete_center'/'SrVO3.vector_x')
checks={key:0. for key in ['inverse_residual','wien_subspace_orthonormality','central_energy_difference','central_projected_H_difference','radial_header_difference','pw_gauge_fit_relative','pw_gauge_unitarity','crossgauge_hamiltonian_error']}
projected={n:[] for n in names};totals={};gauge_all=[]
for k in range(1,76):
 d=read_dump(central/f'dmft_sternheimer.k{k:08d}.bin')
 e0,v0,l0,rad0=next(full);assert len(e0)==len(v0),(k,len(e0),len(v0))
 inverse=solve(v0,np.eye(len(v0)),check_finite=False)
 checks['inverse_residual']=max(checks['inverse_residual'],float(np.max(np.abs(inverse@v0-np.eye(len(v0))))))
 dual=inverse[:43]
 npw=d.nbasis-d.nlo
 ids=perm(d.labels,l0,npw)
 Cpw=d.coefficients[:npw,:,0];Vpw=v0[ids[:npw],:43]
 raw=np.zeros((43,43),complex)
 starts=[0]+[i for i in range(1,43) if e0[i]-e0[i-1]>1e-5]+[43]
 gauge=np.zeros_like(raw)
 for lo,hi in zip(starts[:-1],starts[1:]):
  block=np.linalg.lstsq(Cpw[:,lo:hi],Vpw[:,lo:hi],rcond=None)[0]
  raw[lo:hi,lo:hi]=block;gauge[lo:hi,lo:hi]=polar(block)[0]
 fit=np.linalg.norm(Cpw@gauge-Vpw)/np.linalg.norm(Vpw)
 checks['pw_gauge_fit_relative']=max(checks['pw_gauge_fit_relative'],float(fit))
 checks['pw_gauge_unitarity']=max(checks['pw_gauge_unitarity'],float(np.max(np.abs(raw.conj().T@raw-np.eye(43)))))
 checks['crossgauge_hamiltonian_error']=max(checks['crossgauge_hamiltonian_error'],float(np.max(np.abs((gauge*e0[:43])@gauge.conj().T-np.diag(d.energies)))))
 gauge_all.append(gauge)
 for name in names:
  e,v,l,rad=next(iters[name]);assert np.array_equal(l,l0)
  t=dual@v
  checks['wien_subspace_orthonormality']=max(checks['wien_subspace_orthonormality'],float(np.max(np.abs(t.conj().T@t-np.eye(43)))))
  H=gauge@((t*e)@t.conj().T)@gauge.conj().T
  projected[name].append(H)
  if name=='center':
   checks['central_energy_difference']=max(checks['central_energy_difference'],float(np.max(np.abs(e-d.energies))))
   checks['central_projected_H_difference']=max(checks['central_projected_H_difference'],float(np.max(np.abs(H-np.diag(d.energies)))))
  checks['radial_header_difference']=max(checks['radial_header_difference'],max(float(np.max(np.abs(x-y))) for x,y in zip(rad,rad0)))
 if k%15==0:print('k',k,checks,flush=True)
for name in names:projected[name]=np.array(projected[name])
for prefix,h in [('advection_',3e-5)]:
 dv=(projected[prefix+'plus']-projected[prefix+'minus'])/(2*h)
 vals={name:float(np.einsum('kij,kji->',evidence[key],dv).real) for name,key in [('fixed_X','response'),('normalization','norm_response')]}
 vals['total']=vals['fixed_X']+vals['normalization']
 vals['GPa']=vals['total']*14710.507641078/(3*382.70904)
 totals[prefix or 'full']=vals
 print(prefix,vals,flush=True)
 np.save(root/(prefix+'potential_derivative.npy'),dv)
(root/'advection_results.json').write_text(json.dumps({'checks':checks,'totals':totals},indent=2))
np.savez_compressed(root/'projected_hamiltonians_advection.npz',**projected)
np.save(root/'dftks_wien_gauge.npy',gauge_all)
